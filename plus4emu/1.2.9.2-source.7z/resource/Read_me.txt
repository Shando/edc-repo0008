Hello,

all these icons written by me are free.

I only ask you for enclosing *this* file when you copy or 
duplicate any icon or the whole package. Thanx.

---------------------------
SVS of Plus4' [FIRE] crew.
e-mail: svs_fire@inwind.it
---------------------------