#ifndef	VERSION_H
#define	VERSION_H

#ifndef	Q_TITLE
#define	Q_TITLE		"QUASI88"
#endif

#ifndef	Q_VERSION
#define	Q_VERSION	"0.6.3"
#endif

#ifndef	Q_COMMENT
#define	Q_COMMENT	""
#endif

#endif	/* VERSION_H */
