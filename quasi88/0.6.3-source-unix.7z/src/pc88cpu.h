#ifndef PC88CPU_H_INCLUDED
#define PC88CPU_H_INCLUDED


#include  "z80.h"


extern	z80arch	z80main_cpu;		/* �ᥤ�� CPU	*/
extern	z80arch	z80sub_cpu;		/* ���� CPU	*/


#endif	/* PC88CPU_H_INCLUDED */
