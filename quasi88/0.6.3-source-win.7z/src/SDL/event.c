/***********************************************************************
 * �C�x���g���� (�V�X�e���ˑ�)
 *
 *	�ڍׂ́A event.h �Q��
 ************************************************************************/

/* ----------------------------------------------------------------------
 *		�w�b�_�t�@�C����
 * ---------------------------------------------------------------------- */

#include <SDL.h>

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "quasi88.h"
#include "keyboard.h"

#include "graph.h"	/* now_screen_size		*/

#include "drive.h"

#include "emu.h"
#include "device.h"
#include "screen.h"
#include "event.h"



int	use_cmdkey = 1;			/* Command�L�[�Ń��j���[�֑J��     */

int	keyboard_type = 1;		/* �L�[�{�[�h�̎��                */
char	*file_keyboard = NULL;		/* �L�[�ݒ�t�@�C����		   */

int	use_joydevice = TRUE;		/* �W���C�X�e�B�b�N�f�o�C�X���J��? */

	int	use_unicode = FALSE;	/* UNICODE���g����106�L�[�{�[�h�ł� */
static	int	now_unicode = FALSE;	/* ���m�ɃL�[���E����悤�����A�L�[ */
					/* �����[�X�̌��m���ʓ|�Ȃ̂ŕۗ�   */

static	SDL_Joystick *joy = NULL;	/* NULL�Ȃ�W���C�X�e�B�b�N�g�p�s�� */


/*==========================================================================
 * �L�[�z��ɂ���
 *
 *  ��ʃL�[(�����L�[) �́A
 *	106 �L�[�{�[�h�̏ꍇ�APC-8801 �Ɠ����Ȃ̂Ŗ��Ȃ��B
 *	101 �L�[�{�[�h�̏ꍇ�A�ꕔ�z�u���قȂ邵�A�L�[������Ȃ��B
 *	�Ƃ肠�����A�ȉ��̂悤�ɔz�u���Ă݂�B
 *		` �� \�A = �� ^�A [ ] �͂��̂܂܁A \ �� @�A' �� :�A�ECTRL �� _
 *
 *  ����L�[(�@�\�L�[) �́A
 *	�z�X�g���̃L�[����Ǝ������͋C�̋@�\���APC-8801�̃L�[�Ɋ��蓖�Ă悤�B
 *	Pause �� STOP�A PrintScreen �� COPY �ȂǁB�l�I�Ȏ�ςŌ��߂�B
 *
 *  �e���L�[�́A
 *	PC-8801��106�L�[�ŃL�[���󂪎኱�قȂ邪�A���̂܂܂̃L�[������g���B
 *	�ƂȂ�ƁA = �� , �������B mac �Ȃ炠�邪�B
 *
 *  �ŉ��i�̃L�[�̔z�u�́A�K���Ɋ���U��B (�J�b�R�̃L�[�ɂ͊���U��Ȃ�)
 *
 *	PC-8801        ���� GRPH ����  �X�y�[�X �ϊ�  PC    �S�p
 *	101�L�[   Ctrl      Alt        �X�y�[�X             Alt          Ctrl
 *	104�L�[   Ctrl Win  Alt        �X�y�[�X             Alt  Win App Ctrl
 *	109�L�[   Ctrl Win  Alt ���ϊ� �X�y�[�X �ϊ� (�Ђ�) Alt  Win App Ctrl
 *	mac ?     Ctrl      Opt (Cmd)  �X�y�[�X      (cmd) (Opt)        (Ctrl)
 *
 * SDL�̃L�[���͂ɂ��Ă̐��� (Windows & 106�L�[�̏ꍇ)
 *	�����ϐ� SDL_VIDEODRIVER �� windib �� directx �Ƃŋ������قȂ�B
 *	���uSHIFT�v�������Ȃ��� �u1�v �������Ă��Akeysym �� �u1�v �̂܂܁B
 *	  �܂�A �u!�v �͓��͂���Ȃ��݂����B
 *	  �啶�� �uA�v �����͂���Ȃ��B keysym �� �ua�v �ƂȂ�B
 *	���L�[�z��� 101 ���x�[�X�ɂȂ��Ă���B
 *	  �u^�v �������Ă� keysym �� �u=�v �ɂȂ�B
 *	���������̃L�[�ŁA keycode ���d�����Ă���
 *	  windib  ���ƁA�J�[�\���L�[�ƃe���L�[�ȂǁA��������B
 *	  directx �Ȃ�A�d���͖��� ?
 *	���������̃L�[�ŁA keysym ���d�����Ă���
 *	  windib  ���ƁA�� �� ]  (�Ƃ��� �� �ɂȂ�)
 *	  directx �Ȃ�A�d���͖��� ?
 *	���������̃L�[�ŁA�L�[�V���{��������`
 *	  ���ϊ��A�ϊ��A�J�^�J�i�Ђ炪�� ������`
 *	  windib  ���ƁA�_ ������`
 *	  directx ���ƁA�O�����F�A���p/�S�p ������`
 *	���������̃L�[�ŁA�L�[�𗣂������̌��m���s����(?)
 *	  windib  ���� ���p/�S�p�A�J�^�J�i�Ђ炪�ȁAPrintScreen
 *	  directx ���� ALT
 *	���L�[���b�N�ɓ��(?)
 *	  NumLock�̓��b�N�ł���B
 *	  windib  ���� SHIFT + CapsLock �����b�N�B
 *	  NumLock ���� CapsLock�A�J�^�J�i�Ђ炪�ȁA���p/�S�p�����b�N�B
 *
 *	�����j���[���[�h�ł́AUNICODE ��L���ɂ���B
 *	  ��������΁A�uSHIFT�v+�u1�v �� �u!�v �ƔF���ł��邵�A�uSHIFT�v+�u2�v
 *	  �� �u"�v�ɂȂ�B�������A  directx ���ƁA���͂ł��Ȃ����������邼�B
 *
 *	���Ƃ���ŁA���{��Windows�ł�101�L�[�{�[�h�ƁA�p��Windows�ł�
 *	  101�L�[�{�[�h���āA���������Ȃ񂾂낤���E�E�E
 *	  directx �̎��̃L�[�R�[�h���蓖�Ă����炩�ɕs���R�Ȃ̂����B
 *===========================================================================*/

/*----------------------------------------------------------------------
 * SDL �� keysym �� QUASI88 �� �L�[�R�[�h�ɕϊ�����e�[�u��
 *
 *	�L�[�V���{�� SDLK_xxx �������ꂽ��A 
 *	keysym2key88[ SDLK_xxx ] �������ꂽ�Ƃ���B
 *----------------------------------------------------------------------*/
static int keysym2key88[ SDLK_LAST ];



/*----------------------------------------------------------------------
 * SDL �� scancode �� QUASI88 �� �L�[�R�[�h�ɕϊ�����e�[�u��
 *
 *	�X�L�����R�[�h code �������ꂽ��A
 *	keycode2key88[ code ] �������ꂽ�Ƃ���B
 *	(keysym2key88[]�ɗD�悷��B�X�L�����R�[�h�̒l�� 0�`�z��max�܂�)
 *----------------------------------------------------------------------*/
static int scancode2key88[ 256 ];

 

/*----------------------------------------------------------------------
 * �\�t�g�E�F�A NumLock �I��/�I�t ���̃}�b�s���O�ύX�e�[�u��
 *
 *	binding[].code �������ꂽ��A
 *	binding[].new_key88 �������ꂽ���Ƃɂ���B
 *	(�ύX�ł���L�[�̌��́A�z��max�܂�)
 *----------------------------------------------------------------------*/
typedef struct{
  int type;		/* 0:�I�[ / 1:keysym / 2:scancode	*/
  int code;		/* �L�[�V���{���A�Ȃ����A�X�L�����R�[�h	*/
  int org_key88;	/* NumLock OFF���� QUASI88�L�[�R�[�h	*/
  int new_key88;	/* NumLock ON ���� QUASI88�L�[�R�[�h	*/
} T_BINDING;

static T_BINDING binding[ 64 ];





/*----------------------------------------------------------------------
 * SDLK_xxx �� KEY88_xxx �ϊ��e�[�u�� (�f�t�H���g)
 *----------------------------------------------------------------------*/

static const int keysym2key88_default[ SDLK_LAST ] =
{
  0,				/*	SDLK_UNKNOWN		= 0,	*/
  0, 0, 0, 0, 0, 0, 0,
  KEY88_INS_DEL,		/*	SDLK_BACKSPACE		= 8,	*/
  KEY88_TAB,			/*	SDLK_TAB		= 9,	*/
  0, 0,
  KEY88_HOME,			/*	SDLK_CLEAR		= 12,	*/
  KEY88_RETURNL,		/*	SDLK_RETURN		= 13,	*/
  0, 0, 0, 0, 0,
  KEY88_STOP,			/*	SDLK_PAUSE		= 19,	*/
  0, 0, 0, 0, 0, 0, 0,
  KEY88_ESC,			/*	SDLK_ESCAPE		= 27,	*/
  0, 0, 0, 0,

  KEY88_SPACE,			/*	SDLK_SPACE		= 32,	*/
  KEY88_EXCLAM,			/*	SDLK_EXCLAIM		= 33,	*/
  KEY88_QUOTEDBL,		/*	SDLK_QUOTEDBL		= 34,	*/
  KEY88_NUMBERSIGN,		/*	SDLK_HASH		= 35,	*/
  KEY88_DOLLAR,			/*	SDLK_DOLLAR		= 36,	*/
  KEY88_PERCENT,		/*					*/
  KEY88_AMPERSAND,		/*	SDLK_AMPERSAND		= 38,	*/
  KEY88_APOSTROPHE,		/*	SDLK_QUOTE		= 39,	*/
  KEY88_PARENLEFT,		/*	SDLK_LEFTPAREN		= 40,	*/
  KEY88_PARENRIGHT,		/*	SDLK_RIGHTPAREN		= 41,	*/
  KEY88_ASTERISK,		/*	SDLK_ASTERISK		= 42,	*/
  KEY88_PLUS,			/*	SDLK_PLUS		= 43,	*/
  KEY88_COMMA,			/*	SDLK_COMMA		= 44,	*/
  KEY88_MINUS,			/*	SDLK_MINUS		= 45,	*/
  KEY88_PERIOD,			/*	SDLK_PERIOD		= 46,	*/
  KEY88_SLASH,			/*	SDLK_SLASH		= 47,	*/
  KEY88_0,			/*	SDLK_0			= 48,	*/
  KEY88_1,			/*	SDLK_1			= 49,	*/
  KEY88_2,			/*	SDLK_2			= 50,	*/
  KEY88_3,			/*	SDLK_3			= 51,	*/
  KEY88_4,			/*	SDLK_4			= 52,	*/
  KEY88_5,			/*	SDLK_5			= 53,	*/
  KEY88_6,			/*	SDLK_6			= 54,	*/
  KEY88_7,			/*	SDLK_7			= 55,	*/
  KEY88_8,			/*	SDLK_8			= 56,	*/
  KEY88_9,			/*	SDLK_9			= 57,	*/
  KEY88_COLON,			/*	SDLK_COLON		= 58,	*/
  KEY88_SEMICOLON,		/*	SDLK_SEMICOLON		= 59,	*/
  KEY88_LESS,			/*	SDLK_LESS		= 60,	*/
  KEY88_EQUAL,			/*	SDLK_EQUALS		= 61,	*/
  KEY88_GREATER,		/*	SDLK_GREATER		= 62,	*/
  KEY88_QUESTION,		/*	SDLK_QUESTION		= 63,	*/
  KEY88_AT,			/*	SDLK_AT			= 64,	*/
  KEY88_A,			/*					*/
  KEY88_B,			/*					*/
  KEY88_C,			/*					*/
  KEY88_D,			/*					*/
  KEY88_E,			/*					*/
  KEY88_F,			/*					*/
  KEY88_G,			/*					*/
  KEY88_H,			/*					*/
  KEY88_I,			/*					*/
  KEY88_J,			/*					*/
  KEY88_K,			/*					*/
  KEY88_L,			/*					*/
  KEY88_M,			/*					*/
  KEY88_N,			/*					*/
  KEY88_O,			/*					*/
  KEY88_P,			/*					*/
  KEY88_Q,			/*					*/
  KEY88_R,			/*					*/
  KEY88_S,			/*					*/
  KEY88_T,			/*					*/
  KEY88_U,			/*					*/
  KEY88_V,			/*					*/
  KEY88_W,			/*					*/
  KEY88_X,			/*					*/
  KEY88_Y,			/*					*/
  KEY88_Z,			/*					*/
  KEY88_BRACKETLEFT,		/*	SDLK_LEFTBRACKET	= 91,	*/
  KEY88_YEN,			/*	SDLK_BACKSLASH		= 92,	*/
  KEY88_BRACKETRIGHT,		/*	SDLK_RIGHTBRACKET	= 93,	*/
  KEY88_CARET,			/*	SDLK_CARET		= 94,	*/
  KEY88_UNDERSCORE,		/*	SDLK_UNDERSCORE		= 95,	*/
  KEY88_BACKQUOTE,		/*	SDLK_BACKQUOTE		= 96,	*/
  KEY88_a,			/*	SDLK_a			= 97,	*/
  KEY88_b,			/*	SDLK_b			= 98,	*/
  KEY88_c,			/*	SDLK_c			= 99,	*/
  KEY88_d,			/*	SDLK_d			= 100,	*/
  KEY88_e,			/*	SDLK_e			= 101,	*/
  KEY88_f,			/*	SDLK_f			= 102,	*/
  KEY88_g,			/*	SDLK_g			= 103,	*/
  KEY88_h,			/*	SDLK_h			= 104,	*/
  KEY88_i,			/*	SDLK_i			= 105,	*/
  KEY88_j,			/*	SDLK_j			= 106,	*/
  KEY88_k,			/*	SDLK_k			= 107,	*/
  KEY88_l,			/*	SDLK_l			= 108,	*/
  KEY88_m,			/*	SDLK_m			= 109,	*/
  KEY88_n,			/*	SDLK_n			= 110,	*/
  KEY88_o,			/*	SDLK_o			= 111,	*/
  KEY88_p,			/*	SDLK_p			= 112,	*/
  KEY88_q,			/*	SDLK_q			= 113,	*/
  KEY88_r,			/*	SDLK_r			= 114,	*/
  KEY88_s,			/*	SDLK_s			= 115,	*/
  KEY88_t,			/*	SDLK_t			= 116,	*/
  KEY88_u,			/*	SDLK_u			= 117,	*/
  KEY88_v,			/*	SDLK_v			= 118,	*/
  KEY88_w,			/*	SDLK_w			= 119,	*/
  KEY88_x,			/*	SDLK_x			= 120,	*/
  KEY88_y,			/*	SDLK_y			= 121,	*/
  KEY88_z,			/*	SDLK_z			= 122,	*/
  KEY88_BRACELEFT,		/*					*/
  KEY88_BAR,			/*					*/
  KEY88_BRACERIGHT,		/*					*/
  KEY88_TILDE,			/*					*/
  KEY88_DEL,			/*	SDLK_DELETE		= 127,	*/

  0, 0, 0, 0, 0, 0, 0, 0,	/*	SDLK_WORLD_0		= 160,	*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
				/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*		:			*/
  0, 0, 0, 0, 0, 0, 0, 0,	/*	SDLK_WORLD_95		= 255,	*/

  KEY88_KP_0,			/*	SDLK_KP0		= 256,	*/
  KEY88_KP_1,			/*	SDLK_KP1		= 257,	*/
  KEY88_KP_2,			/*	SDLK_KP2		= 258,	*/
  KEY88_KP_3,			/*	SDLK_KP3		= 259,	*/
  KEY88_KP_4,			/*	SDLK_KP4		= 260,	*/
  KEY88_KP_5,			/*	SDLK_KP5		= 261,	*/
  KEY88_KP_6,			/*	SDLK_KP6		= 262,	*/
  KEY88_KP_7,			/*	SDLK_KP7		= 263,	*/
  KEY88_KP_8,			/*	SDLK_KP8		= 264,	*/
  KEY88_KP_9,			/*	SDLK_KP9		= 265,	*/
  KEY88_KP_PERIOD,		/*	SDLK_KP_PERIOD		= 266,	*/
  KEY88_KP_DIVIDE,		/*	SDLK_KP_DIVIDE		= 267,	*/
  KEY88_KP_MULTIPLY,		/*	SDLK_KP_MULTIPLY	= 268,	*/
  KEY88_KP_SUB,			/*	SDLK_KP_MINUS		= 269,	*/
  KEY88_KP_ADD,			/*	SDLK_KP_PLUS		= 270,	*/
  KEY88_RETURNR,		/*	SDLK_KP_ENTER		= 271,	*/
  KEY88_KP_EQUAL,		/*	SDLK_KP_EQUALS		= 272,	*/
  KEY88_UP,			/*	SDLK_UP			= 273,	*/
  KEY88_DOWN,			/*	SDLK_DOWN		= 274,	*/
  KEY88_RIGHT,			/*	SDLK_RIGHT		= 275,	*/
  KEY88_LEFT,			/*	SDLK_LEFT		= 276,	*/
  KEY88_INS,			/*	SDLK_INSERT		= 277,	*/
  KEY88_HOME,			/*	SDLK_HOME		= 278,	*/
  KEY88_HELP,			/*	SDLK_END		= 279,	*/
  KEY88_ROLLDOWN,		/*	SDLK_PAGEUP		= 280,	*/
  KEY88_ROLLUP,			/*	SDLK_PAGEDOWN		= 281,	*/
  KEY88_F1,			/*	SDLK_F1			= 282,	*/
  KEY88_F2,			/*	SDLK_F2			= 283,	*/
  KEY88_F3,			/*	SDLK_F3			= 284,	*/
  KEY88_F4,			/*	SDLK_F4			= 285,	*/
  KEY88_F5,			/*	SDLK_F5			= 286,	*/
  KEY88_F6,			/*	SDLK_F6			= 287,	*/
  KEY88_F7,			/*	SDLK_F7			= 288,	*/
  KEY88_F8,			/*	SDLK_F8			= 289,	*/
  KEY88_F9,			/*	SDLK_F9			= 290,	*/
  KEY88_F10,			/*	SDLK_F10		= 291,	*/
  KEY88_F11,			/*	SDLK_F11		= 292,	*/
  KEY88_F12,			/*	SDLK_F12		= 293,	*/
  KEY88_F13,			/*	SDLK_F13		= 294,	*/
  KEY88_F14,			/*	SDLK_F14		= 295,	*/
  KEY88_F15,			/*	SDLK_F15		= 296,	*/
  0, 0, 0,
  0,				/*	SDLK_NUMLOCK		= 300,	*/
  KEY88_CAPS,			/*	SDLK_CAPSLOCK		= 301,	*/
  KEY88_KANA,			/*	SDLK_SCROLLOCK		= 302,	*/
  KEY88_SHIFTR,			/*	SDLK_RSHIFT		= 303,	*/
  KEY88_SHIFTL,			/*	SDLK_LSHIFT		= 304,	*/
  KEY88_CTRL,			/*	SDLK_RCTRL		= 305,	*/
  KEY88_CTRL,			/*	SDLK_LCTRL		= 306,	*/
  KEY88_GRAPH,			/*	SDLK_RALT		= 307,	*/
  KEY88_GRAPH,			/*	SDLK_LALT		= 308,	*/
  KEY88_GRAPH,			/*	SDLK_RMETA		= 309,	*/
  KEY88_GRAPH,			/*	SDLK_LMETA		= 310,	*/
  0,				/*	SDLK_LSUPER		= 311,	*/
  0,				/*	SDLK_RSUPER		= 312,	*/
  0,				/*	SDLK_MODE		= 313,	*/
  0,				/*	SDLK_COMPOSE		= 314,	*/
  KEY88_HELP,			/*	SDLK_HELP		= 315,	*/
  KEY88_COPY,			/*	SDLK_PRINT		= 316,	*/
  0,				/*	SDLK_SYSREQ		= 317,	*/
  KEY88_STOP,			/*	SDLK_BREAK		= 318,	*/
  0,				/*	SDLK_MENU		= 319,	*/
  0,				/*	SDLK_POWER		= 320,	*/
  0,				/*	SDLK_EURO		= 321,	*/
  0,				/*	SDLK_UNDO		= 322,	*/
};



/*----------------------------------------------------------------------
 * keysym2key88[] �� scancode2key88[] �̈ꕔ���A�ύX����e�[�u��
 *----------------------------------------------------------------------*/

typedef struct{
  int type;		/* 0:�I�[ / 1:keysym / 2:scancode	*/
  int code;		/* �L�[�V���{���A�Ȃ����A�X�L�����R�[�h	*/
  int key88;
} T_REMAPPING;


const T_REMAPPING remapping_x11_106[] =
{
  {	1,  SDLK_LSUPER,	KEY88_KANA,		},
  {	1,  SDLK_RALT,		KEY88_ZENKAKU,		},
/*{	1,  SDLK_RCTRL,		KEY88_UNDERSCORE,	},*/
  {	1,  SDLK_MENU,		KEY88_SYS_MENU, 	},
  {	2,  49,			KEY88_ZENKAKU,		},	/* ���p�S�p */
  {	2,  133,		KEY88_YEN,		},	/* \ |      */
  {	2,  123,		KEY88_UNDERSCORE,	},	/* \ _ ��   */
  {	2,  131,		KEY88_KETTEI,		},
  {	2,  129,		KEY88_HENKAN,		},
  {	2,  120,		KEY88_KANA,		},	/* �J�^�Ђ� */
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_x11_101[] =
{
  {	1,  SDLK_BACKQUOTE,	KEY88_YEN,		},
  {	1,  SDLK_EQUALS,	KEY88_CARET,		},
  {	1,  SDLK_BACKSLASH,	KEY88_AT,		},
  {	1,  SDLK_QUOTE,		KEY88_COLON,		},
  {	1,  SDLK_LSUPER,	KEY88_KANA,		},
  {	1,  SDLK_RALT,		KEY88_ZENKAKU,		},
  {	1,  SDLK_RCTRL,		KEY88_UNDERSCORE,	},
  {	1,  SDLK_MENU,		KEY88_SYS_MENU, 	},
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_windib_106[] =
{
  {	1,  SDLK_BACKQUOTE,	0,			},	/* ���p�S�p */
  {	1,  SDLK_EQUALS,	KEY88_CARET,		},	/* ^        */
  {	1,  SDLK_LEFTBRACKET,	KEY88_AT,		},	/* @        */
  {	1,  SDLK_RIGHTBRACKET,	KEY88_BRACKETLEFT,	},	/* [        */
  {	1,  SDLK_QUOTE,		KEY88_COLON,		},	/* :        */
  {	1,  SDLK_LSUPER,	KEY88_KANA,		},	/* ��Window */
  {	1,  SDLK_RALT,		KEY88_ZENKAKU,		},	/* �EAlt    */
/*{	1,  SDLK_RCTRL,		KEY88_UNDERSCORE,	},*/	/* �ECtrl   */
  {	1,  SDLK_MENU,		KEY88_SYS_MENU, 	},	/* Menu     */
  {	2,  125,		KEY88_YEN,		},	/* \ |      */
  {	2,   43,		KEY88_BRACKETRIGHT,	},	/* ] }      */
  {	2,  115,		KEY88_UNDERSCORE,	},	/* \ _ ��   */
  {	2,  123,		KEY88_KETTEI,		},	/* ���ϊ�   */
  {	2,  121,		KEY88_HENKAN,		},	/* �ϊ�     */
/*{	2,  112,		0,			},*/	/* �J�^�Ђ� */
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_windib_101[] =
{
  {	1,  SDLK_BACKQUOTE,	KEY88_YEN,		}, 	/* `        */
  {	1,  SDLK_EQUALS,	KEY88_CARET,		}, 	/* =        */
  {	1,  SDLK_BACKSLASH,	KEY88_AT,		},	/* \        */
  {	1,  SDLK_QUOTE,		KEY88_COLON,		}, 	/* '        */
  {	1,  SDLK_LSUPER,	KEY88_KANA,		},	/* ��Window */
  {	1,  SDLK_RALT,		KEY88_ZENKAKU,		},	/* �EAlt    */
  {	1,  SDLK_RCTRL,		KEY88_UNDERSCORE,	},	/* �ECtrl   */
  {	1,  SDLK_MENU,		KEY88_SYS_MENU, 	},	/* Menu     */
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_directx_106[] =
{
  {	1,  SDLK_BACKSLASH,	KEY88_UNDERSCORE,	},	/* \ _ ��   */
  {	1,  SDLK_LMETA,		KEY88_KANA,		},	/* ��Window */
  {	1,  SDLK_RALT,		KEY88_ZENKAKU,		},	/* �EAlt    */
/*{	1,  SDLK_RCTRL,		KEY88_UNDERSCORE,	},*/	/* �ECtrl   */
  {	1,  SDLK_MENU,		KEY88_SYS_MENU, 	},	/* Menu     */
/*{	2,  148,		0,			},*/	/* ���p�S�p */
  {	2,  144,		KEY88_CARET,		},	/* ^        */
  {	2,  125,		KEY88_YEN,		},	/* \        */
  {	2,  145,		KEY88_AT,		},	/* @        */
  {	2,  146,		KEY88_COLON,		},	/* :        */
  {	2,  123,		KEY88_KETTEI,		},	/* ���ϊ�   */
  {	2,  121,		KEY88_HENKAN,		},	/* �ϊ�     */
  {	2,  112,		KEY88_KANA,		},	/* �J�^�Ђ� */
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_directx_101[] =
{
  {	1,  SDLK_BACKQUOTE,	KEY88_YEN,		}, 	/* `        */
  {	1,  SDLK_EQUALS,	KEY88_CARET,		}, 	/* =        */
  {	1,  SDLK_BACKSLASH,	KEY88_AT,		},	/* \        */
  {	1,  SDLK_QUOTE,		KEY88_COLON,		}, 	/* '        */
  {	1,  SDLK_LMETA,		KEY88_KANA,		},	/* ��Window */
  {	1,  SDLK_RALT,		KEY88_ZENKAKU,		},	/* �EAlt    */
  {	1,  SDLK_RCTRL,		KEY88_UNDERSCORE,	},	/* �ECtrl   */
  {	1,  SDLK_MENU,		KEY88_SYS_MENU, 	},	/* Menu     */
  {	2,  148,		KEY88_YEN,		},
  {	2,  144,		KEY88_CARET,		},
  {	2,  145,		KEY88_AT,		},
  {	2,  146,		KEY88_COLON,		},
  {	2,  125,		KEY88_YEN,		},
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_toolbox_106[] =
{
  {	1,  SDLK_LMETA,		KEY88_SYS_MENU,		},
  {	1,  SDLK_RMETA,		KEY88_SYS_MENU,		},
  {	2,  95,			KEY88_KP_COMMA,		},
/*{	2,  102,		0,			},*/	 /* �p��    */
/*{	2,  104,		0,			},*/	 /* �J�i    */
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_toolbox_101[] =
{
  {	1,  SDLK_LMETA,		KEY88_SYS_MENU,		},
  {	1,  SDLK_RMETA,		KEY88_SYS_MENU,		},
  {	1,  SDLK_BACKQUOTE,	KEY88_YEN,		},
  {	1,  SDLK_EQUALS,	KEY88_CARET,		},
  {	1,  SDLK_BACKSLASH,	KEY88_AT,		},
  {	1,  SDLK_QUOTE,		KEY88_COLON,		},
  {	0,  0,			0,			},
};

const T_REMAPPING remapping_dummy[] =
{
  {	0,  0,			0,			},
};



/*----------------------------------------------------------------------
 * �\�t�g�E�F�A NumLock �I��/�I�t ���̃}�b�s���O�ύX�e�[�u��
 *----------------------------------------------------------------------*/

static const T_BINDING binding_106[] =
{
  {	1,	SDLK_5,		0,	KEY88_HOME,		},
  {	1,	SDLK_6,		0,	KEY88_HELP,		},
  {	1,	SDLK_7,		0,	KEY88_KP_7,		},
  {	1,	SDLK_8,		0,	KEY88_KP_8,		},
  {	1,	SDLK_9,		0,	KEY88_KP_9,		},
  {	1,	SDLK_0,		0,	KEY88_KP_MULTIPLY,	},
  {	1,	SDLK_MINUS,	0,	KEY88_KP_SUB,		},
  {	1,	SDLK_CARET,	0,	KEY88_KP_DIVIDE,	},
  {	1,	SDLK_u,		0,	KEY88_KP_4,		},
  {	1,	SDLK_i,		0,	KEY88_KP_5,		},
  {	1,	SDLK_o,		0,	KEY88_KP_6,		},
  {	1,	SDLK_p,		0,	KEY88_KP_ADD,		},
  {	1,	SDLK_j,		0,	KEY88_KP_1,		},
  {	1,	SDLK_k,		0,	KEY88_KP_2,		},
  {	1,	SDLK_l,		0,	KEY88_KP_3,		},
  {	1,	SDLK_SEMICOLON,	0,	KEY88_KP_EQUAL,		},
  {	1,	SDLK_m,		0,	KEY88_KP_0,		},
  {	1,	SDLK_COMMA,	0,	KEY88_KP_COMMA,		},
  {	1,	SDLK_PERIOD,	0,	KEY88_KP_PERIOD,	},
  {	1,	SDLK_SLASH,	0,	KEY88_RETURNR,		},
  {	0,	0,		0,	0,			},
};

static const T_BINDING binding_101[] =
{
  {	1,	SDLK_5,		0,	KEY88_HOME,		},
  {	1,	SDLK_6,		0,	KEY88_HELP,		},
  {	1,	SDLK_7,		0,	KEY88_KP_7,		},
  {	1,	SDLK_8,		0,	KEY88_KP_8,		},
  {	1,	SDLK_9,		0,	KEY88_KP_9,		},
  {	1,	SDLK_0,		0,	KEY88_KP_MULTIPLY,	},
  {	1,	SDLK_MINUS,	0,	KEY88_KP_SUB,		},
  {	1,	SDLK_EQUALS,	0,	KEY88_KP_DIVIDE,	},
  {	1,	SDLK_u,		0,	KEY88_KP_4,		},
  {	1,	SDLK_i,		0,	KEY88_KP_5,		},
  {	1,	SDLK_o,		0,	KEY88_KP_6,		},
  {	1,	SDLK_p,		0,	KEY88_KP_ADD,		},
  {	1,	SDLK_j,		0,	KEY88_KP_1,		},
  {	1,	SDLK_k,		0,	KEY88_KP_2,		},
  {	1,	SDLK_l,		0,	KEY88_KP_3,		},
  {	1,	SDLK_SEMICOLON,	0,	KEY88_KP_EQUAL,		},
  {	1,	SDLK_m,		0,	KEY88_KP_0,		},
  {	1,	SDLK_COMMA,	0,	KEY88_KP_COMMA,		},
  {	1,	SDLK_PERIOD,	0,	KEY88_KP_PERIOD,	},
  {	1,	SDLK_SLASH,	0,	KEY88_RETURNR,		},
  {	0,	0,		0,	0,			},
};

static const T_BINDING binding_directx[] =
{
  {	1,	SDLK_5,		0,	KEY88_HOME,		},
  {	1,	SDLK_6,		0,	KEY88_HELP,		},
  {	1,	SDLK_7,		0,	KEY88_KP_7,		},
  {	1,	SDLK_8,		0,	KEY88_KP_8,		},
  {	1,	SDLK_9,		0,	KEY88_KP_9,		},
  {	1,	SDLK_0,		0,	KEY88_KP_MULTIPLY,	},
  {	1,	SDLK_MINUS,	0,	KEY88_KP_SUB,		},
  {	1,	SDLK_EQUALS,	0,	KEY88_KP_DIVIDE,	},
  {	2,	144,		0,	KEY88_KP_DIVIDE,	},
  {	1,	SDLK_u,		0,	KEY88_KP_4,		},
  {	1,	SDLK_i,		0,	KEY88_KP_5,		},
  {	1,	SDLK_o,		0,	KEY88_KP_6,		},
  {	1,	SDLK_p,		0,	KEY88_KP_ADD,		},
  {	1,	SDLK_j,		0,	KEY88_KP_1,		},
  {	1,	SDLK_k,		0,	KEY88_KP_2,		},
  {	1,	SDLK_l,		0,	KEY88_KP_3,		},
  {	1,	SDLK_SEMICOLON,	0,	KEY88_KP_EQUAL,		},
  {	1,	SDLK_m,		0,	KEY88_KP_0,		},
  {	1,	SDLK_COMMA,	0,	KEY88_KP_COMMA,		},
  {	1,	SDLK_PERIOD,	0,	KEY88_KP_PERIOD,	},
  {	1,	SDLK_SLASH,	0,	KEY88_RETURNR,		},
  {	0,	0,		0,	0,			},
};



/******************************************************************************
 * ���j���[�ɓ���ۂ̃L�[�̖��̂�Ԃ�
 *	�Ƃ肠�����A�N�����̃X�e�[�^�X�̕\���ɂĎg�p�B
 *	�{���̓��j���[���[�h�̒��ł����f������K�v������̂��� �c�c�c
 *		�ʓ|�Ȃ̂ŁA�����͍���̉ۑ�ɂ��悤
 *****************************************************************************/
const	char	*get_keysym_menu( void )
{
#if	defined( QUASI88_FMAC )
  if( use_cmdkey ){
    return	"Command";
  }
#endif

  return	"F12";
}


/******************************************************************************
 * �C�x���g�n���h�����O
 *
 *	1/60���ɌĂяo�����B
 *****************************************************************************/
static	int	analyze_keyconf_file( const char *video_driver );

/*
 * ����� �N������1�񂾂��Ă΂��
 */
void	event_handle_init( void )
{
  const T_REMAPPING *map;
  const T_BINDING   *bin;
  int i;
  char video_driver[32];


  if( SDL_VideoDriverName( video_driver, sizeof(video_driver) ) == NULL ){
    memset( video_driver, 0, sizeof(video_driver) );
  }

  memset( keysym2key88, 0, sizeof(keysym2key88) );
  for( i=0; i<COUNTOF(scancode2key88); i++ ){
    scancode2key88[ i ] = -1;
  }
  memset( binding, 0, sizeof(binding) );

  function_f[ 11 ] = FN_STATUS;
  function_f[ 12 ] = FN_MENU;



  switch( keyboard_type ){

  case 0:					/* �f�t�H���g�L�[�{�[�h */
    if( analyze_keyconf_file( video_driver ) ){
      ;
    }else{
      memcpy( keysym2key88, keysym2key88_default,sizeof(keysym2key88_default));
      memcpy( binding, binding_106, sizeof(binding_106) );
    }
    break;


  case 1:					/* 106���{��L�[�{�[�h */
  case 2:					/* 101�p��L�[�{�[�h ? */
    memcpy( keysym2key88, keysym2key88_default, sizeof(keysym2key88_default) );

#if	defined( QUASI88_FUNIX )

    if( keyboard_type == 1 ){ map = remapping_x11_106;	bin = binding_106; }
    else                    { map = remapping_x11_101;	bin = binding_101; }

#elif	defined( QUASI88_FWIN )

    if( strcmp( video_driver, "directx" ) == 0 ){
      if( keyboard_type == 1 ) map = remapping_directx_106;
      else                     map = remapping_directx_101;
      bin = binding_directx;
    }else{
      if( keyboard_type == 1 ) map = remapping_windib_106;
      else                     map = remapping_windib_101;
      bin = binding_101;
    }

#elif	defined( QUASI88_FMAC )

    if( keyboard_type == 1 ){ map = remapping_toolbox_106; bin = binding_106; }
    else                    { map = remapping_toolbox_101; bin = binding_101; }

    if( use_cmdkey == FALSE ){
      map += 2;
    }

#else
    map = remapping_dummy;
    bin = binding_106;
#endif

    for( ;  map->type;  map ++ ){

      if      ( map->type == 1 ){

	keysym2key88[ map->code ] = map->key88;

      }else if( map->type == 2 ){

	scancode2key88[ map->code ] = map->key88;

      }
    }

    for( i=0; i<COUNTOF(binding); i++ ){
      if( bin->type == 0 ) break;

      binding[ i ].type      = bin->type;
      binding[ i ].code      = bin->code;
      binding[ i ].org_key88 = bin->org_key88;
      binding[ i ].new_key88 = bin->new_key88;
      bin ++;
    }
    break;
  }



  /* �\�t�g�E�F�ANumLock ���̃L�[�����ւ��̏��� */

  for( i=0; i<COUNTOF(binding); i++ ){

    if      ( binding[i].type == 1 ){

      binding[i].org_key88 = keysym2key88[ binding[i].code ];

    }else if( binding[i].type == 2 ){

      binding[i].org_key88 = scancode2key88[ binding[i].code ];

    }else{
      break;
    }
  }

}



/*
 * �� 1/60 ���ɌĂ΂��
 */
void	event_handle( void )
{
  static enum {
    AXIS_U = 0x01,
    AXIS_D = 0x02,
    AXIS_L = 0x04,
    AXIS_R = 0x08
  } pad_axis = 0x00;


  SDL_Event E;
  SDLKey keysym;
  int    key88, x, y;


  SDL_PumpEvents();		/* �C�x���g�����ݏグ�� */

  while( SDL_PeepEvents(&E, 1, SDL_GETEVENT,
			SDL_EVENTMASK(SDL_KEYDOWN)        | 
			SDL_EVENTMASK(SDL_KEYUP)          |
			SDL_EVENTMASK(SDL_MOUSEMOTION)    |
			SDL_EVENTMASK(SDL_MOUSEBUTTONDOWN)|
			SDL_EVENTMASK(SDL_MOUSEBUTTONUP)  |
			SDL_EVENTMASK(SDL_JOYAXISMOTION)  |
			SDL_EVENTMASK(SDL_JOYBUTTONDOWN)  |
			SDL_EVENTMASK(SDL_JOYBUTTONUP)    |
			SDL_EVENTMASK(SDL_VIDEOEXPOSE)    |
			SDL_EVENTMASK(SDL_ACTIVEEVENT)    |
    			SDL_EVENTMASK(SDL_QUIT)) ) {

    switch( E.type ){

    case SDL_KEYDOWN:		/*------------------------------------------*/
    case SDL_KEYUP:

      keysym  = E.key.keysym.sym;

      if( now_unicode ){		/* �L�[UNICODE�� (���j���[�Ȃ�) */

	if( E.key.keysym.unicode <= 0xff &&
	    isprint( E.key.keysym.unicode ) ){
	  keysym = E.key.keysym.unicode;
	}
	if( SDLK_SPACE <= keysym && keysym < SDLK_DELETE ) key88 = keysym;
	else                                 key88 = keysym2key88[ keysym ];

      }else{				/* �L�[ASCII�� */

	key88 = keysym2key88[ keysym ];

	if( E.key.keysym.scancode < COUNTOF(scancode2key88) &&
	    scancode2key88[ E.key.keysym.scancode ] >= 0    ){

	  key88 = scancode2key88[ E.key.keysym.scancode ];
	}

/*printf("%d %d %d\n",key88,keysym,E.key.keysym.scancode );*/
      }
      pc88_key( key88, (E.type==SDL_KEYDOWN) );

      break;

    case SDL_MOUSEMOTION:	/*------------------------------------------*/
      if( mouse_rel_move ){		/* �}�E�X���E�C���h�E�̒[�ɓ͂��Ă� */
					/* ���ΓI�ȓ��������o�ł���ꍇ     */
	x = E.motion.xrel;
	y = E.motion.yrel;
#if 0
	if( get_emu_mode()==EXEC ){	/* �}�E�X�̑��x�������\�����ǂ� */
	  x /= 10;			/* �}�E�X��\�����Ă���ꍇ�A     */
	  y /= 10;			/* �\���ʒu�ƍ��W�������̂Œ��� */
	}
#endif
	pc88_mouse_moved_rel( x, y );
      

      }else{

	x = E.motion.x;
	y = E.motion.y;

	x -= SCREEN_DX;
	y -= SCREEN_DY;
	if     ( now_screen_size == SCREEN_SIZE_HALF )  { x *= 2; y *= 2; }
#ifdef	SUPPORT_DOUBLE
	else if( now_screen_size == SCREEN_SIZE_DOUBLE ){ x /= 2; y /= 2; }
#endif
	pc88_mouse_moved_abs( x, y );
      }
      break;


    case SDL_MOUSEBUTTONDOWN:	/*------------------------------------------*/
    case SDL_MOUSEBUTTONUP:

      /* �}�E�X�ړ��C�x���g�������ɏ�������K�v������Ȃ�A
	 pc88_mouse_moved_abs/rel �֐��������ŌĂяo���Ă��� */

      if     ( E.button.button==SDL_BUTTON_LEFT      ) key88 = KEY88_MOUSE_L;
      else if( E.button.button==SDL_BUTTON_MIDDLE    ) key88 = KEY88_MOUSE_M;
      else if( E.button.button==SDL_BUTTON_RIGHT     ) key88 = KEY88_MOUSE_R;
      else if( E.button.button==SDL_BUTTON_WHEELUP   ) key88 = KEY88_MOUSE_WUP;
      else if( E.button.button==SDL_BUTTON_WHEELDOWN ) key88 = KEY88_MOUSE_WDN;
      else break;

      pc88_mouse( key88, (E.type==SDL_MOUSEBUTTONDOWN) );
      break;


    case SDL_JOYAXISMOTION:	/*------------------------------------------*/
/*printf("%d %d %d\n",E.jaxis.which,E.jaxis.axis,E.jaxis.value);*/
      if( E.jbutton.which == 0 ){
	int now, chg;

	if( E.jaxis.axis == 0 ){	/* ���E���� */

	  now = pad_axis & ~(AXIS_L|AXIS_R);

	  if     ( E.jaxis.value < -0x4000 ) now |= AXIS_L;
	  else if( E.jaxis.value >  0x4000 ) now |= AXIS_R;

	  chg = pad_axis ^ now;
	  if( chg & AXIS_L ) pc88_pad( KEY88_PAD_LEFT,  (now & AXIS_L) );
	  if( chg & AXIS_R ) pc88_pad( KEY88_PAD_RIGHT, (now & AXIS_R) );

	}else{				/* �㉺���� */

	  now = pad_axis & ~(AXIS_U|AXIS_D);

	  if     ( E.jaxis.value < -0x4000 ) now |= AXIS_U;
	  else if( E.jaxis.value >  0x4000 ) now |= AXIS_D;

	  chg = pad_axis ^ now;
	  if( chg & AXIS_U ) pc88_pad( KEY88_PAD_UP,    (now & AXIS_U) );
	  if( chg & AXIS_D ) pc88_pad( KEY88_PAD_DOWN,  (now & AXIS_D) );
	}
	pad_axis = now;
      }
      break;


    case SDL_JOYBUTTONDOWN:	/*------------------------------------------*/
    case SDL_JOYBUTTONUP:
/*printf("%d %d\n",E.jbutton.which,E.jbutton.button);*/
      if( E.jbutton.which == 0 ){
	if( E.jbutton.button < 8 ){
	  key88 = KEY88_PAD_A + E.jbutton.button;
	  pc88_pad( key88, ( E.type==SDL_JOYBUTTONDOWN ) );
	}
      }
      break;


    case SDL_QUIT:		/*------------------------------------------*/
      if( verbose_proc ) printf( "Window Closed.....\n" );
      pc88_quit();
      break;


    case SDL_ACTIVEEVENT:	/*------------------------------------------*/
      /* -focus �I�v�V�������@�\���������Ȃ�A 
	 pc88_focus_in / pc88_focus_out ��K�X�Ăяo���K�v������B */

      if( E.active.state & SDL_APPINPUTFOCUS ){
	if( E.active.gain ){
	  pc88_focus_in();
	}else{
	  pc88_focus_out();
	}
      }
      break;


    case SDL_VIDEOEXPOSE:	/*------------------------------------------*/
      put_image_all();			/* EXPOSE ���� ����ɍĕ`�悵�Ă��� */
      break;
    }
  }
}



/***********************************************************************
 * ���݂̃}�E�X���W�擾�֐�
 *
 *	���݂̃}�E�X�̐�΍��W�� *x, *y �ɃZ�b�g
 ************************************************************************/

void	init_mouse_position( int *x, int *y )
{
  int win_x, win_y;

  SDL_PumpEvents();
  SDL_GetMouseState( &win_x, &win_y );

  win_x -= SCREEN_DX;
  win_y -= SCREEN_DY;

  if     ( now_screen_size == SCREEN_SIZE_HALF )  { win_x *= 2;  win_y *= 2; }
#ifdef	SUPPORT_DOUBLE
  else if( now_screen_size == SCREEN_SIZE_DOUBLE ){ win_x /= 2;  win_y /= 2; }
#endif
  *x = win_x;
  *y = win_y;
}




/******************************************************************************
 * �\�t�g�E�F�A NumLock �L���^����
 *
 *****************************************************************************/

INLINE	void	numlock_setup( int enable )
{
  int i;

  for( i=0; i<COUNTOF(binding); i++ ){

    if      ( binding[i].type == 1 ){

      if( enable ){
	keysym2key88[ binding[i].code ] = binding[i].new_key88;
      }else{
	keysym2key88[ binding[i].code ] = binding[i].org_key88;
      }

    }else if( binding[i].type == 2 ){

      if( enable ){
	scancode2key88[ binding[i].code ] = binding[i].new_key88;
      }else{
	scancode2key88[ binding[i].code ] = binding[i].org_key88;
      }

    }else{
      break;
    }
  }
}

int	numlock_on ( void ){ numlock_setup( TRUE );  return TRUE; }
void	numlock_off( void ){ numlock_setup( FALSE ); }



/******************************************************************************
 * �G�~�����[�g�^���j���[�^�|�[�Y�^���j�^�[���[�h �� �J�n���̏���
 *
 *****************************************************************************/

void	event_init( void )
{
  /* �����̃C�x���g�����ׂĔj�� */
  /* �Ȃ�Ă��Ƃ́A���Ȃ� ? */

  if( get_emu_mode() == EXEC ){

    if( use_unicode ){

      /* �L�[������ UNICODE �ɕϊ��\�Ƃ��� (�������d���炵���̂Ŏw�莞�̂�)*/
      SDL_EnableUNICODE( 1 );
      now_unicode = TRUE;

    }else{

      /* �L�[������ ASCII �R�[�h�ɕϊ��\�Ƃ��� */
      SDL_EnableUNICODE( 0 );
      now_unicode = FALSE;
    }

  }else{

    SDL_EnableUNICODE( 1 );
    now_unicode = TRUE;

  }

  /* �}�E�X�\���A�O���u�̐ݒ� (���łɃL�[���s�[�g��) */
  set_mouse_state();
}



/******************************************************************************
 * �W���C�X�e�B�b�N
 *
 * ��x�����̏��������_�i�E�C���h�E�Ƃ��H�j�ɂāA�I�[�v������B
 *****************************************************************************/

int	joy_init( void )
{
  joy = NULL;

  if( ! SDL_WasInit( SDL_INIT_JOYSTICK ) ){
    if( SDL_InitSubSystem( SDL_INIT_JOYSTICK ) ){
      return FALSE;
    }
  }

  if( SDL_NumJoysticks() >= 1 ){	/* �W���C�X�e�B�b�N�����邩�`�F�b�N */

    joy = SDL_JoystickOpen(0);		/* �W���C�X�e�B�b�N���I�[�v�� */

    if( joy )
      SDL_JoystickEventState( SDL_ENABLE );	/* �C�x���g������L���ɂ��� */
  }

  if( joy ) return TRUE;
  else      return FALSE;
}



int	joystick_available( void )
{
  if( joy ) return TRUE;
  else      return FALSE;
}






/****************************************************************************
 * �L�[�ݒ�t�@�C����ǂݍ���ŁA�ݒ肷��B
 *	�ݒ�t�@�C����������΋U�A����Ώ������Đ^��Ԃ�
 *****************************************************************************/

/* �L�[�ݒ�t�@�C��1�s������̍ő啶���� */
#define	MAX_KEYFILE_LINE	(256)

static	int	convert_str2keysym( const char *str );
static	int	analyze_keyconf_file( const char *video_driver )
{
  FILE *fp = NULL;
  int	enable = FALSE;
  int	initialized = FALSE;

  int  line_cnt = 0;
  int  binding_cnt = 0;
  int  code, key88, chg = -1;
  char   line[ MAX_KEYFILE_LINE ];
  char buffer[ MAX_KEYFILE_LINE ];
  char *parm1, *parm2, *parm3, *parm4;


	/* �L�[�ݒ�t�@�C�����J�� */

  if( file_keyboard == NULL ){			/* �L�[�ݒ�t�@�C�����擾 */
    file_keyboard = alloc_keyboard_cfgname();
  }

  if( file_keyboard ){
    fp = fopen( file_keyboard, "r" );		/* �L�[�ݒ�t�@�C�����J�� */
    if( verbose_proc ){
      if( fp ){
	printf( "\"%s\" read and initialize\n", file_keyboard );
      }else{
	printf( "can't open keyboard configuration file \"%s\"\n",
		file_keyboard );
	printf( "\n" );
      }
      fflush(stdout); fflush(stderr);
    }
    free( file_keyboard );
  }

  if( fp == NULL ) return 0;			/* �J���Ȃ�������U��Ԃ� */



	/* �L�[�ݒ�t�@�C����1�s�Â�� */

  while( fgets( line, MAX_KEYFILE_LINE, fp ) ){

    line_cnt ++;
    parm1 = parm2 = parm3 = parm4 = NULL;

	/* �p�����[�^�� parm1�`parm4 �ɃZ�b�g */

    { char *str = line;
      char *b; {             b = &buffer[0];    str = my_strtok( b, str ); }
      if( str ){ parm1 = b;  b += strlen(b)+1;  str = my_strtok( b, str ); }
      if( str ){ parm2 = b;  b += strlen(b)+1;  str = my_strtok( b, str ); }
      if( str ){ parm3 = b;  b += strlen(b)+1;  str = my_strtok( b, str ); }
      if( str ){ parm4 = b;  }
    }


	/* �p�����[�^���Ȃ���Ύ��̍s�ցA����Ή�͏��� */

    if      ( parm1 == NULL ){			/* �p�����[�^�Ȃ� */
      ;

    }else if( parm2 == NULL ){			/* �p�����[�^ 1�� */

      if( parm1[0] == '[' ){

	if( my_strcmp( parm1, "[SDL]" ) == 0 &&
	    initialized == FALSE ){

	  enable      = TRUE;
	  initialized = TRUE;
	  if( verbose_proc ) printf( "(read start in line %d)\n", line_cnt );

	}else{
	  if( enable ){
	    if(verbose_proc) printf( "(read end   in line %d)\n", line_cnt-1);
	  }
	  enable = FALSE;
	}

      }else if( enable ){
	fprintf( stderr, "warning: error in line %d (ignored)\n", line_cnt );
      }

    }else if( parm3 == NULL ||			/* �p�����[�^ 2�� */
	      parm4 == NULL ){			/* �p�����[�^ 3�� */

      if( parm3 == NULL   &&
	  parm1[0] == '[' ){

	if( my_strcmp( parm1, "[SDL]" )      == 0 &&
	    my_strcmp( parm2, video_driver ) == 0 ){

	  enable      = TRUE;
	  initialized = TRUE;
	  if( verbose_proc ) printf( "(read start in line %d)\n", line_cnt );

	}else{
	  if( enable ){
	    if(verbose_proc) printf( "(read end   in line %d)\n", line_cnt-1);
	  }
	  enable = FALSE;
	}

      }else if( enable ){

	code  = convert_str2keysym( parm1 );
	key88 = convert_str2key88( parm2 );

	if( parm3 ) chg = convert_str2key88( parm3 );


	if( code  < 0 ||
	    key88 < 0 ||
	    (parm3 && chg < 0) ){
	  fprintf( stderr, "warning: error in line %d (ignored)\n", line_cnt );

	}else{

	  if( parm1[0] == '<' ){
	    scancode2key88[ code ] = key88;
	  }else{
	    keysym2key88[ code ]   = key88;
	  }

	  if( parm3 ){
	    if( binding_cnt >= COUNTOF(binding) ){
	      fprintf( stderr,
		"warning: too many NumLock-code in %d (ignored)\n", line_cnt );

	    }else{
	      binding[ binding_cnt ].type      = ( parm1[0] == '<' ) ? 2 : 1;
	      binding[ binding_cnt ].code      = code;
	      binding[ binding_cnt ].new_key88 = chg;
	      binding_cnt ++;
	    }
	  }
	}
      }

    }else{					/* �p�����[�^ �����ς� */

      if( enable ){
	fprintf( stderr, "warning: too many argument in line %d\n", line_cnt );
      }

    }

  }
  fclose(fp);


  if( enable ){
    if(verbose_proc) printf( "(read end   in line %d)\n", line_cnt-1);
  }

  if( initialized == FALSE ){
    fprintf( stderr, "warning: not configured (use initial config)\n" );
  }

  if( verbose_proc ){
    printf( "\n" );
  }
  fflush(stdout); fflush(stderr);

  return (initialized) ? 1 : 0;
}


/*---------------------------------------------------------------------------
 *---------------------------------------------------------------------------*/
static	int	convert_str2keysym( const char *str )
{
  const struct{
    char *name;    int val;
  }
  list[] = {
    {	"SDLK_BACKSPACE",	SDLK_BACKSPACE		}, /*	= 8,	*/
    {	"SDLK_TAB",		SDLK_TAB		}, /*	= 9,	*/
    {	"SDLK_CLEAR",		SDLK_CLEAR		}, /*	= 12,	*/
    {	"SDLK_RETURN",		SDLK_RETURN		}, /*	= 13,	*/
    {	"SDLK_PAUSE",		SDLK_PAUSE		}, /*	= 19,	*/
    {	"SDLK_ESCAPE",		SDLK_ESCAPE		}, /*	= 27,	*/
    {	"SDLK_SPACE",		SDLK_SPACE		}, /*	= 32,	*/
    {	"SDLK_EXCLAIM",		SDLK_EXCLAIM		}, /*	= 33,	*/
    {	"SDLK_QUOTEDBL",	SDLK_QUOTEDBL		}, /*	= 34,	*/
    {	"SDLK_HASH",		SDLK_HASH		}, /*	= 35,	*/
    {	"SDLK_DOLLAR",		SDLK_DOLLAR		}, /*	= 36,	*/
    {	"SDLK_AMPERSAND",	SDLK_AMPERSAND		}, /*	= 38,	*/
    {	"SDLK_QUOTE",		SDLK_QUOTE		}, /*	= 39,	*/
    {	"SDLK_LEFTPAREN",	SDLK_LEFTPAREN		}, /*	= 40,	*/
    {	"SDLK_RIGHTPAREN",	SDLK_RIGHTPAREN		}, /*	= 41,	*/
    {	"SDLK_ASTERISK",	SDLK_ASTERISK		}, /*	= 42,	*/
    {	"SDLK_PLUS",		SDLK_PLUS		}, /*	= 43,	*/
    {	"SDLK_COMMA",		SDLK_COMMA		}, /*	= 44,	*/
    {	"SDLK_MINUS",		SDLK_MINUS		}, /*	= 45,	*/
    {	"SDLK_PERIOD",		SDLK_PERIOD		}, /*	= 46,	*/
    {	"SDLK_SLASH",		SDLK_SLASH		}, /*	= 47,	*/
    {	"SDLK_0",		SDLK_0			}, /*	= 48,	*/
    {	"SDLK_1",		SDLK_1			}, /*	= 49,	*/
    {	"SDLK_2",		SDLK_2			}, /*	= 50,	*/
    {	"SDLK_3",		SDLK_3			}, /*	= 51,	*/
    {	"SDLK_4",		SDLK_4			}, /*	= 52,	*/
    {	"SDLK_5",		SDLK_5			}, /*	= 53,	*/
    {	"SDLK_6",		SDLK_6			}, /*	= 54,	*/
    {	"SDLK_7",		SDLK_7			}, /*	= 55,	*/
    {	"SDLK_8",		SDLK_8			}, /*	= 56,	*/
    {	"SDLK_9",		SDLK_9			}, /*	= 57,	*/
    {	"SDLK_COLON",		SDLK_COLON		}, /*	= 58,	*/
    {	"SDLK_SEMICOLON",	SDLK_SEMICOLON		}, /*	= 59,	*/
    {	"SDLK_LESS",		SDLK_LESS		}, /*	= 60,	*/
    {	"SDLK_EQUALS",		SDLK_EQUALS		}, /*	= 61,	*/
    {	"SDLK_GREATER",		SDLK_GREATER		}, /*	= 62,	*/
    {	"SDLK_QUESTION",	SDLK_QUESTION		}, /*	= 63,	*/
    {	"SDLK_AT",		SDLK_AT			}, /*	= 64,	*/
    {	"SDLK_LEFTBRACKET",	SDLK_LEFTBRACKET	}, /*	= 91,	*/
    {	"SDLK_BACKSLASH",	SDLK_BACKSLASH		}, /*	= 92,	*/
    {	"SDLK_RIGHTBRACKET",	SDLK_RIGHTBRACKET	}, /*	= 93,	*/
    {	"SDLK_CARET",		SDLK_CARET		}, /*	= 94,	*/
    {	"SDLK_UNDERSCORE",	SDLK_UNDERSCORE		}, /*	= 95,	*/
    {	"SDLK_BACKQUOTE",	SDLK_BACKQUOTE		}, /*	= 96,	*/
    {	"SDLK_a",		SDLK_a			}, /*	= 97,	*/
    {	"SDLK_b",		SDLK_b			}, /*	= 98,	*/
    {	"SDLK_c",		SDLK_c			}, /*	= 99,	*/
    {	"SDLK_d",		SDLK_d			}, /*	= 100,	*/
    {	"SDLK_e",		SDLK_e			}, /*	= 101,	*/
    {	"SDLK_f",		SDLK_f			}, /*	= 102,	*/
    {	"SDLK_g",		SDLK_g			}, /*	= 103,	*/
    {	"SDLK_h",		SDLK_h			}, /*	= 104,	*/
    {	"SDLK_i",		SDLK_i			}, /*	= 105,	*/
    {	"SDLK_j",		SDLK_j			}, /*	= 106,	*/
    {	"SDLK_k",		SDLK_k			}, /*	= 107,	*/
    {	"SDLK_l",		SDLK_l			}, /*	= 108,	*/
    {	"SDLK_m",		SDLK_m			}, /*	= 109,	*/
    {	"SDLK_n",		SDLK_n			}, /*	= 110,	*/
    {	"SDLK_o",		SDLK_o			}, /*	= 111,	*/
    {	"SDLK_p",		SDLK_p			}, /*	= 112,	*/
    {	"SDLK_q",		SDLK_q			}, /*	= 113,	*/
    {	"SDLK_r",		SDLK_r			}, /*	= 114,	*/
    {	"SDLK_s",		SDLK_s			}, /*	= 115,	*/
    {	"SDLK_t",		SDLK_t			}, /*	= 116,	*/
    {	"SDLK_u",		SDLK_u			}, /*	= 117,	*/
    {	"SDLK_v",		SDLK_v			}, /*	= 118,	*/
    {	"SDLK_w",		SDLK_w			}, /*	= 119,	*/
    {	"SDLK_x",		SDLK_x			}, /*	= 120,	*/
    {	"SDLK_y",		SDLK_y			}, /*	= 121,	*/
    {	"SDLK_z",		SDLK_z			}, /*	= 122,	*/
    {	"SDLK_DELETE",		SDLK_DELETE		}, /*	= 127,	*/
    {	"SDLK_WORLD_0",		SDLK_WORLD_0		}, /*	= 160,	*/
    {	"SDLK_WORLD_1",		SDLK_WORLD_1		}, /*	= 161,	*/
    {	"SDLK_WORLD_2",		SDLK_WORLD_2		}, /*	= 162,	*/
    {	"SDLK_WORLD_3",		SDLK_WORLD_3		}, /*	= 163,	*/
    {	"SDLK_WORLD_4",		SDLK_WORLD_4		}, /*	= 164,	*/
    {	"SDLK_WORLD_5",		SDLK_WORLD_5		}, /*	= 165,	*/
    {	"SDLK_WORLD_6",		SDLK_WORLD_6		}, /*	= 166,	*/
    {	"SDLK_WORLD_7",		SDLK_WORLD_7		}, /*	= 167,	*/
    {	"SDLK_WORLD_8",		SDLK_WORLD_8		}, /*	= 168,	*/
    {	"SDLK_WORLD_9",		SDLK_WORLD_9		}, /*	= 169,	*/
    {	"SDLK_WORLD_10",	SDLK_WORLD_10		}, /*	= 170,	*/
    {	"SDLK_WORLD_11",	SDLK_WORLD_11		}, /*	= 171,	*/
    {	"SDLK_WORLD_12",	SDLK_WORLD_12		}, /*	= 172,	*/
    {	"SDLK_WORLD_13",	SDLK_WORLD_13		}, /*	= 173,	*/
    {	"SDLK_WORLD_14",	SDLK_WORLD_14		}, /*	= 174,	*/
    {	"SDLK_WORLD_15",	SDLK_WORLD_15		}, /*	= 175,	*/
    {	"SDLK_WORLD_16",	SDLK_WORLD_16		}, /*	= 176,	*/
    {	"SDLK_WORLD_17",	SDLK_WORLD_17		}, /*	= 177,	*/
    {	"SDLK_WORLD_18",	SDLK_WORLD_18		}, /*	= 178,	*/
    {	"SDLK_WORLD_19",	SDLK_WORLD_19		}, /*	= 179,	*/
    {	"SDLK_WORLD_20",	SDLK_WORLD_20		}, /*	= 180,	*/
    {	"SDLK_WORLD_21",	SDLK_WORLD_21		}, /*	= 181,	*/
    {	"SDLK_WORLD_22",	SDLK_WORLD_22		}, /*	= 182,	*/
    {	"SDLK_WORLD_23",	SDLK_WORLD_23		}, /*	= 183,	*/
    {	"SDLK_WORLD_24",	SDLK_WORLD_24		}, /*	= 184,	*/
    {	"SDLK_WORLD_25",	SDLK_WORLD_25		}, /*	= 185,	*/
    {	"SDLK_WORLD_26",	SDLK_WORLD_26		}, /*	= 186,	*/
    {	"SDLK_WORLD_27",	SDLK_WORLD_27		}, /*	= 187,	*/
    {	"SDLK_WORLD_28",	SDLK_WORLD_28		}, /*	= 188,	*/
    {	"SDLK_WORLD_29",	SDLK_WORLD_29		}, /*	= 189,	*/
    {	"SDLK_WORLD_30",	SDLK_WORLD_30		}, /*	= 190,	*/
    {	"SDLK_WORLD_31",	SDLK_WORLD_31		}, /*	= 191,	*/
    {	"SDLK_WORLD_32",	SDLK_WORLD_32		}, /*	= 192,	*/
    {	"SDLK_WORLD_33",	SDLK_WORLD_33		}, /*	= 193,	*/
    {	"SDLK_WORLD_34",	SDLK_WORLD_34		}, /*	= 194,	*/
    {	"SDLK_WORLD_35",	SDLK_WORLD_35		}, /*	= 195,	*/
    {	"SDLK_WORLD_36",	SDLK_WORLD_36		}, /*	= 196,	*/
    {	"SDLK_WORLD_37",	SDLK_WORLD_37		}, /*	= 197,	*/
    {	"SDLK_WORLD_38",	SDLK_WORLD_38		}, /*	= 198,	*/
    {	"SDLK_WORLD_39",	SDLK_WORLD_39		}, /*	= 199,	*/
    {	"SDLK_WORLD_40",	SDLK_WORLD_40		}, /*	= 200,	*/
    {	"SDLK_WORLD_41",	SDLK_WORLD_41		}, /*	= 201,	*/
    {	"SDLK_WORLD_42",	SDLK_WORLD_42		}, /*	= 202,	*/
    {	"SDLK_WORLD_43",	SDLK_WORLD_43		}, /*	= 203,	*/
    {	"SDLK_WORLD_44",	SDLK_WORLD_44		}, /*	= 204,	*/
    {	"SDLK_WORLD_45",	SDLK_WORLD_45		}, /*	= 205,	*/
    {	"SDLK_WORLD_46",	SDLK_WORLD_46		}, /*	= 206,	*/
    {	"SDLK_WORLD_47",	SDLK_WORLD_47		}, /*	= 207,	*/
    {	"SDLK_WORLD_48",	SDLK_WORLD_48		}, /*	= 208,	*/
    {	"SDLK_WORLD_49",	SDLK_WORLD_49		}, /*	= 209,	*/
    {	"SDLK_WORLD_50",	SDLK_WORLD_50		}, /*	= 210,	*/
    {	"SDLK_WORLD_51",	SDLK_WORLD_51		}, /*	= 211,	*/
    {	"SDLK_WORLD_52",	SDLK_WORLD_52		}, /*	= 212,	*/
    {	"SDLK_WORLD_53",	SDLK_WORLD_53		}, /*	= 213,	*/
    {	"SDLK_WORLD_54",	SDLK_WORLD_54		}, /*	= 214,	*/
    {	"SDLK_WORLD_55",	SDLK_WORLD_55		}, /*	= 215,	*/
    {	"SDLK_WORLD_56",	SDLK_WORLD_56		}, /*	= 216,	*/
    {	"SDLK_WORLD_57",	SDLK_WORLD_57		}, /*	= 217,	*/
    {	"SDLK_WORLD_58",	SDLK_WORLD_58		}, /*	= 218,	*/
    {	"SDLK_WORLD_59",	SDLK_WORLD_59		}, /*	= 219,	*/
    {	"SDLK_WORLD_60",	SDLK_WORLD_60		}, /*	= 220,	*/
    {	"SDLK_WORLD_61",	SDLK_WORLD_61		}, /*	= 221,	*/
    {	"SDLK_WORLD_62",	SDLK_WORLD_62		}, /*	= 222,	*/
    {	"SDLK_WORLD_63",	SDLK_WORLD_63		}, /*	= 223,	*/
    {	"SDLK_WORLD_64",	SDLK_WORLD_64		}, /*	= 224,	*/
    {	"SDLK_WORLD_65",	SDLK_WORLD_65		}, /*	= 225,	*/
    {	"SDLK_WORLD_66",	SDLK_WORLD_66		}, /*	= 226,	*/
    {	"SDLK_WORLD_67",	SDLK_WORLD_67		}, /*	= 227,	*/
    {	"SDLK_WORLD_68",	SDLK_WORLD_68		}, /*	= 228,	*/
    {	"SDLK_WORLD_69",	SDLK_WORLD_69		}, /*	= 229,	*/
    {	"SDLK_WORLD_70",	SDLK_WORLD_70		}, /*	= 230,	*/
    {	"SDLK_WORLD_71",	SDLK_WORLD_71		}, /*	= 231,	*/
    {	"SDLK_WORLD_72",	SDLK_WORLD_72		}, /*	= 232,	*/
    {	"SDLK_WORLD_73",	SDLK_WORLD_73		}, /*	= 233,	*/
    {	"SDLK_WORLD_74",	SDLK_WORLD_74		}, /*	= 234,	*/
    {	"SDLK_WORLD_75",	SDLK_WORLD_75		}, /*	= 235,	*/
    {	"SDLK_WORLD_76",	SDLK_WORLD_76		}, /*	= 236,	*/
    {	"SDLK_WORLD_77",	SDLK_WORLD_77		}, /*	= 237,	*/
    {	"SDLK_WORLD_78",	SDLK_WORLD_78		}, /*	= 238,	*/
    {	"SDLK_WORLD_79",	SDLK_WORLD_79		}, /*	= 239,	*/
    {	"SDLK_WORLD_80",	SDLK_WORLD_80		}, /*	= 240,	*/
    {	"SDLK_WORLD_81",	SDLK_WORLD_81		}, /*	= 241,	*/
    {	"SDLK_WORLD_82",	SDLK_WORLD_82		}, /*	= 242,	*/
    {	"SDLK_WORLD_83",	SDLK_WORLD_83		}, /*	= 243,	*/
    {	"SDLK_WORLD_84",	SDLK_WORLD_84		}, /*	= 244,	*/
    {	"SDLK_WORLD_85",	SDLK_WORLD_85		}, /*	= 245,	*/
    {	"SDLK_WORLD_86",	SDLK_WORLD_86		}, /*	= 246,	*/
    {	"SDLK_WORLD_87",	SDLK_WORLD_87		}, /*	= 247,	*/
    {	"SDLK_WORLD_88",	SDLK_WORLD_88		}, /*	= 248,	*/
    {	"SDLK_WORLD_89",	SDLK_WORLD_89		}, /*	= 249,	*/
    {	"SDLK_WORLD_90",	SDLK_WORLD_90		}, /*	= 250,	*/
    {	"SDLK_WORLD_91",	SDLK_WORLD_91		}, /*	= 251,	*/
    {	"SDLK_WORLD_92",	SDLK_WORLD_92		}, /*	= 252,	*/
    {	"SDLK_WORLD_93",	SDLK_WORLD_93		}, /*	= 253,	*/
    {	"SDLK_WORLD_94",	SDLK_WORLD_94		}, /*	= 254,	*/
    {	"SDLK_WORLD_95",	SDLK_WORLD_95		}, /*	= 255,	*/
    {	"SDLK_KP0",		SDLK_KP0		}, /*	= 256,	*/
    {	"SDLK_KP1",		SDLK_KP1		}, /*	= 257,	*/
    {	"SDLK_KP2",		SDLK_KP2		}, /*	= 258,	*/
    {	"SDLK_KP3",		SDLK_KP3		}, /*	= 259,	*/
    {	"SDLK_KP4",		SDLK_KP4		}, /*	= 260,	*/
    {	"SDLK_KP5",		SDLK_KP5		}, /*	= 261,	*/
    {	"SDLK_KP6",		SDLK_KP6		}, /*	= 262,	*/
    {	"SDLK_KP7",		SDLK_KP7		}, /*	= 263,	*/
    {	"SDLK_KP8",		SDLK_KP8		}, /*	= 264,	*/
    {	"SDLK_KP9",		SDLK_KP9		}, /*	= 265,	*/
    {	"SDLK_KP_PERIOD",	SDLK_KP_PERIOD		}, /*	= 266,	*/
    {	"SDLK_KP_DIVIDE",	SDLK_KP_DIVIDE		}, /*	= 267,	*/
    {	"SDLK_KP_MULTIPLY",	SDLK_KP_MULTIPLY	}, /*	= 268,	*/
    {	"SDLK_KP_MINUS",	SDLK_KP_MINUS		}, /*	= 269,	*/
    {	"SDLK_KP_PLUS",		SDLK_KP_PLUS		}, /*	= 270,	*/
    {	"SDLK_KP_ENTER",	SDLK_KP_ENTER		}, /*	= 271,	*/
    {	"SDLK_KP_EQUALS",	SDLK_KP_EQUALS		}, /*	= 272,	*/
    {	"SDLK_UP",		SDLK_UP			}, /*	= 273,	*/
    {	"SDLK_DOWN",		SDLK_DOWN		}, /*	= 274,	*/
    {	"SDLK_RIGHT",		SDLK_RIGHT		}, /*	= 275,	*/
    {	"SDLK_LEFT",		SDLK_LEFT		}, /*	= 276,	*/
    {	"SDLK_INSERT",		SDLK_INSERT		}, /*	= 277,	*/
    {	"SDLK_HOME",		SDLK_HOME		}, /*	= 278,	*/
    {	"SDLK_END",		SDLK_END		}, /*	= 279,	*/
    {	"SDLK_PAGEUP",		SDLK_PAGEUP		}, /*	= 280,	*/
    {	"SDLK_PAGEDOWN",	SDLK_PAGEDOWN		}, /*	= 281,	*/
    {	"SDLK_F1",		SDLK_F1			}, /*	= 282,	*/
    {	"SDLK_F2",		SDLK_F2			}, /*	= 283,	*/
    {	"SDLK_F3",		SDLK_F3			}, /*	= 284,	*/
    {	"SDLK_F4",		SDLK_F4			}, /*	= 285,	*/
    {	"SDLK_F5",		SDLK_F5			}, /*	= 286,	*/
    {	"SDLK_F6",		SDLK_F6			}, /*	= 287,	*/
    {	"SDLK_F7",		SDLK_F7			}, /*	= 288,	*/
    {	"SDLK_F8",		SDLK_F8			}, /*	= 289,	*/
    {	"SDLK_F9",		SDLK_F9			}, /*	= 290,	*/
    {	"SDLK_F10",		SDLK_F10		}, /*	= 291,	*/
    {	"SDLK_F11",		SDLK_F11		}, /*	= 292,	*/
    {	"SDLK_F12",		SDLK_F12		}, /*	= 293,	*/
    {	"SDLK_F13",		SDLK_F13		}, /*	= 294,	*/
    {	"SDLK_F14",		SDLK_F14		}, /*	= 295,	*/
    {	"SDLK_F15",		SDLK_F15		}, /*	= 296,	*/
    {	"SDLK_NUMLOCK",		SDLK_NUMLOCK		}, /*	= 300,	*/
    {	"SDLK_CAPSLOCK",	SDLK_CAPSLOCK		}, /*	= 301,	*/
    {	"SDLK_SCROLLOCK",	SDLK_SCROLLOCK		}, /*	= 302,	*/
    {	"SDLK_RSHIFT",		SDLK_RSHIFT		}, /*	= 303,	*/
    {	"SDLK_LSHIFT",		SDLK_LSHIFT		}, /*	= 304,	*/
    {	"SDLK_RCTRL",		SDLK_RCTRL		}, /*	= 305,	*/
    {	"SDLK_LCTRL",		SDLK_LCTRL		}, /*	= 306,	*/
    {	"SDLK_RALT",		SDLK_RALT		}, /*	= 307,	*/
    {	"SDLK_LALT",		SDLK_LALT		}, /*	= 308,	*/
    {	"SDLK_RMETA",		SDLK_RMETA		}, /*	= 309,	*/
    {	"SDLK_LMETA",		SDLK_LMETA		}, /*	= 310,	*/
    {	"SDLK_LSUPER",		SDLK_LSUPER		}, /*	= 311,	*/
    {	"SDLK_RSUPER",		SDLK_RSUPER		}, /*	= 312,	*/
    {	"SDLK_MODE",		SDLK_MODE		}, /*	= 313,	*/
    {	"SDLK_COMPOSE",		SDLK_COMPOSE		}, /*	= 314,	*/
    {	"SDLK_HELP",		SDLK_HELP		}, /*	= 315,	*/
    {	"SDLK_PRINT",		SDLK_PRINT		}, /*	= 316,	*/
    {	"SDLK_SYSREQ",		SDLK_SYSREQ		}, /*	= 317,	*/
    {	"SDLK_BREAK",		SDLK_BREAK		}, /*	= 318,	*/
    {	"SDLK_MENU",		SDLK_MENU		}, /*	= 319,	*/
    {	"SDLK_POWER",		SDLK_POWER		}, /*	= 320,	*/
    {	"SDLK_EURO",		SDLK_EURO		}, /*	= 321,	*/
    {	"SDLK_UNDO",		SDLK_UNDO		}, /*	= 322,	*/
  };

  char *conv_end;
  unsigned long i;

  if(  str==NULL ) return -1;
  if( *str=='\0' ) return -1;

  if( str[0] == '<' ){				/* <����> �̏ꍇ */
    i = strtoul( &str[1], &conv_end, 0 );
    if( *conv_end == '>' &&
	i < COUNTOF(scancode2key88) ){
      return i;
    }
    return -1;
  }
					/* ��`������ɍ��v����̂�T�� */
  for( i=0; i<COUNTOF(list); i++ ){
    if( strcmp( list[i].name, str ) == 0 ){
      return list[i].val;
    }
  }

  return -1;
}
