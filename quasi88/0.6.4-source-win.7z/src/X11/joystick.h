/*
 *	Joystick �w�b�_�t�@�C��
 */

#ifndef	JOYSTICK_H_INCLUDED
#define	JOYSTICK_H_INCLUDED

void	joystick_init(void);
void	joystick_exit(void);
void	joystick_update(void);


#endif	/* JOYSTICK_H_INCLUDED */
