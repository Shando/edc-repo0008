#ifndef	stderr_file
#define stderr_file stderr
#endif

#include "audio.h"
