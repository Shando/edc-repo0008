#include "mame-quasi88.h"
