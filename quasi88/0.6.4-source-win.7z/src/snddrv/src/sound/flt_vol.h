#ifndef FLT_VOL_H
#define FLT_VOL_H

void flt_volume_set_volume(int num, float volume);

#endif
