#include <math.h>
#include "sndintrf.h"
#include "streams.h"
#include "2203intf.h"
#include "fm.h"


struct ym2203_info
{
	sound_stream *	stream;
	mame_timer *	timer[2];
	void *			chip;
	void *			psg;
	const struct YM2203interface *intf;
};


static void psg_set_clock(void *param, int clock)
{
	struct ym2203_info *info = param;
	ay8910_set_clock_ym(info->psg, clock);
}

static void psg_write(void *param, int address, int data)
{
	struct ym2203_info *info = param;
	ay8910_write_ym(info->psg, address, data);
}

static int psg_read(void *param)
{
	struct ym2203_info *info = param;
	return ay8910_read_ym(info->psg);
}

static void psg_reset(void *param)
{
	struct ym2203_info *info = param;
	ay8910_reset_ym(info->psg);
}

static const struct ssg_callbacks psgintf =
{
	psg_set_clock,
	psg_write,
	psg_read,
	psg_reset
};

/* IRQ Handler */
static void IRQHandler(void *param,int irq)
{
	struct ym2203_info *info = param;
	if(info->intf->handler) info->intf->handler(irq);
}

/* Timer overflow callback from timer.c */
static void timer_callback_2203_0(void *param)
{
	struct ym2203_info *info = param;
	YM2203TimerOver(info->chip,0);
}

static void timer_callback_2203_1(void *param)
{
	struct ym2203_info *info = param;
	YM2203TimerOver(info->chip,1);
}

/* update request from fm.c */
void YM2203UpdateRequest(void *param)
{
	struct ym2203_info *info = param;
	stream_update(info->stream);
}


/* TimerHandler from fm.c */
static void TimerHandler(void *param,int c,int count,double stepTime)
{
	struct ym2203_info *info = param;
	if( count == 0 )
	{	/* Reset FM Timer */
		timer_enable(info->timer[c], 0);
	}
	else
	{	/* Start FM Timer */
		double timeSec = (double)count * stepTime;
		if (!timer_enable(info->timer[c], 1))
			timer_adjust_ptr(info->timer[c], timeSec, 0);
	}
}

static void ym2203_stream_update(void *param, stream_sample_t **inputs, stream_sample_t **buffer, int length)
{
	struct ym2203_info *info = param;
	YM2203UpdateOne(info->chip, buffer[0], length);
}


#if 0		/* QUASI88 */
static void ym2203_postload(void *param)
{
	struct ym2203_info *info = param;
	YM2203Postload(info->chip);
}
#endif		/* QUASI88 */


static void *ym2203_start(int sndindex, int clock, const void *config)
{
	static const struct YM2203interface generic_2203 = { 0 };
	const struct YM2203interface *intf = config ? config : &generic_2203;
	struct ym2203_info *info;

	info = auto_malloc(sizeof(*info));
	memset(info, 0, sizeof(*info));

	info->intf = intf;
	info->psg = ay8910_start_ym(SOUND_YM2203, sndindex, clock, 3, intf->portAread, intf->portBread, intf->portAwrite, intf->portBwrite);
	if (!info->psg) return NULL;

	/* Timer Handler set */
	info->timer[0] = timer_alloc_ptr(timer_callback_2203_0, info);
	info->timer[1] = timer_alloc_ptr(timer_callback_2203_1, info);

	/* stream system initialize */
	info->stream = stream_create(0,1,Machine->sample_rate,info,ym2203_stream_update);

	/* Initialize FM emurator */
#if 0		/* QUASI88 */
	info->chip = YM2203Init(info,sndindex,clock,Machine->sample_rate,TimerHandler,IRQHandler,&psgintf);
#else		/* QUASI88 */
	info->chip = YM2203Init(info,sndindex,clock,Machine->sample_rate,0,0,&psgintf);
#endif		/* QUASI88 */

	state_save_register_func_postload_ptr(ym2203_postload, info);

	if (info->chip)
		return info;

	/* error */
	/* stream close */
	return NULL;
}

static void ym2203_stop(void *token)
{
	struct ym2203_info *info = token;
	YM2203Shutdown(info->chip);
	ay8910_stop_ym(info->psg);
}

static void ym2203_reset(void *token)
{
	struct ym2203_info *info = token;
	YM2203ResetChip(info->chip);
}



READ8_HANDLER( YM2203_status_port_0_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 0); return YM2203Read(info->chip,0); }
READ8_HANDLER( YM2203_status_port_1_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 1); return YM2203Read(info->chip,0); }
READ8_HANDLER( YM2203_status_port_2_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 2); return YM2203Read(info->chip,0); }
READ8_HANDLER( YM2203_status_port_3_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 3); return YM2203Read(info->chip,0); }
READ8_HANDLER( YM2203_status_port_4_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 4); return YM2203Read(info->chip,0); }

READ8_HANDLER( YM2203_read_port_0_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 0); return YM2203Read(info->chip,1); }
READ8_HANDLER( YM2203_read_port_1_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 1); return YM2203Read(info->chip,1); }
READ8_HANDLER( YM2203_read_port_2_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 2); return YM2203Read(info->chip,1); }
READ8_HANDLER( YM2203_read_port_3_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 3); return YM2203Read(info->chip,1); }
READ8_HANDLER( YM2203_read_port_4_r ) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 4); return YM2203Read(info->chip,1); }

WRITE8_HANDLER( YM2203_control_port_0_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 0);
	YM2203Write(info->chip,0,data);
}
WRITE8_HANDLER( YM2203_control_port_1_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 1);
	YM2203Write(info->chip,0,data);
}
WRITE8_HANDLER( YM2203_control_port_2_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 2);
	YM2203Write(info->chip,0,data);
}
WRITE8_HANDLER( YM2203_control_port_3_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 3);
	YM2203Write(info->chip,0,data);
}
WRITE8_HANDLER( YM2203_control_port_4_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 4);
	YM2203Write(info->chip,0,data);
}

WRITE8_HANDLER( YM2203_write_port_0_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 0);
	YM2203Write(info->chip,1,data);
}
WRITE8_HANDLER( YM2203_write_port_1_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 1);
	YM2203Write(info->chip,1,data);
}
WRITE8_HANDLER( YM2203_write_port_2_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 2);
	YM2203Write(info->chip,1,data);
}
WRITE8_HANDLER( YM2203_write_port_3_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 3);
	YM2203Write(info->chip,1,data);
}
WRITE8_HANDLER( YM2203_write_port_4_w )
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 4);
	YM2203Write(info->chip,1,data);
}

WRITE8_HANDLER( YM2203_word_0_w )
{
	if (offset)
		YM2203_write_port_0_w(0,data);
	else
		YM2203_control_port_0_w(0,data);
}

WRITE8_HANDLER( YM2203_word_1_w )
{
	if (offset)
		YM2203_write_port_1_w(0,data);
	else
		YM2203_control_port_1_w(0,data);
}

#if 1		/* QUASI88 */
int	YM2203_timer_over_0(int c) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 0); return YM2203TimerOver(info->chip,c); }
int	YM2203_timer_over_1(int c) { struct ym2203_info *info = sndti_token(SOUND_YM2203, 1); return YM2203TimerOver(info->chip,c); }

void YM2203_set_volume_0(float volume)
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 0);
	stream_set_output_gain(info->stream, 0, volume);
}
void YM2203_set_volume_1(float volume)
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 1);
	stream_set_output_gain(info->stream, 0, volume);
}

void YM2203_AY8910_set_volume_0(float volume)
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 0);
	ay8910_set_volume_ym(info->psg, ALL_8910_CHANNELS, volume);
}
void YM2203_AY8910_set_volume_1(float volume)
{
	struct ym2203_info *info = sndti_token(SOUND_YM2203, 1);
	ay8910_set_volume_ym(info->psg, ALL_8910_CHANNELS, volume);
}
#endif		/* QUASI88 */





/**************************************************************************
 * Generic get_info
 **************************************************************************/

static void ym2203_set_info(void *token, UINT32 state, sndinfo *info)
{
	switch (state)
	{
		/* no parameters to set */
	}
}


void ym2203_get_info(void *token, UINT32 state, sndinfo *info)
{
	switch (state)
	{
		/* --- the following bits of info are returned as 64-bit signed integers --- */

		/* --- the following bits of info are returned as pointers to data or functions --- */
		case SNDINFO_PTR_SET_INFO:						info->set_info = ym2203_set_info;		break;
		case SNDINFO_PTR_START:							info->start = ym2203_start;				break;
		case SNDINFO_PTR_STOP:							info->stop = ym2203_stop;				break;
		case SNDINFO_PTR_RESET:							info->reset = ym2203_reset;				break;

		/* --- the following bits of info are returned as NULL-terminated strings --- */
		case SNDINFO_STR_NAME:							info->s = "YM2203";						break;
		case SNDINFO_STR_CORE_FAMILY:					info->s = "Yamaha FM";					break;
		case SNDINFO_STR_CORE_VERSION:					info->s = "1.0";						break;
		case SNDINFO_STR_CORE_FILE:						info->s = __FILE__;						break;
		case SNDINFO_STR_CORE_CREDITS:					info->s = "Copyright (c) 2004, The MAME Team"; break;
	}
}
