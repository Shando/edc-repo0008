#ifndef PAUSE_H_INCLUDED
#define PAUSE_H_INCLUDED

/************************************************************************/
/* �ꎞ��~���[�h							*/
/************************************************************************/

void	pause_init(void);
void	pause_main(void);



/*----------------------------------------------------------------------
 * �C�x���g�����̑Ώ�
 *----------------------------------------------------------------------*/
void	pause_event_focus_out_when_exec(void);
void	pause_event_focus_in_when_pause(void);
void	pause_event_key_on_esc(void);
void	pause_event_key_on_menu(void);





#endif	/* PAUSE_H_INCLUDED */
