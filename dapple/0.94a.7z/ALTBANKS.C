/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  ALTBANKS: top half of //e banked RAM
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 */

unsigned char bankram1[49152];
unsigned char bankram2[16384];
