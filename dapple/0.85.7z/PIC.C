/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *   Source code for personal use only
 *   If you alter this code, send me a copy: steve@dosius.zzn.com
 *
 * Component:  PIC: Parallel interface
 * Revision:   (0.73) 2002.0914
 * Code was taken from Andrew Gregory's emulator
 */
#include <stdio.h>
#include <string.h>

void xputcs (unsigned char c, unsigned int cx, unsigned int attr);

int tweakpic=0;

#ifdef DEFPAR
char parallel[128] = {DEFPAR};
#else
char parallel[128] = {"dapple.prn"};
#endif

#pragma argsused
void WriteParallel( unsigned int Address, unsigned char Data )
{
    FILE *file;

    switch ( Address & 0x0f )
    {
    case 0x00:
        /* Parallel icon */
        xputcs(166,40,4);
        xputcs(167,41,4);
        /* load output port */
        if(!stricmp(parallel,"prn"))
        {
         fputc(tweakpic?Data:Data&0x7F,stdprn);
         fflush(stdprn);
         xputcs(32,40,4);
         xputcs(32,41,4);
         break;
        }
        file=fopen(parallel,"ab");
        if (file)
        {
         fputc(tweakpic?Data:Data&0x7F,file);
         fclose (file);
        }
        xputcs(32,40,4);
        xputcs(32,41,4);
    }
}
