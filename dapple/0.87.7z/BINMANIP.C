/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *   Source code for personal use only
 *   If you alter this code, send me a copy: steve@dosius.zzn.com
 *
 * Component:  BINMANIP: binary image manipulation tools
 * Revision:   (0.87) 2002.1018
 *             0.33 "LOST KEY WEEKEND"
 */

#include <stdio.h>
#include <errno.h>
#include "m6502.h"
#include "dapple.h"

extern char parallel[128];
extern int hold, flipmethod, dqhdv;

enum DiskTypes
{
    UnknownType = 0,
    RawType     = 1,
    DOSType     = 2
};

  extern struct DriveState
  {
    /* variables for each disk */
    char DiskFN[ 80 ]; /* MS-DOS filename of disk image */
    int DiskFH;        /* MS-DOS file handle of disk image */
    long DiskSize;     /* length of disk image file in bytes */
    enum DiskTypes DiskType; /* Type of disk image */
    int WritePro;      /* 0:write-enabled, !0:write-protected */
    int TrkBufChanged; /* Track buffer has changed */
    int TrkBufOld;     /* Data in track buffer needs updating before I/O */
    int ShouldRecal;
    /* variables used during emulation */
    int Track;    /* 0-70 */
    int Phase;    /* 0- 3 */
    int ReadWP;   /* 0/1  */
    int Active;   /* 0/1  */
    int Writing;  /* 0/1  */
  } DrvSt[ 2 ];

/* Saves RAM image */
int bsave (char *filename)
{
 FILE *file;
 char *errstr;

 file=fopen(filename,"wb");
 gotoxy(1,25);
 if (!file)
 {
  errstr=strerror(errno);
  fprintf(stderr,"%s: %s%c\r",filename,errstr,7);
  return -1;
 }
 fwrite(RAM,1,49152,file);
 fclose(file);
 return 0;
}

/* Saves RAM image, ROM image and processor status */
int immk (char *filename, M6502 *proc)
{
 FILE *file;

 file=fopen(filename,"wb");
 if (!file) return -1;

 fprintf(file,"DAPL%c",gm);
 fwrite(rompath,128,1,file);
 fwrite(&fg,sizeof(fg),1,file);
 fwrite(&bg,sizeof(bg),1,file);
 fwrite(&mono,sizeof(mono),1,file);
 fwrite(&spread,sizeof(spread),1,file);
 fwrite(&smode,sizeof(smode),1,file);
 fwrite(ROM,12,1024,file);
 fwrite(RAM,48,1024,file);
 fwrite(proc,1,sizeof(M6502),file);
 /* 0.21 additions - not to break 0.20 compatibility */
 fwrite(RAMEXT,16,1024,file);
 /* 0.31 additions - not to break 0.2/0.30 compatibility */
 fwrite(DrvSt,sizeof(struct DriveState),2,file);
 /* 0.52 additions - not to break compatibility */
 fwrite(parallel,128,1,file);
 fwrite(&hold,sizeof(hold),1,file);
 /* 0.61 additions - not to break compatibility */
 fwrite(&flipmethod,sizeof(flipmethod),1,file);
 /* 0.67b additions - not to break compatibility */
 fwrite(&dqhdv,sizeof(dqhdv),1,file);
 fclose(file);
 return 0;
}

int imrs (char *filename, M6502 *proc)
{
 FILE *file;
 char uid[4];

 file=fopen(filename,"rb");
 if (!file) return -1;

 fread(uid,4,1,file);
 if (uid[0]!='D' || uid[1]!='A' || uid[2]!='P' || uid[3]!='L')
 {
  return -2;
 }
 gm=fgetc(file);
 fread(rompath,128,1,file);
 fread(&fg,sizeof(fg),1,file);
 fread(&bg,sizeof(bg),1,file);
 fread(&mono,sizeof(mono),1,file);
 fread(&spread,sizeof(spread),1,file);
 fread(&smode,sizeof(smode),1,file);
 fread(ROM,12,1024,file);
 fread(RAM,48,1024,file);
 fread(proc,1,sizeof(M6502),file);
 /* 0.21 additions - not to break 0.20 compatibility */
 fread(RAMEXT,16,1024,file);
 /* 0.31 additions - not to break 0.2/0.30 compatibility */
 fread(DrvSt,sizeof(struct DriveState),2,file);
 /* 0.52 additions - not to break compatibility */
 fread(parallel,128,1,file);
 fread(&hold,sizeof(hold),1,file);
 /* 0.61 additions - not to break compatibility */
 fread(&flipmethod,sizeof(flipmethod),1,file);
 /* 0.67b additions - not to break compatibility */
 fread(&dqhdv,sizeof(dqhdv),1,file);
 fclose(file);
 return 0;
}

int imrsx (char *filename, M6502 *proc)
{
 FILE *file;
 long seekpoint;
 char uid[4];
 struct exeheader
 {
  int sig;
  int xbyte;
  int pages;
  int reloc;
  int headsz;
  int minalloc;
  int maxalloc;
  int ss;
  int sp;
  int checksum;
  int ip;
  int cs;
  int reloctab;
  int ovl;
 } exehdr;
 int tmpctr;
 char *exehdr_ptr=(char*) &exehdr;
 file=fopen(filename,"rb");
 if (!file) return -1;

 for (tmpctr=0; tmpctr<sizeof(exehdr); tmpctr++)
  exehdr_ptr[tmpctr]=fgetc(file);
 seekpoint=exehdr.pages;
 if (exehdr.xbyte!=0) seekpoint--;
 seekpoint<<=9 /* *=512 */; seekpoint+=exehdr.xbyte;

 fseek(file,seekpoint,SEEK_SET);

 fread(uid,4,1,file);
 if (uid[0]!='D' || uid[1]!='A' || uid[2]!='P' || uid[3]!='L')
 {
  return -2;
 }
 gm=fgetc(file);
 fread(ROM,12,1024,file);
 fread(RAM,48,1024,file);
 fread(proc,1,sizeof(M6502),file);
 /* 0.21 additions - not to break 0.20 compatibility */
 fread(RAMEXT,16,1024,file);
 /* 0.31 additions - not to break 0.2/0.30 compatibility */
 fread(DrvSt,sizeof(struct DriveState),2,file);
 /* 0.52 additions - not to break compatibility */
 fread(parallel,128,1,file);
 fread(&hold,sizeof(hold),1,file);
 /* 0.61 additions - not to break compatibility */
 fread(&flipmethod,sizeof(flipmethod),1,file);
 /* 0.67b additions - not to break compatibility */
 fread(&dqhdv,sizeof(dqhdv),1,file);
 fclose(file);
 return 0;
}

int xbload (char *filename)
{
 unsigned short int ca,address,length;
 unsigned long int fl;
 FILE *file;
 char *errstr;

 file=fopen(filename,"rb");
 gotoxy(1,25);
 if (!file)
 {
  errstr=strerror(errno);
  fprintf(stderr,"%s: %s%c\r",filename,errstr,7);
  return -1370;
 }
 fseek(file,0,SEEK_END);
 fl=ftell(file)-4;
 fseek(file,0,SEEK_SET);
 fread(&address,2,1,file);
 fread(&length,2,1,file);

 for (ca=address; fl; fl--, ca++) Wr6502(ca,fgetc(file));

 fclose(file);
 return address;
}

int bload (char *filename)
{
 unsigned short int ca,address,length;
 unsigned long int fl;
 FILE *file;
 char *errstr;

 file=fopen(filename,"rb");
 gotoxy(1,25);
 if (!file)
 {
  errstr=strerror(errno);
  fprintf(stderr,"%s: %s%c\r",filename,errstr,7);
  return -1;
 }
 fseek(file,0,SEEK_END);
 fl=ftell(file)-4;
 fseek(file,0,SEEK_SET);
 fread(&address,2,1,file);
 fread(&length,2,1,file);
 gotoxy(1,25);
 printf("Trns A$%04X,L$%04X (type: CALL %d)",address,length,address);

 /* if (fl+address>49152) return -2; (we have 64K) */

 for (ca=address; fl; fl--, ca++) Wr6502(ca,fgetc(file));

 fclose(file);
 return 0;
}

void savebas (char *filename)
{
 unsigned int startofprog;
 unsigned int endofprog;
 unsigned int lenofprog;
 unsigned int travel;
 FILE        *file;

 startofprog=RAM[103]+256*RAM[104];
 endofprog = RAM[175]+256*RAM[176];

 lenofprog = endofprog-startofprog;

 file=fopen(filename,"wb");
 if (!file) return;

 fwrite(&lenofprog,1,sizeof(lenofprog),file);

 for (travel=startofprog; travel<=endofprog; travel++)
  fwrite(&(RAM[travel]),1,1,file);

 fclose(file);
}

int loadbas(char *filename)
{
 unsigned int startofprog;
 unsigned int endofprog;
 unsigned int lenofprog;
 unsigned int travel;
 char         tmp;
 FILE        *file;

 file=fopen(filename,"rb");
 if (!file) return -1;

 fread(&lenofprog,1,sizeof(lenofprog),file);

 startofprog=RAM[103]+256*RAM[104];
 endofprog = startofprog+lenofprog;
 RAM[175]=endofprog%256;
 RAM[176]=endofprog>>8;

 for (travel=startofprog; travel<=endofprog; travel++)
  fread(&(RAM[travel]),1,1,file);

 fclose(file);
 return 0;
}
