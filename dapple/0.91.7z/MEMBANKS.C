/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  MEMBANKS:  Banked RAM emulation
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 * Some code was taken from Andrew Gregory's emulator
 *
 * Some information regarding 128K memory banking was provided by David
 * Empson and Holger Picker.  The author greatly appreciates your help.
 * Thanks a million!
 */

#include "m6502.h"
#include "dapple.h"

char ROM[16384];
char RAMEXT[16384];
char DISKROM[256], PICROM[256];
int membankon=1;
int sbank, abank;
BANK rbank=BANK0, wbank=BANK0;

/* Andrew Gregory says: */

/*****************************
 *                           *
 * MEMORY BANK SOFT SWITCHES *
 * Slot 0 16K Language Card  *
 *                           *
 *****************************/

/*              ROM RAM1 RAM2
 *  c080 c084 - W         R
 *  c081 c085 - R         W
 *  c082 c086 - RW
 *  c083 c087 -           RW
 *  c088 c08c - W    R
 *  c089 c08d - R    W
 *  c08a c08e - RW
 *  c08b c08f -      RW
 */

static int last0=0, inbank=0;

unsigned char ReadSlot0IO( unsigned int Address )
{
    unsigned char v;
    extern int ROM16K;

    v = 0xff;

    /* keep track of last bank accessed */
    if ( Address >= 0x80 && Address <= 0x83 ) inbank=1;
    if ( Address >= 0x88 && Address <= 0x8b ) inbank=0;
    /* default to write-protected RAM */
    wbank=0;
    /* handle each soft-switch */
    switch ( Address )
    {
    case 0x11:
        v = (inbank*(membankon||ROM16K))?0x8d:0x0d;
        break;
    case 0x12:
        v = (rbank==BANK0&&(membankon||ROM16K))?0x0d:0x8d;
        break;
    case 0x80:
    case 0x83:
    case 0x84:
    case 0x87:
        rbank=BANK2;
        break;
    case 0x88:
    case 0x8b:
    case 0x8c:
    case 0x8f:
        rbank=BANK1;
        break;
    case 0x81:
    case 0x82:
    case 0x85:
    case 0x86:
    case 0x89:
    case 0x8a:
    case 0x8d:
    case 0x8e:
        rbank=BANK0;
        break;
    }
    /* check for double read */
    if ( last0 == Address )
    {
        /* yes - write-enable RAM */
        switch ( Address )
        {
        case 0x81:
        case 0x83:
            wbank=BANK2;
            break;
        case 0x89:
        case 0x8b:
            wbank=BANK1;
            break;
        }
    }
    last0 = Address; /* keep last access */
    return v;
}

int  C01 (char strobe)
{
 return ReadSlot0IO(strobe+0x10);
}

void C08 (char strobe)
{
 ReadSlot0IO(strobe+0x80);
}

#ifdef BANK128
int lcbank128=0;
int mainbank128r=0;
int mainbank128w=0;

byte read128 (unsigned int addr)
{
 if (addr<0x200) return lcbank128?bankram1[addr]:RAM[addr];
              return mainbank128r?bankram1[addr]:RAM[addr];
}

void write128 (unsigned int addr, char val)
{
 extern int store80;

 if (addr<0x200)
 {
  if (lcbank128) bankram1[addr]=val; else RAM[addr]=val;
  return;
 }
 if (addr>=0x4000 && addr<0x6000 && store80)
 {
  /* FIXME: what should this do if memory is banked? */
  bankram1[addr-0x2000]=val; /* write to aux page 1 */
  return;
 }
 if (mainbank128w) bankram1[addr]=val; else RAM[addr]=val;
}
#endif

char readbank (unsigned int addr)
{
 extern int ROM16K;

 if (!(membankon||ROM16K)) return ROM[addr];
 if (rbank==BANK0) return ROM[addr];
 if (rbank==BANK1) return RAMEXT[addr];
 if (rbank==BANK2)
 {
#ifdef BANK128
  char *ptr;

  ptr=lcbank128?bankram2:RAMEXT;
  if (addr<4096) return ptr[addr+12288];
  return ptr[addr];
#else
  if (addr<4096) return RAMEXT[addr+12288];
  return RAMEXT[addr];
#endif
 }
 return 96;
}

void writebank (unsigned int addr, char val)
{
 extern int ROM16K;
#ifdef BANK128
 char *ptr;

 ptr=lcbank128?bankram2:RAMEXT;
#endif
 if (!(membankon||ROM16K)) return; /* ROM */
 if (wbank==BANK0) return; /* ROM */
#ifdef BANK128
 if (wbank==BANK1) {ptr[addr]=val; return;}
 if (wbank==BANK2)
 {
  if (addr<4096) ptr[addr+12288]=val; else ptr[addr]=val;
  return;
 }
#else
 if (wbank==BANK1) {RAMEXT[addr]=val; return;}
 if (wbank==BANK2)
 {
  if (addr<4096) RAMEXT[addr+12288]=val; else RAMEXT[addr]=val;
  return;
 }
#endif
}

/* Incomplete code: to support 16K BIOS banking. ][ and ][+ don't need it */
byte SlotCxROM;
byte SlotC3ROM;

byte ReadAltROMIO( word Address ) /* $C015 $C017 */
{
    byte v;

    switch ( Address )
    {
    case 0x15:
        /* Read SLOTCXROM switch */
        v = SlotCxROM;
        break;
    case 0x17:
        /* Read SLOTC3ROM switch */
        v = SlotC3ROM;
        break;
    }
    return v;
}

#pragma argsused /* $C006 $C007 $C00A $C00B */
void WriteAltROMIO( word Address, byte Data )
{
    switch ( Address )
    {
    case 0x06:
        /* SLOTCXROM Off */
        SlotCxROM = 0x0d;
        sbank = 0; /* normal mode */
        break;
    case 0x07:
        /* SLOTCXROM On */
        SlotCxROM = 0x8d;
        /* only allow slot ROM changes on a //e */
        sbank = 1; /* ROM mode */
        break;
    case 0x0a:
        /* SLOTC3ROM Off */
        SlotC3ROM = 0x0d;
        break;
    case 0x0b:
        /* SLOTC3ROM On */
        SlotC3ROM = 0x8d;
        break;
    }
    if ( SlotCxROM == 0x0d && SlotC3ROM == 0x8d )
        abank = 0; /* normal mode */
    else
        abank = 1; /* ROM mode */
}
