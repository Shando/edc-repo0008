/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  PSET:  pixel manipulation functions (replaces BGI)
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 *
 * Foreign character translation derived from experimentation and Epson
 * RX-80 documentation.
 */

#include <dos.h>

static union REGS regs;
#define VIDEO int86(16,&regs,&regs);

extern int fg, bg;
extern char AppleFont[2048];

typedef enum {English, French} Charset;
extern Charset charmode;

static char xchr[11][12]={
 {'#', '$', '@', '[', '\\',']', '^', '`', '{', '|', '}', '~'}, /* USA       */
 {'#', '$', 133, 248, 135, 232, '^', '`', 130, 151, 138, 249}, /* France    */
 {'#', '$', 232, 142, 143, 144, '^', '`', 132, 148, 129, 225}, /* Germany   */
 {156, '$', '@', '[', '\\',']', '^', '`', '{', '|', '}', '~'}, /* UK        */
 {'#', '$', '@', 146, 242, 143, '^', '`', 145, 243, 134, '~'}, /* Denmark 1 */
 {'#', 241, 144, 142, 153, 143, 154, 130, 132, 148, 134, 129}, /* Sweden    */
 {'#', '$', '@', 248, '\\',130, '^', 151, 133, 149, 138, 141}, /* Italy     */
 {158, '$', '@', 173, 165, 168, '^', '`', 249, 164, '}', '~'}, /* Spain     */
 {'#', '$', '@', '[', 157, ']', '^', '`', '{', '|', '}', '~'}, /* Japan     */
 {'#', 241, 144, 146, 242, 143, 154, 130, 145, 243, 134, 129}, /* Norway    */
 {'#', '$', 144, 146, 242, 143, 154, 130, 145, 243, 134, 129}, /* Denmark 2 */
};

void pset (unsigned int x, unsigned int y, unsigned int c)
{
 static char far *screen=MK_FP(0xA000,0x0000);

 screen[(y*320)+x]=c;
}

unsigned int point (unsigned int x, unsigned int y)
{
 static char far *screen=MK_FP(0xA000,0x0000);

 return screen[(y*320)+x];
}

void gmode (unsigned int mode)
{
 regs.x.ax=mode%256;
 VIDEO;
}

void gputc (char c, unsigned int cx, unsigned int cy)
{
 int Y,x,y,FG,BG;
 char ch;

 if (bg&8) {FG=254; BG=255;} else {FG=fg; BG=bg;}
 if (FG==7) FG=15; else if (BG==7) BG=15;

 x=(cx-1)*7+20;
 y=(cy-1)*8;

 for (Y=y; Y<y+8; Y++)
 {
  ch=AppleFont[(c*8+(Y-y))];
  pset (x,Y,(ch&128)?FG:BG);
  pset (x+1,Y,(ch&64)?FG:BG);
  pset (x+2,Y,(ch&32)?FG:BG);
  pset (x+3,Y,(ch&16)?FG:BG);
  pset (x+4,Y,(ch&8)?FG:BG);
  pset (x+5,Y,(ch&4)?FG:BG);
  pset (x+6,Y,(ch&2)?FG:BG);
 }
}

void xputc (unsigned char c, unsigned int cx, unsigned int cy, unsigned int attr)
{
 int Y,x,y,FG,BG;
 char ch;
 FG=attr%256;
 BG=attr>>8;

 x=(cx-1)*7+20;
 y=(cy-1)*8;

 /* Nationalizations */
 if (cy<25)
 {
  if (c=='#') c=xchr[charmode][0];
  if (c=='$') c=xchr[charmode][1];
  if (c=='@') c=xchr[charmode][2];
  if (c=='[') c=xchr[charmode][3];
  if (c=='\\') c=xchr[charmode][4];
  if (c==']') c=xchr[charmode][5];
  if (c=='^') c=xchr[charmode][6];
  if (c=='`') c=xchr[charmode][7];
  if (c=='{') c=xchr[charmode][8];
  if (c=='|') c=xchr[charmode][9];
  if (c=='}') c=xchr[charmode][10];
  if (c=='~') c=xchr[charmode][11];
 }

 for (Y=y; Y<y+8; Y++)
 {
  ch=AppleFont[(c*8+(Y-y))];
  pset (x,Y+4,(ch&128)?FG:BG);
  pset (x+1,Y+4,(ch&64)?FG:BG);
  pset (x+2,Y+4,(ch&32)?FG:BG);
  pset (x+3,Y+4,(ch&16)?FG:BG);
  pset (x+4,Y+4,(ch&8)?FG:BG);
  pset (x+5,Y+4,(ch&4)?FG:BG);
  pset (x+6,Y+4,(ch&2)?FG:BG);
 }
}

void xputcs (unsigned char c, unsigned int cx, unsigned int attr)
{
 int Y,x,y,FG,BG;
 char ch;
 FG=attr%256;
 BG=attr>>8;

 x=cx*7;
 y=192;

 for (Y=y; Y<y+8; Y++)
 {
  ch=AppleFont[(c*8+(Y-y))];
  pset (x,Y,(ch&128)?FG:BG);
  pset (x+1,Y,(ch&64)?FG:BG);
  pset (x+2,Y,(ch&32)?FG:BG);
  pset (x+3,Y,(ch&16)?FG:BG);
  pset (x+4,Y,(ch&8)?FG:BG);
  pset (x+5,Y,(ch&4)?FG:BG);
  pset (x+6,Y,(ch&2)?FG:BG);
 }
}

