/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  JOYSTICK:  emulate Apple joystick through PC game port
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 * Some code was taken from Andrew Gregory's emulator
 */

#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include "m6502.h"
#include "dapple.h"

unsigned int GameMinX = 26, GameMinY = 26;
unsigned int GameMaxX = 27, GameMaxY = 27;
unsigned long ClockX, ClockY;                /* Timeouts for 556 timer */
unsigned int LeftAltDown = 0, RightAltDown = 0;

int joyx(void)
{
 int readval;
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0x0001;
 int86(0x15,&regs,&regs);
 readval=regs.x.ax;
// if (readval<GameMinX) GameMinX=readval;
// if (readval>GameMaxX) GameMaxX=readval;
// return (readval-GameMinX)*256/(GameMaxX-GameMinX);
 return readval;
/*    ClockX = ClockTick +7 + 11 * ReadX; */
}

int joyy(void)
{
 int readval;
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0x0001;
 int86(0x15,&regs,&regs);
 readval=regs.x.bx;
// if (readval<GameMinY) GameMinY=readval;
// if (readval>GameMaxY) GameMaxY=readval;
// return (readval-GameMinY)*256/(GameMaxY-GameMinY);
 return readval;
/*    ClockY = ClockTick +7 + 11 * ReadY; */
}

int joya(void)
{
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0;
 int86(0x15,&regs,&regs); /* al */
 return ((regs.h.al&0x10)==0)?255:0;
}

int joyb(void)
{
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0;
 int86(0x15,&regs,&regs); /* al */
 return ((regs.h.al&0x20)==0)?255:0;
}

int vjoyx(void)
{
 int readval;
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0x0001;
 int86(0x15,&regs,&regs);
 readval=regs.x.ax;
 if (readval<GameMinX) GameMinX=readval;
 if (readval>GameMaxX) GameMaxX=readval;
 return (readval-GameMinX)*256/(GameMaxX-GameMinX);
/*    ClockX = ClockTick +7 + 11 * ReadX; */
}

int vjoyy(void)
{
 int readval;
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0x0001;
 int86(0x15,&regs,&regs);
 readval=regs.x.bx;
 if (readval<GameMinY) GameMinY=readval;
 if (readval>GameMaxY) GameMaxY=readval;
 return (readval-GameMinY)*256/(GameMaxY-GameMinY);
/*    ClockY = ClockTick +7 + 11 * ReadY; */
}

void calibrate(void)
{
 int x=0,y=0;

 while (!(joya()||joyb()) || (x<123 || x>133 || y<123 || y>133))
 {
  x=vjoyx();
  y=vjoyy();
  if (x<123 || x>133 || y<123 || y>133)
   printf("\rMove the joystick to all extremes.");
  else printf("\rRelease the joystick and press a button.");
 }
 printf ("\r%-75c",32);
}
