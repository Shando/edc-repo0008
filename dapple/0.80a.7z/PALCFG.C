/* This is incomplete, unused code. */

#include <dos.h>
#include <string.h>
#include "dapple.h"

char colnames[0x30][24]={ /* Definitions according to Mobocolor */
/*....|....1....|....2...*/
 "Lo-res $0 (Black)",
 "Lo-res $1 (Red)",
 "Lo-res $2 (Blue)",
 "Lo-res $3 (Magenta)",
 "Lo-res $4 (Cyan)",
 "Lo-res $5 (Grey 1)",
 "Lo-res $6 (Green)",
 "Lo-res $7 (Lt Blue)",
 "Lo-res $8 (Orange)",
 "Lo-res $9 (Lt Magenta)",
 "Lo-res $A (Grey 2)",
 "Lo-res $B (Lt Red)",
 "Lo-res $C (Lt Green)",
 "Lo-res $D (Yellow)",
 "Lo-res $E (Lt Cyan)",
 "Lo-res $F (White)",
 "Hi-res $0/4 (Black)",
 "Hi-res $1   (Green)",
 "Hi-res $2   (Violet)",
 "Hi-res $3/7 (White)",
 "Unused $4",
 "Hi-res $5   (Orange)",
 "Hi-res $6   (Blue)",
 "Unused $7",
 "Text Pal 1 BG (Black)",
 "Text Pal 1 FG (White)",
 "Reserved",
 "Reserved",
 "Text Pal 2 BG (Black)",
 "Text Pal 2 FG (Green)",
 "Reserved",
 "Reserved",
 "Text Pal 3 BG (Black)",
 "Text Pal 3 FG (Amber)",
 "Reserved",
 "Reserved",
 "Drive Light Off (Grey)",
 "Drive Light On  (Red)",
 "Unused",
 "Printer In Use (Red)",
 "Disassembler (Blue)",
 "CPU Flags (Cyan)",
 "Unused",
 "Unused",
 "HDD Light Off (Grey)",
 "HDD Light On  (Grey)",
 "Disk Status (Magenta)",
 "Printer Error (Red)"
};

void xputs (char *s, int cx, int cy, int attr)
{
 int x;

 for (x=0; x<strlen(s); x++) xputc(s[x],cx+x,cy,attr);
}

void xcls (void)
{
 memset (MK_FP(0xA000,0x0000),0,64000);
}

void setrgb (unsigned char attr)
{
 gmode(0x13);
 char pstr[3]={0,0,0};

 xcls();
 /*      ....|....1....|....2....|....3....|....4 */
 xputs ("            Set Palette $               ",1,1,COL_TXT_WHT1+(256*COL_TXT_WHT0));
 sprintf(pstr,"%02X",attr);
 xputs (pstr,26,1,COL_TXT_WHT1+(256*COL_TXT_WHT0));
 xputs ("Name:",2,3,COL_TXT_WHT1+(256*COL_TXT_WHT0));
 xputs (colnames[attr],9,3,COL_TXT_WHT1+(256*COL_TXT_WHT0));

}

