/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  DEBUG: Dapple's debug/tracer (F5)
 * Revision:   (Diana 0.99) 2002.1202
 *             0.33 "LOST KEY WEEKEND"
 */

#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "dapple.h"
#include "m6502.h"

/** Debug6502() **********************************************/
/** This function should exist if DEBUG is #defined. When   **/
/** Trace!=0, it is called after each command executed by   **/
/** the CPU, and given the 6502 registers. Emulation exits  **/
/** if Debug6502() returns 0.                               **/
/*************************************************************/
byte Debug6502(M6502 *R);

/////////////////////////////////////////////////////////////////////////////

/* Information on the opcodes is defined in two components:
   the name of the opcode in printf() format, and a method used to determine
   what variables should be fed into the printf() and how far the IP should
   be pushed ahead.
   Opcodes are given in the format used by the Apple ][ disassembler. */
   
typedef enum {Nothing, Byte, Word, Relative} NumberSize;

typedef struct
{
 char Description[20];
 NumberSize Method;
}
Opcode;

Opcode Ops[256]=
{
 "BRK",Nothing,                 /* $00 */
 "ORA ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "TSB $%02X",Byte,
 "ORA $%02X",Byte,
 "ASL $%02X",Byte,
 "???",Nothing,
 "PHP",Nothing,                 /* $08 */
 "ORA #$%02X",Byte,
 "ASL",Nothing,
 "???",Nothing,
 "TSB $%04X",Word,
 "ORA $%04X",Word,
 "ASL $%04X",Word,
 "???",Nothing,
 "BPL $%04X",Relative,          /* $10 */
 "ORA ($%02X),Y",Byte,
 "ORA ($%02X)",Byte,
 "???",Nothing,
 "TRB $%02X",Byte,
 "ORA $%02X,X",Byte,
 "ASL $%02X,X",Byte,
 "???",Nothing,
 "CLC",Nothing,                 /* $18 */
 "ORA $%04X,Y",Word,
 "INC",Nothing,
 "???",Nothing,
 "TRB $%04X",Word,
 "ORA $%04X,X",Word,
 "ASL $%04X,X",Word,
 "???",Nothing,
 "JSR $%04X",Word,              /* $20 */
 "AND ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "BIT $%02X",Byte,
 "AND $%02X",Byte,
 "ROL $%02X",Byte,
 "???",Nothing,
 "PLP",Nothing,                 /* $28 */
 "AND #$%02X",Byte,
 "ROL",Byte,
 "???",Nothing,
 "BIT $%04X",Word,
 "AND $%04X",Word,
 "ROL $%04X",Word,
 "???",Nothing,
 "BMI $%04X",Relative,          /* $30 */
 "AND ($%02X),Y",Byte,
 "AND ($%02X)",Byte,
 "???",Nothing,
 "BIT $%02X,X",Byte,
 "AND $%02X,X",Byte,
 "ROL $%02X,X",Byte,
 "???",Nothing,
 "SEC",Nothing,                 /* $38 */
 "AND $%04X,Y",Word,
 "DEC",Nothing,
 "???",Nothing,
 "BIT $%04X,X",Word,
 "AND $%04X,X",Word,
 "ROL $%04X,X",Word,
 "???",Nothing,
 "RTI",Nothing,                 /* $40 */
 "EOR ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "EOR $%02X",Byte,
 "LSR $%02X",Byte,
 "???",Nothing,
 "PHA",Nothing,                 /* $48 */
 "EOR #$%02X",Byte,
 "LSR",Nothing,
 "???",Nothing,
 "JMP $%04X",Word,
 "EOR $%04X",Word,
 "LSR $%04X",Word,
 "???",Nothing,
 "BVC $%04X",Relative,          /* $50 */
 "EOR ($%02X),Y",Byte,
 "EOR ($%02X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "EOR $%02X,X",Byte,
 "LSR $%02X,X",Byte,
 "???",Nothing,
 "CLI",Nothing,                 /* $58 */
 "EOR $%04X,Y",Word,
 "PHY",Nothing,
 "???",Nothing,
 "???",Nothing,
 "EOR $%04X,X",Word,
 "LSR $%04X,X",Word,
 "???",Nothing,
 "RTS",Nothing,                 /* $60 */
 "ADC ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "STZ $%02X",Byte,
 "ADC $%02X",Byte,
 "ROR $%02X",Byte,
 "???",Nothing,
 "PLA",Nothing,                 /* $68 */
 "ADC #$%02X",Byte,
 "ROR",Nothing,
 "???",Nothing,
 "JMP ($%04X)",Word,
 "ADC $%04X",Word,
 "ROR $%04X",Word,
 "???",Nothing,
 "BVS $%04X",Relative,          /* $70 */
 "ADC ($%02X),Y",Byte,
 "ADC ($%02X)",Byte,
 "???",Nothing,
 "STZ $%02X,X",Byte,
 "ADC $%02X,X",Byte,
 "ROR $%02X,X",Byte,
 "???",Nothing,
 "SEI",Nothing,                 /* $78 */
 "ADC $%04X,Y",Word,
 "PLY",Nothing,
 "???",Nothing,
 "JMP ($%04X,X)",Word,
 "ADC $%04X,X",Word,
 "ROR $%04X,X",Word,
 "???",Nothing,
 "BRA $%04X",Relative,          /* $80 */
 "STA ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "STY $%02X",Byte,
 "STA $%02X",Byte,
 "STX $%02X",Byte,
 "???",Nothing,
 "DEY",Nothing,                 /* $88 */
 "BIT #$%02X",Byte,
 "TXA",Nothing,
 "???",Nothing,
 "STY $%04X",Word,
 "STA $%04X",Word,
 "STX $%04X",Word,
 "???",Nothing,
 "BCC $%04X",Relative,          /* $90 */
 "STA ($%02X),Y",Byte,
 "STA ($%02X)",Byte,
 "???",Nothing,
 "STY $%02X,X",Byte,
 "STA $%02X,X",Byte,
 "STX $%02X,Y",Byte,
 "???",Nothing,
 "TYA",Nothing,                 /* $98 */
 "STA $%04X,Y",Word,
 "TXS",Nothing,
 "???",Nothing,
 "STZ $%04X",Word,
 "STA $%04X,X",Word,
 "STZ $%04X,X",Word,
 "???",Nothing,
 "LDY #$%02X",Byte,             /* $A0 */
 "LDA ($%02X,X)",Byte,
 "LDX #$%02X",Byte,
 "???",Nothing,
 "LDY $%02X",Byte,
 "LDA $%02X",Byte,
 "LDX $%02X",Byte,
 "???",Nothing,
 "TAY",Nothing,                 /* $A8 */
 "LDA #$%02X",Byte,
 "TAX",Nothing,
 "???",Nothing,
 "LDY $%04X",Word,
 "LDA $%04X",Word,
 "LDX $%04X",Word,
 "???",Nothing,
 "BCS $%04X",Relative,          /* $B0 */
 "LDA ($%02X),Y",Byte,
 "LDA ($%02X)",Byte,
 "???",Nothing,
 "LDY $%02X,X",Byte,
 "LDA $%02X,X",Byte,
 "LDX $%02X,Y",Byte,
 "???",Nothing,
 "CLV",Nothing,                 /* $B8 */
 "LDA $%04X,Y",Word,
 "TSX",Nothing,
 "???",Nothing,
 "LDY $%04X,X",Word,
 "LDA $%04X,X",Word,
 "LDX $%04X,Y",Word,
 "???",Nothing,
 "CPY #$%02X",Byte,             /* $C0 */
 "CMP ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "CPY $%02X",Byte,
 "CMP $%02X",Byte,
 "DEC $%02X",Byte,
 "???",Nothing,
 "INY",Nothing,                 /* $C8 */
 "CMP #$%02X",Byte,
 "DEX",Nothing,
 "???",Nothing,
 "CPY $%04X",Word,
 "CMP $%04X",Word,
 "DEC $%04X",Word,
 "???",Nothing,
 "BNE $%04X",Relative,          /* $D0 */
 "CMP ($%02X),Y",Byte,
 "CMP ($%02X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "CMP $%02X,X",Byte,
 "DEC $%02X,X",Byte,
 "???",Nothing,
 "CLD",Nothing,                 /* $D8 */
 "CMP $%04X,Y",Word,
 "PHX",Nothing,
 "???",Nothing,
 "???",Nothing,
 "CMP $%04X,X",Word,
 "DEC $%04X,X",Word,
 "???",Nothing,
 "CPX #$%02X",Byte,             /* $E0 */
 "SBC ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "CPX $%02X",Byte,
 "SBC $%02X",Byte,
 "INC $%02X",Byte,
 "???",Nothing,
 "INX",Nothing,                 /* $E8 */
 "SBC #$%02X",Byte,
 "NOP",Nothing,
 "???",Nothing,
 "CPX $%04X",Word,
 "SBC $%04X",Word,
 "INC $%04X",Word,
 "???",Nothing,
 "BEQ $%04X",Relative,          /* $F0 */
 "SBC ($%02X),Y",Byte,
 "SBC ($%02X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "SBC $%02X,X",Byte,
 "INC $%02X,X",Byte,
 "???",Nothing,
 "SED",Nothing,                 /* $F8 */
 "SBC $%04X,Y",Word,
 "PLX",Nothing,
 "???",Nothing,
 "???",Nothing,
 "SBC $%04X,X",Word,
 "INC $%04X,X",Word,
 "???",Nothing
};

/* dasm()
   Disassemble one opcode:
   given a buffer in which to copy the disassembly and the current IP,
   returns the new IP. */
   
static int dasm(char *output, unsigned short int address)
{
 /* Addresses used by branch ops are relative to address+2, signed char */
 unsigned int num;
 signed char Rel;
 unsigned int p1,p2;
 unsigned int op;
 char Desc[128];

 /* We must keep the compiler from promoting signed values, so often we
    explicitly cast to unsigned char. */
 op=(unsigned char)Rd6502(address);

 if (Ops[op].Method==Nothing) /* Just the opcode */
 {
  sprintf (output,"%04X:  %02X            %s",address,op,Ops[op].Description);
  return address+1;
 }
 if (Ops[op].Method==Byte) /* Two byte opcode */
 {
  sprintf (Desc,Ops[op].Description,(unsigned char)(p1=Rd6502(address+1)));
  sprintf (output,"%04X:  %02X%02X          %s",address,op,(unsigned char)p1,Desc);
  return address+2;
 }
 if (Ops[op].Method==Word) /* Three byte opcode */
 {
  p1=(unsigned char)Rd6502(address+1);
  p2=(unsigned char)Rd6502(address+2);
  num=p1+(p2<<8); /* Construct low-endian number */
  sprintf (Desc,Ops[op].Description,num);
  sprintf (output,"%04X:  %02X%02X%02X        %s",address,op,p1,p2,Desc);
  return address+3;
 }
 if (Ops[op].Method==Relative) /* Two byte opcode */
 {
  /* This is a little tricky... The relative address is a signed char. */
  Rel=Rd6502(address+1);
  num=(address+2);
  num+=Rel; /* this CAN subtract; remember a+(-b) is the same as a-b */
  sprintf (Desc,Ops[op].Description,(unsigned int)num);
  sprintf (output,"%04X:  %02X%02X          %s",address,op,(unsigned char)Rel,Desc);
  return address+2;
 }
 /* error : should never reach this point but placate compilers */
 return -1;
}

byte Debug6502 (M6502 *R)
{
 int exitcode,I,J;
 char input[128], dasmop[128];

 gmode(3); clrscr(); _setcursortype(_NORMALCURSOR);

 exitcode=1;

 gotoxy(1,1);

vtop:
 dasm(dasmop,R->PC.W);

 printf ("%s\n",dasmop);
 printf ("       A=%02X X=%02X Y=%02X S=%02X P=%02X M=%02X [%c%c%c%c%c%c%c%c]\n",
         R->A,R->X,R->Y,R->S,R->P,Rd6502(R->PC.W),
         R->P&N_FLAG?'N':'n',
         R->P&V_FLAG?'V':'v',
         R->P&R_FLAG?'R':'r',
         R->P&B_FLAG?'B':'b',
         R->P&D_FLAG?'D':'d',
         R->P&I_FLAG?'I':'i',
         R->P&Z_FLAG?'Z':'z',
         R->P&C_FLAG?'C':'c');
 printf ("SP=01%02X -> %02X %02X %02X\n",
         R->S,
         Rd6502(0x0100+(byte)(R->S+1)),
         Rd6502(0x0100+(byte)(R->S+2)),
         Rd6502(0x0100+(byte)(R->S+3)));
 printf ("(? for help)\n");
top:
 printf ("{65C02} ");
 fgets (input,128,stdin);
 input[strlen(input)-1]=0;
 if (!*input) goto btm;
 if (input[0]=='q' || input[0]=='Q')
 {
  exitcode=0;
  goto btm;
 }
 if (input[0]=='?' || input[0]=='h' || input[0]=='H')
 {
  printf ("\
*** Dapple 65C02 Debugger ][ - Built-in Commands ***\n\
<CR>       : Break at the next instruction\n\
= <addr>   : Break at addr\n\
+ <offset> : Break at PC + offset\n\
c          : Continue without break\n\
j <addr>   : Continue from addr\n\
m <addr>   : Memory dump at addr\n\
d <addr>   : Disassembly at addr\n\
v          : Show interrupt vectors\n\
?,h        : Show this help text\n\
q          : Exit to DOS\n\
");
  goto top;
 }
 switch (input[0])
 {
  case '=':
   if(strlen(input)>=2)
   {
    sscanf(input+1,"%hX",&(R->Trap));
    R->Trace=0;
    goto btm;
   }
   break;
  case '+':
   if(strlen(input)>=2)
   {
    sscanf(input+1,"%hX",&(R->Trap));
    R->Trap+=R->PC.W;R->Trace=0;
    goto btm;
   }
   break;
  case 'J': case 'j':
   if(strlen(input)>=2)
   {
    sscanf(input+1,"%hX",&(R->PC.W));
    R->Trace=0;
    goto btm;
   }
   break;
  case 'C': case 'c':
   R->Trap=0xFFFF;
   R->Trace=0;
   goto btm;
  case 'V':
   puts("\n65C02 Interrupt Vectors:");
   printf("[$FFFC] Reset: $%04X\n",Rd6502(0xFFFC)+256*Rd6502(0xFFFD));
   printf("[$FFFE] IRQ:   $%04X\n",Rd6502(0xFFFE)+256*Rd6502(0xFFFF));
   printf("[$FFFA] NMI:   $%04X\n",Rd6502(0xFFFA)+256*Rd6502(0xFFFB));
   goto top;
// break;
  case 'M': case 'm':
  {
   word Addr;

   if(strlen(input)>1)
    sscanf(input+1,"%hX",&Addr);
   else
    Addr=R->PC.W;
   puts("");
   for(J=0;J<16;J++)
   {
    printf("%04X: ",Addr);
    for(I=0;I<16;I++,Addr++)
     printf("%02X ",Rd6502(Addr));
    printf(" | ");Addr-=16;
    for(I=0;I<16;I++,Addr++)
     putchar(isprint(Rd6502(Addr))? Rd6502(Addr):'.');
     puts("");
    }
   }
   goto top;
// break;
  case 'D': case 'd':
  {
   word Addr;

   if(strlen(input)>1)
    sscanf(input+1,"%hX",&Addr);
   else
    Addr=R->PC.W;
   puts("");
   for(J=0;J<16;J++)
   {
    Addr+=dasm(input,Addr);
    printf ("%s\n",input);
   }
  }
  goto top;
//break;
 }

 printf ("Error: Invalid command (? for help)\n");
 
btm:
 clrscr(); opengraph(); redrawtext(1+(0!=(gm&PG2)));

 return exitcode;
}
