/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  PIC: Parallel interface
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 * Code was taken from Andrew Gregory's emulator
 */

#include <stdio.h>
#include <string.h>
void pset (unsigned int x, unsigned int y, unsigned int c);
#define COL_DRV_OFF  0x24
#define COL_DRV_ON   0x25

int tweakpic=0;

#ifdef DEFPAR
char parallel[128] = {DEFPAR};
#else
char parallel[128] = {"dapple.prn"};
#endif

#pragma argsused
void WriteParallel( unsigned int Address, unsigned char Data )
{
    FILE *file;

    switch ( Address & 0x0f )
    {
    case 0x00:
        pset(316,199,COL_DRV_ON);
        /* load output port */
        if(!stricmp(parallel,"prn"))
        {
         fputc(tweakpic?Data:Data&0x7F,stdprn);
         fflush(stdprn);
         pset(316,199,0);
         break;
        }
        file=fopen(parallel,"ab");
        if (file)
        {
         fputc(tweakpic?Data:Data&0x7F,file);
         fclose (file);
        }
        pset(316,199,0);
    }
}
