/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *   Source code for personal use only
 *   If you alter this code, send me a copy: steve@dosius.zzn.com
 *
 * Component:  Z80MMU: Z80 memory management unit
 * Revision:   (0.72) 2002.0912
 *             0.33 "LOST KEY WEEKEND"
 */

/* This is prototype code not used by Dapple */

#include "z80.h"
#include "dapple.h"

/* from m6502.h */

#define INT65_NONE  0            /* No interrupt required      */
#define INT65_IRQ   1            /* Standard IRQ interrupt     */
#define INT65_NMI   2            /* Non-maskable interrupt     */
#define INT65_QUIT  3            /* Exit the emulation         */

typedef struct
{
  byte A,P,X,Y,S;     /* CPU registers and program counter   */
  pair PC;

  int IPeriod,ICount; /* Set IPeriod to number of CPU cycles */
                      /* between calls to Loop6502()         */
  byte IRequest;      /* Set to the INT_IRQ when pending IRQ */
  byte AfterCLI;      /* Private, don't touch                */
  int IBackup;        /* Private, don't touch                */
  void *User;         /* Arbitrary user data (ID,RAM*,etc.)  */
  byte TrapBadOps;    /* Set to 1 to warn of illegal opcodes */
  word Trap;          /* Set Trap to address to trace from   */
  byte Trace;         /* Set Trace=1 to start tracing        */
} M6502;
byte Loop6502(register M6502 *R);
void Wr6502(register word Addr,register byte Value);
byte Rd6502(register word Addr);

void Z80_WRMEM(dword Addr,byte Value)
{
 unsigned int laddr;

 laddr=Addr&0x0FFF;
 switch (Addr&0xF000)
 {
  case 0x0000: Wr6502(laddr+0x1000,Value); break;
  case 0x1000: Wr6502(laddr+0x2000,Value); break;
  case 0x2000: Wr6502(laddr+0x3000,Value); break;
  case 0x3000: Wr6502(laddr+0x4000,Value); break;
  case 0x4000: Wr6502(laddr+0x5000,Value); break;
  case 0x5000: Wr6502(laddr+0x6000,Value); break;
  case 0x6000: Wr6502(laddr+0x7000,Value); break;
  case 0x7000: Wr6502(laddr+0x8000,Value); break;
  case 0x8000: Wr6502(laddr+0x9000,Value); break;
  case 0x9000: Wr6502(laddr+0xA000,Value); break;
  case 0xA000: Wr6502(laddr+0xB000,Value); break;
  case 0xB000: Wr6502(laddr+0xD000,Value); break;
  case 0xC000: Wr6502(laddr+0xE000,Value); break;
  case 0xD000: Wr6502(laddr+0xF000,Value); break;
  case 0xE000: Wr6502(laddr+0xC000,Value); break;
  case 0xF000: Wr6502(laddr+0x0000,Value); break;
 }
}

unsigned Z80_RDMEM(dword Addr)
{
 switch (Addr/0x1000)
 {
  case 0x0:
  case 0x1:
  case 0x2:
  case 0x3:
  case 0x4:
  case 0x5:
  case 0x6:
  case 0x7:
  case 0x8:
  case 0x9:
  case 0xA:
   return Rd6502(Addr+0x1000);
  case 0xB:
  case 0xC:
  case 0xD:
   return Rd6502(Addr+0x2000);
  case 0xE:
   return Rd6502(Addr-0x2000);
  case 0xF:
   return Rd6502(Addr-0xF000);
 }
 return 255;
}
