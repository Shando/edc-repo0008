/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  CGAFNT2H:  build tool to generate font header from 2K font
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 */

#include <stdio.h>

void main(void)
{
 unsigned char font[2048];
 FILE *file;
 FILE *src;
 int travel;

 file=fopen("dapple.fnt","rb");
 if (!file) {perror("cannot open font");return;}
 src=fopen("font.h","wb");
 if (!src) {perror("cannot open font.h");return;}

 fprintf(src,"/* File generated automatically from dapple.fnt by cgafnt2h - do not modify */\n");
 fprintf(src,"\n");
 fprintf(src,"char AppleFont[2048]=\n{");
 fread(font,1,2048,file);
 fclose(file);
 for (travel=0;travel<2048; travel++)
 {
  if (!(travel%8)) fprintf (src,"\n");
  fprintf (src," 0x%02X",font[travel]);
  if (travel<2047) fprintf (src,",");
 }
 fprintf (src,"\n};");
 fclose(src);
}