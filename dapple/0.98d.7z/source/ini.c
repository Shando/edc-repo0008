/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  INI: DAPPLE.INI file handling
 * Revision:   (Diana 0.97a) 2002.1115
 *             0.33 "LOST KEY WEEKEND"
 */

#include <stdio.h>
#include <string.h>

extern int sounddelay, smode,
           flipmethod,
           dqhdv,
           fake80,
           fg, bg, mono,
           membankon,
           tweakpic,
           hold,
           dqshift;

typedef enum {USA, France, Germany, UK, Denmark1, Sweden, Italy, Spain,
              Japan, Norway, Denmark2} Charset;

extern Charset charmode;

extern char parallel[128], rompath[128];

void wrini(void)
{
 FILE *file;

 file=fopen("dapple.ini","wt");
 if (!file) return;
 fprintf(file,"[Dapple]\n");
 fprintf(file,"Sound=%s\n",smode?"Yes":"No");
 fprintf(file,"FlipMethod=%s\n",flipmethod?"PC":"Apple");
 fprintf(file,"HardDisk=%s\n",dqhdv?"No":"Yes");
 fprintf(file,"FakeTerminal=%s\n",fake80?"Yes":"No");
 fprintf(file,"Video=%s\n",mono==0?"Color":
                           mono==1?"Mono":
                           mono==2?"Green":
                           mono==3?"apl2em":
                                   "Amber");
 fprintf(file,"LanguageCard=%s\n",membankon?"Yes":"No");
 fprintf(file,"HighParallel=%s\n",tweakpic?"Yes":"No");
 fprintf(file,"Charset=%s\n",charmode==USA     ?"USA":
                             charmode==France  ?"France":
                             charmode==Germany ?"Germany":
                             charmode==UK      ?"UK":
                             charmode==Denmark1?"Denmark1":
                             charmode==Sweden  ?"Sweden":
                             charmode==Italy   ?"Italy":
                             charmode==Spain   ?"Spain":
                             charmode==Japan   ?"Japan":
                             charmode==Norway  ?"Norway":
                             charmode==Denmark2?"Denmark2":"???");
 fprintf(file,"ParallelOutput=%s\n",parallel);
 fprintf(file,"DefaultBios=%s\n",rompath);
 fprintf(file,"Delay=$%04X\n",hold);
 fprintf(file,"ShiftMod=%s\n",dqshift?"No":"Yes");
 fclose(file);
}

void rdini(void)
{
 FILE *file;

 file=fopen("dapple.ini","rt");
 if (!file) return;
 while (!feof(file))
 {
  char wip[128];

  fgets(wip,128,file);
  wip[strlen(wip)-1]=0;
  if (!stricmp(wip,"Sound=Yes")) smode=1;
  if (!stricmp(wip,"Sound=No")) smode=0;
  if (!stricmp(wip,"FlipMethod=PC")) flipmethod=1;
  if (!stricmp(wip,"FlipMethod=Apple")) flipmethod=0;
  if (!stricmp(wip,"HardDisk=No")) dqhdv=1;
  if (!stricmp(wip,"HardDisk=Yes")) dqhdv=0;
  if (!stricmp(wip,"Video=Color")) mono=0;
  if (!stricmp(wip,"Video=Mono")) mono=1;
  if (!stricmp(wip,"Video=Green")) mono=2;
  if (!stricmp(wip,"Video=apl2em")) mono=3;
  if (!stricmp(wip,"Video=Amber")) mono=4;
  if (!stricmp(wip,"LanguageCard=Yes")) membankon=1;
  if (!stricmp(wip,"LanguageCard=No")) membankon=0;
  if (!stricmp(wip,"HighParallel=Yes")) tweakpic=1;
  if (!stricmp(wip,"HighParallel=No")) tweakpic=0;
  if (!stricmp(wip,"Charset=USA")) charmode=USA;
  if (!stricmp(wip,"Charset=France")) charmode=France;
  if (!stricmp(wip,"Charset=Germany")) charmode=Germany;
  if (!stricmp(wip,"Charset=UK")) charmode=UK;
  if (!stricmp(wip,"Charset=Denmark1")) charmode=Denmark1;
  if (!stricmp(wip,"Charset=Sweden")) charmode=Sweden;
  if (!stricmp(wip,"Charset=Italy")) charmode=Italy;
  if (!stricmp(wip,"Charset=Spain")) charmode=Spain;
  if (!stricmp(wip,"Charset=Japan")) charmode=Japan;
  if (!stricmp(wip,"Charset=Norway")) charmode=Norway;
  if (!stricmp(wip,"Charset=Denmark2")) charmode=Denmark2;
  if (!strnicmp(wip,"ParallelOutput=",15)) strcpy(parallel,&wip[15]);
  if (!strnicmp(wip,"DefaultBios=",12)) strcpy(rompath,&wip[12]);
  if (!strnicmp(wip,"Delay=$",7)) sscanf(wip,"Delay=$%x",&hold);
  if (!stricmp(wip,"ShiftMod=No")) dqshift=1;
  if (!stricmp(wip,"ShiftMod=Yes")) dqshift=0;
 }
 fclose(file);
}
