/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  DAPPLE:  main functions
 * Revision:   (Diana 0.98d) 2002.1126
 *             0.33 "LOST KEY WEEKEND"
 *
 * Graphics chroma data (0x00-0x17) provided to Usenet by Robert Munafo
 * and given to the author by Holger Picker.  See dapple.h for alternate
 * names for the colors.
 *
 * Foreign character translation derived from experimentation and Epson
 * RX-80 documentation.
 *
 * Some information was provided to Usenet by Jon Bettencourt and given to
 * the author by Holger Picker.
 *
 * Some information regarding 128K memory banking was provided by David
 * Empson and Holger Picker.  The author greatly appreciates your help.
 * Thanks a million!
 */

#include "m6502.h"
#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include "dapple.h"

int Z80_Execute (void);

int sounddelay=2;
int flipmethod=0;
int dqhdv=1;
int store80=0;

Charset charmode=USA;

int ROM16K=0;
int fake80=0;
int loaded3=0; /* Slot 3 ROM loaded? This may be unnecessary in the future */
int patchrom=0;
int mode80=0;
int mousetext=0; /* Mousetext, not yet supported */

/* disk.c */
void InitDisk( int slot );
void ShutdownDisk( void );
void DiskReset( void );
byte ReadDiskIO( word Address );
void WriteDiskIO( word Address, byte Data );

void WriteParallel( word Address, byte Data );

void redrawtext(int screen);

void nullpixmap(void);

word XRun6502(M6502 *R);

#define _NOCURSOR      0
#define _SOLIDCURSOR   1
#define _NORMALCURSOR  2

int joyenabled=1;
int hold=0;
char RAM[49152];
extern char DISKROM[256], PICROM[256];
extern char HDDROM[256]; /* no room here! */
extern int hdd;
char rompath[128]={"apple.rom"};
//static char cmap[16]={0,4,1,5,3,7,2,9,6,13,8,12,10,14,11,15};
#ifdef SAFE
char *shiftstate=1047;
#else
char *shiftstate=MK_FP(0,1047);
#endif
char oldshift;
int dqshift=1;

static int k=0,d=0,hd=0,osp;
int gm=0,hgron=0,spread=0,smode=1;
int fg=COL_TXT_WHT1, bg=COL_TXT_WHT0, mono=0;
int fontloaded=0;
int drawtext=1;
int debugstep=0, debugtrace=0;
int dlight1=0, dlight2=0;
enum {emu6502, emuZ80} cpuinuse=emu6502;

#include "font.h"

static M6502 proc;

M6502 *_proc=&proc;

enum DiskTypes
{
    UnknownType = 0,
    RawType     = 1,
    DOSType     = 2
};

extern struct DriveState
{
    /* variables for each disk */
    char DiskFN[ 80 ]; /* MS-DOS filename of disk image */
    int DiskFH;        /* MS-DOS file handle of disk image */
    long DiskSize;     /* length of disk image file in bytes */
    enum DiskTypes DiskType; /* Type of disk image */
    int WritePro;      /* 0:write-enabled, !0:write-protected */
    int TrkBufChanged; /* Track buffer has changed */
    int TrkBufOld;     /* Data in track buffer needs updating before I/O */
    int ShouldRecal;
    /* variables used during emulation */
    int Track;    /* 0-70 */
    int Phase;    /* 0- 3 */
    int ReadWP;   /* 0/1  */
    int Active;   /* 0/1  */
    int Writing;  /* 0/1  */
} DrvSt[ 2 ];

int critical_error_handler (int errval, int ax, int bp, int si)
{
 char far *deviceDriver;
 char AllowedActions;
 int CanIgnore=0, CanFail=0;
 char ah, al;
 deviceDriver=MK_FP(bp, si+10);
 ah=ax/256;
/* al=ax%256; */
 /* Generate ARIF message from AH flags */
 AllowedActions=ah;
 if ((ah&0x80)&&(((struct devhdr far *)(deviceDriver-10))->dh_attr&0x8000))
 {
  if (deviceDriver[0]=='P'&&
      deviceDriver[1]=='R'&&
      deviceDriver[2]=='N')
  {
   static char errnam[3];
   int travel;

   switch (errval)
   {
    case 1:  strcpy(errnam,"UN"); break;
    case 3:  strcpy(errnam,"RQ"); break;
    case 5:  strcpy(errnam,"PR"); break;
    case 9:  strcpy(errnam,"OP"); break;
    case 10: strcpy(errnam,"WF"); break;
    default: strcpy(errnam,"??"); break;
   }
   for (travel=0;travel<3;travel++) xputcs(32,travel,COL_LPTERR%256);
   for (travel=0;errnam[travel];travel++) xputcs(errnam[travel],travel,COL_LPTERR%256);
   if (kbhit())
   {
    for (travel=0;travel<3;travel++) xputcs(32,travel,COL_LPTERR%256);
    if (!getch()) getch();
    hardresume(3);
   }
   hardresume(1);
  }
 }
 if (AllowedActions & 32)  CanIgnore=-1;
 if (AllowedActions & 8)   CanFail=-1;
 if (CanIgnore) hardresume (0);
 if (CanFail)   hardresume (3);
 gmode(3);
 cprintf ("FATAL I/O ERROR, CANNOT RECOVER  #%04X  DEVICE @%04X:%04X",errval,si,bp);
 hardresume(2);
 return 2;
}

void palette (unsigned char attr, unsigned char r, unsigned char g, unsigned char b)
{
 outp(0x3C8,attr);
 outp(0x3C9,r/4);
 outp(0x3C9,g/4);
 outp(0x3C9,b/4);
 PALETTE[attr].red=r;
 PALETTE[attr].green=g;
 PALETTE[attr].blue=b;
}

int palinit=0;

void initpalette (void)
{
 if (palinit) return;
 palinit=1;
 palette (0x00,   0,  0,  0);
 palette (0x01, 227, 30, 96);
 palette (0x02,  96, 78,189);
 palette (0x03, 255, 68,253);
 palette (0x04,   0,163, 96);
 palette (0x05, 156,156,156);
 palette (0x06,  20,207,253);
 palette (0x07, 208,195,255);
 palette (0x08,  96,114,  3);
 palette (0x09, 255,106, 60);
 palette (0x0a, 156,156,156);
 palette (0x0b, 255,160,208);
 palette (0x0c,  20,245, 60);
 palette (0x0d, 208,221,141);
 palette (0x0e, 114,255,208);
 palette (0x0f, 255,255,255);
 palette (0x10,   0,  0,  0);
 palette (0x11,  20,245, 60);
 palette (0x12, 255, 68,253);
 palette (0x13, 255,255,255);
 palette (0x14,   0,  0,  0);
 palette (0x15,  20,207,253);
 palette (0x16, 255,106, 60);
 palette (0x17, 255,255,255);
 palette (0x18,0x00,0x00,0x00);
 palette (0x19,0xff,0xff,0xff);
 palette (0x1a,0x00,0x00,0x00);
 palette (0x1b,0xff,0xff,0xff);
 palette (0x1c,0x00,0x00,0x00);
 palette (0x1d,0x00,0xaf,0x00);
 palette (0x1e,0x00,0x00,0x00);
 palette (0x1f,0x00,0xaf,0x00);
 palette (0x20,0x00,0x00,0x00);
 palette (0x21,0xaf,0xaf,0x00);
 palette (0x22,0x00,0x00,0x00);
 palette (0x23,0xaf,0xaf,0x00);
 palette (0x24,0x7f,0x7f,0x7f);
 palette (0x25,0xff,0x00,0x00);
 palette (0x26,0xff,0xff,0x00);
 palette (0x27,0x00,0xff,0x00);
 palette (0x28,0xff,0xff,0x00);
 palette (0x29,0xff,0x00,0xff);
 palette (0x2a,0xff,0x00,0xff);
 palette (0x2b,0xff,0xff,0x00);
 palette (0x2c,0x7f,0x7f,0x7f);
 palette (0x2d,0xff,0x00,0x00);
 palette (0x2e,0xff,0x00,0xff);
 palette (0x2f,0xff,0x00,0x00);
}

void linput (char *x)
{
 _setcursortype(_SOLIDCURSOR);
 fgets(x,128,stdin);
 _setcursortype(_NOCURSOR);
}

void opengraph(void)
{
 int pal;
 gmode(0x13);
 initpalette();
 for (pal=0; pal<256; pal++)
  palette(pal,PALETTE[pal].red,PALETTE[pal].green,PALETTE[pal].blue);
}

struct tpoint relpix(int addr) /* 0-rel */
{
 struct tpoint t;

 int by128,by40,in128;

 by128=(addr-(addr%128))/128;
 in128=addr%128;
 by40=(in128-(in128%40))/40;
 t.x=(in128%40)+1;
 if (t.x>40) t.x=-1;
 t.y=1+(8*by40)+by128;
 gotoxy(1,25);
 return t;
}

void click(void)
{
 if (!smode) return;
 if (sounddelay!=2)
 {
  sound(40);
  delay(sounddelay);
  nosound();
 }
 else
 {
  int al;
  // Toggle the speaker
  al=inportb(0x61);
  al ^= 0x02;
  al &= 0xfe;
  outportb(0x61,al);
 }
}

void PC2APL (void)
{
 int x;

 x=bioskey(1);
 if (/*kbhit()*/ x)
 {
  if (x==-1)
  {
   extern byte SlotCxROM, SlotC3ROM;
   extern int sbank;

   k=0;
   cpuinuse=emu6502;
   DiskReset();
   Reset6502(&proc);
   sbank=0;
   rbank=0;
   wbank=0;
   SlotCxROM = 0x0d;
   SlotC3ROM = 0x0d;
   Z80_Reset();
   x=bioskey(0);
   return;
  } /* Ctrl-Break */

  x=getch();
  if (!x) {x=getch(); x*=(-1);}
  if (x>=0&&x<=127) {k=x+128; return;}
  if (x>127 && x<256)
  {
   switch (x)
   {/* Foreign Keyboard Support */
    case 128:
     k='C'+128;
     return;
    case 129:
     k='u'+128;
     if (charmode==Germany) k='}'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='~'+128;
     return;
    case 130:
     k='e'+128;
     if (charmode==France) k='{'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='`'+128;
     if (charmode==Italy) k=']'+128;
     return;
    case 131: k='a'+128; return;
    case 132:
     k='a'+128;
     if (charmode==Germany||charmode==Sweden) k='{'+128;
     return;
    case 133:
     k='a'+128;
     if (charmode==France) k='@'+128;
     if (charmode==Italy) k='{'+128;
     return;
    case 134:
     k='a'+128;
     if (charmode==Denmark1||charmode==Sweden
       ||charmode==Norway||charmode==Denmark2) k='}'+128;
     return;
    case 135:
     k='c'+128;
     if (charmode==France) k='\\'+128;
     return;
    case 136:
     k='e'+128;
     return;
    case 137: k='e'+128; return;
    case 138:
     k='e'+128;
     if (charmode==France||charmode==Italy) k='}'+128;
     return;
    case 139: k='i'+128; return;
    case 140: k='i'+128; return;
    case 141:
     k='i'+128;
     if (charmode==Italy) k='~'+128;
     return;
    case 142:
     k='A'+128;
     if (charmode==Germany||charmode==Sweden) k='['+128;
     return;
    case 143:
     k='A'+128;
     if (charmode==Denmark1||charmode==Sweden
       ||charmode==Norway||charmode==Denmark2) k=']'+128;
     return;
    case 144:
     k='E'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='@'+128;
     return;
    case 145:
     k='e'+128;
     if (charmode==Denmark1||charmode==Norway||charmode==Denmark2) k='{'+128;
     return;
    case 146:
     k='E'+128;
     if (charmode==Denmark1||charmode==Norway||charmode==Denmark2) k='['+128;
     return;
    case 147: k='o'+128; return;
    case 148:
     k='o'+128;
     if (charmode==Germany||charmode==Sweden) k='|'+128;
     return;
    case 149:
     k='o'+128;
     if (charmode==Italy) k='|'+128;
     return;
    case 150: k='u'+128; return;
    case 151:
     k='u'+128;
     if (charmode==France) k='|'+128;
     if (charmode==Italy) k='`'+128;
     return;
    case 152: k='y'+128; return;
    case 153:
     k='O'+128;
     if (charmode==Germany||charmode==Sweden) k='\\'+128;
     return;
    case 154:
     k='U'+128;
     if (charmode==Germany) k=']'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='^'+128;
     return;
    case 155: k='c'+128; return;
    case 156:
     k='L'+128;
     if (charmode==UK) k='#'+128;
     return;
    case 157:
     k='Y'+128;
     if (charmode==Japan) k='\\'+128;
     return;
    case 158:
     k='P'+128;
     if (charmode==Spain) k='#'+128;
     return;
    case 159: k='f'+128; return;
    case 160:
     k='a'+128;
     return;
    case 161: k='i'+128; return;
    case 162: k='o'+128; return;
    case 163: k='u'+128; return;
    case 164:
     k='n'+128;
     if (charmode==Spain) k='|'+128;
     return;
    case 165:
     k='N'+128;
     if (charmode==Spain) k='\\'+128;
     return;
    case 225:
     if (charmode==Germany) {k='~'+128; return;}
   }
  }
  if (x==-72) {k=11+128; return;}
  if (x==-75) {k=8+128;  return;}
  if (x==-77) {k=21+128; return;}
  if (x==-80) {k=10+128; return;}
  if (x==-68) {if (uimain(&proc)) k=-1;  return;}
  if (x==-107) {k=-1; return;}
  if (x==-112) Wr6502(1012,0);
  if (x==-67||x==-112)
  {
   extern byte SlotCxROM, SlotC3ROM;
   extern int sbank;

   k=0;
   cpuinuse=emu6502;
   DiskReset();
   Reset6502(&proc);
   sbank=0;
   rbank=0;
   wbank=0;
   SlotCxROM = 0x0d;
   SlotC3ROM = 0x0d;
   Z80_Reset();
   return;
  }

  if (x==-63) redrawtext((gm&PG2)?2:1);
 }
}

void redrawtext(int screen)
{
 int Addr,Value;

 pset(314,2,COL_DRV_OFF);
 pset(314,4,dlight1?COL_DRV_ON:COL_DRV_OFF);
 pset(316,4,dlight2?COL_DRV_ON:COL_DRV_OFF);
 pset(314,6,COL_DRV_OFF);
 pset(316,6,COL_DRV_OFF);
 pset(316,199,0);

 if ((gm&HRG)&&(gm&GRX)&&(!hgron))
 {
  hgron=1;
  nullpixmap();
  gotoxy(1,25);
 }
 if (((!(gm&HRG))||(!(gm&GRX)))&&(hgron))
 {
  hgron=0;
  nullpixmap();
  gotoxy(1,25);
 }

 if (hgron)
 {
  for (Addr=8192;Addr<24576;Addr++) /* redraw both pixmaps */
   Wr6502(Addr,Rd6502(Addr));
 }

 for (Addr=screen*1024;Addr<(screen*1024)+1024;Addr++)
  Wr6502(Addr,Rd6502(Addr));
}

void Wr6502(register word Addr,register byte Value)
{
 extern int sbank;
 extern int mainbank128w;
 if (!debugger)
 {
#ifdef BANK128
  if (Addr<49152) write128(Addr,Value);
#else
  if (Addr<49152) RAM[Addr]=Value;
#endif
  if (Addr>=49152 && Addr<=49167)
  {
   if (ROM16K)
   {
    if (Addr==0xC000) store80=0;
    if (Addr==0xC001) store80=1;
#ifdef BANK128
    if (!store80)
    {
     extern int lcbank128, mainbank128r;

     if (Addr==0xC002) mainbank128r=0;
     if (Addr==0xC003) mainbank128r=1;
     if (Addr==0xC004) mainbank128w=0;
     if (Addr==0xC005) mainbank128w=1;
    }
#endif
   }
   if (Addr==0xC006 || Addr==0xC007 || Addr==0xC00A || Addr==0xC00B)
   {
    if (ROM16K)
    {
     void WriteAltROMIO( word Address, byte Data );

     WriteAltROMIO (Addr-0xC000,Value);
     return;
    }
   }
#ifdef BANK128
   if (Addr==0xC008 && ROM16K)
   {
    extern int lcbank128;

    lcbank128=0;
   }
   if (Addr==0xC009 && ROM16K)
   {
    extern int lcbank128;

    lcbank128=1;
   }
#endif
   if (Addr==0xC00C) mode80=0;
   if (Addr==0xC00D) mode80=1;
   if (Addr==0xC00E) {mousetext=0; redrawtext(gm&PG2?2:1);}
   if (Addr==0xC00F) {mousetext=ROM16K; redrawtext(gm&PG2?2:1);}
  }

  if (Addr==0xC064 || Addr==0xC065)
  {
   extern byte ReadGameTimer(word Address);

   ReadGameTimer(Addr&0xFF);
  }
  if (Addr==0xC070)
  {
   extern byte ResetGameTimer(word Address);

   ResetGameTimer(Addr);
  }

  if (Addr>=49168 && Addr<=49183 && (k!=-1)) k&=0x7f;

  if (Addr>=49184 && Addr<=49199); /* Cassette output toggle */
  if (Addr>=49200 && Addr<=49215) {click(); click();}
  if (Addr>=49216 && Addr<=49231); /* Utility output strobe - nani yo? */
  if (Addr==49232) {gm|=GRX; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49233) {gm&=~GRX; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49234) {gm&=~SPL; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49235) {gm|=SPL; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49236 && (gm&PG2))
  {
   if (!((gm&GRX)&&(gm&HRG))) {gm&=~PG2; redrawtext(1); return;}
   if ((gm&PG2)&&(gm&GRX)&&(gm&HRG)&&(!flipmethod)&&hgron&&(!(gm&SPL)))
   {
    gm&=~PG2;
    pageflip();
   }
   else
   {
    gm&=~PG2;
    redrawtext(1);
   }
  }
  if (Addr==49237 && ((!ROM16K)||(!(store80||mode80))))
  {
   if (!((gm&GRX)&&(gm&HRG))) {gm|=PG2; redrawtext(2); return;}
   if ((!(gm&PG2))&&(gm&GRX)&&(gm&HRG)&&(!flipmethod)&&hgron&&(!(gm&SPL)))
   {
    gm|=PG2;
    pageflip();
    return;
   }
   else
   {
    gm|=PG2;
    redrawtext(2);
    return;
   }
  }
  if (Addr==49238) {gm&=~HRG; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49239) {gm|=HRG; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49240); /* Out0-off - nani yo? */
  if (Addr==49241); /* Out0-on - nani yo? */
  if (Addr==49242); /* Out1-off - nani yo? */
  if (Addr==49243); /* Out1-on - nani yo? */
  if (Addr==49244); /* Out2-off - nani yo? */
  if (Addr==49245); /* Out2-on - nani yo? */
  if (Addr==49246); /* Out3-off - nani yo? */
  if (Addr==49247); /* Out3-on - nani yo? */
  if (Addr==49248); /* Cassette input */
  if (Addr==49249);
  if (Addr==49250);
  if (Addr==49251);
  if (Addr==49252); /* Pdl0 */
  if (Addr==49253); /* Pdl1 */
  if (Addr==49254); /* Pdl2 */
  if (Addr==49255); /* Pdl3 */
  if (Addr==49256); /* Cassette input */
  if (Addr==49257);
  if (Addr==49258);
  if (Addr==49259);
  if (Addr==49260); /* Pdl0 */
  if (Addr==49261); /* Pdl1 */
  if (Addr==49262); /* Pdl2 */
  if (Addr==49263); /* Pdl3 */
  if (Addr>=49264 && Addr<=49279); /* Joystick strobe - nani yo? */
 }

 /* Andrew Gregory says the 65C02 writes twice. */
 if (Addr>49279 && Addr<49296) {C08(Addr-49280); C08(Addr-49280);}

 if (Addr>=49296 && Addr<=49311)
 {
  WriteParallel (Addr, Value);
 }

 if (Addr>=49920 && Addr<=50175)
 {
  return;
 }

// if (Addr>=50432 && Addr<=50687)
 if (Addr==50176)
 {
  if (cpuinuse==emuZ80) /* from manual */
  {
   cpuinuse=emu6502;
   return;
  }
  cpuinuse=emuZ80;
  return;
 }

 if (Addr>=49360 && Addr<=49375) WriteRawDiskIO (Addr, Value);
 if (Addr>=49376 && Addr<=49391) WriteDiskIO (Addr,Value);
 if (Addr>=49392 && Addr<=49407 && (!dqhdv)) WriteMassStorIO (Addr,Value);
                              /* vvvvvvv bugfix */
 if (Addr>0xCFFFU) writebank(Addr-0xD000,Value);

 if (debugger) return;
 if (mainbank128w) return;

 if (Addr>8191 && Addr<16384 && (gm&HRG) && (gm&GRX))
 {
  struct tpoint t;
  void (*lpset) (unsigned int x, unsigned int y, unsigned c);

  if (gm&PG2) lpset=apset; else lpset=pset;

  t=hrelpix(Addr-8192);
  if (t.x==-1||t.y>191) return;
  if ((gm&SPL)&&(t.y>159)) return;
  {
   int hue,c1,c2;
   if (t.x&1 && !(Value&128))    hue=3; /* odd  - pal1 */
   if (t.x&1 && Value&128)       hue=4; /* odd  - pal2 */
   if (!(t.x&1) && !(Value&128)) hue=1; /* even - pal1 */
   if (!(t.x&1) && Value&128)    hue=2; /* even - pal2 */

   if (hue==1) {c1=COL_HGR2;c2=COL_HGR1;}
   if (hue==2) {c1=COL_HGR5;c2=COL_HGR6;}
   if (hue==3) {c1=COL_HGR1;c2=COL_HGR2;}
   if (hue==4) {c1=COL_HGR6;c2=COL_HGR5;}

   osp=spread;
   if (mono==1) {spread=0; c1=COL_TXT_WHT1; c2=COL_TXT_WHT1;}
   if (mono==2) {spread=0; c1=COL_TXT_GRN1; c2=COL_TXT_GRN1;}
   if (mono==3) spread=0;
   if (mono==4) {spread=0; c1=COL_TXT_AMB1; c2=COL_TXT_AMB1;}

   lpset((t.x)+20,t.y+4,c1*(0!=(Value&1))+spread*c2*(0!=(Value&2)));
   lpset((t.x)+21,t.y+4,spread*c1*(0!=(Value&1))+c2*(0!=(Value&2)));
if (mono<2){
#ifdef BANK128
   if (((Value&1)==1) && ((read128(Addr-1)&64)==64))
#else
   if (((Value&1)==1) && ((RAM[Addr-1]&64)==64))
#endif
   {
    lpset((t.x)+20,t.y+4,COL_HGR3);
   }
   if ((Value&3)==3)
   {
    lpset((t.x)+20,t.y+4,COL_HGR3);
    lpset((t.x)+21,t.y+4,COL_HGR3);
   }
}
   lpset((t.x)+22,t.y+4,c1*(0!=(Value&4))+spread*c2*(0!=(Value&8)));
   lpset((t.x)+23,t.y+4,spread*c1*(0!=(Value&4))+c2*(0!=(Value&8)));
if (mono<2){
   if ((Value&12)==12)
   {
    lpset((t.x)+22,t.y+4,COL_HGR3);
    lpset((t.x)+23,t.y+4,COL_HGR3);
   }
}
   lpset((t.x)+24,t.y+4,c1*(0!=(Value&16))+spread*c2*(0!=(Value&32)));
   lpset((t.x)+25,t.y+4,spread*c1*(0!=(Value&16))+c2*(0!=(Value&32)));
if (mono<2){
   if ((Value&48)==48)
   {
    lpset((t.x)+24,t.y+4,COL_HGR3);
    lpset((t.x)+25,t.y+4,COL_HGR3);
   }
}
   lpset((t.x)+26,t.y+4,c1*(0!=(Value&64)));
if (mono<2){
#ifdef BANK128
   if ((Value&64)&&(read128(Addr+1)&1))
#else
   if ((Value&64)&&(RAM[Addr+1]&1))
#endif
   {
    lpset((t.x)+26,t.y+4,COL_HGR3);
   }
}
   spread=osp;
  }
  if (!(gm&SPL)) return;
 }

 if (Addr>16383 && Addr<24576 && (gm&HRG) && (gm&GRX))
 {
  struct tpoint t;
  void (*lpset) (unsigned int x, unsigned int y, unsigned c);

  if (gm&PG2) lpset=pset; else lpset=apset;

  t=hrelpix(Addr-16384);
  if (t.x==-1||t.y>191) return;
  if ((gm&SPL)&&(t.y>159)) return;
  {
   int hue,c1,c2;
   if (t.x&1 && !(Value&128))    hue=3; /* odd  - pal1 */
   if (t.x&1 && Value&128)       hue=4; /* odd  - pal2 */
   if (!(t.x&1) && !(Value&128)) hue=1; /* even - pal1 */
   if (!(t.x&1) && Value&128)    hue=2; /* even - pal2 */

   if (hue==1) {c1=COL_HGR2;c2=COL_HGR1;}
   if (hue==2) {c1=COL_HGR5;c2=COL_HGR6;}
   if (hue==3) {c1=COL_HGR1;c2=COL_HGR2;}
   if (hue==4) {c1=COL_HGR6;c2=COL_HGR5;}

   osp=spread;
   if (mono==1) {spread=0; c1=COL_TXT_WHT1; c2=COL_TXT_WHT1;}
   if (mono==2) {spread=0; c1=COL_TXT_GRN1; c2=COL_TXT_GRN1;}
   if (mono==3) spread=0;
   if (mono==4) {spread=0; c1=COL_TXT_AMB1; c2=COL_TXT_AMB1;}

   lpset((t.x)+20,t.y+4,c1*(0!=(Value&1))+spread*c2*(0!=(Value&2)));
   lpset((t.x)+21,t.y+4,spread*c1*(0!=(Value&1))+c2*(0!=(Value&2)));
if (mono<2){
#ifdef BANK128
   if (((Value&1)==1) && ((read128(Addr-1)&64)==64))
#else
   if (((Value&1)==1) && ((RAM[Addr-1]&64)==64))
#endif
   {
    lpset((t.x)+20,t.y+4,COL_HGR3);
   }
   if ((Value&3)==3)
   {
    lpset((t.x)+20,t.y+4,COL_HGR3);
    lpset((t.x)+21,t.y+4,COL_HGR3);
   }
}
   lpset((t.x)+22,t.y+4,c1*(0!=(Value&4))+spread*c2*(0!=(Value&8)));
   lpset((t.x)+23,t.y+4,spread*c1*(0!=(Value&4))+c2*(0!=(Value&8)));
if (mono<2){
   if ((Value&12)==12)
   {
    lpset((t.x)+22,t.y+4,COL_HGR3);
    lpset((t.x)+23,t.y+4,COL_HGR3);
   }
}
   lpset((t.x)+24,t.y+4,c1*(0!=(Value&16))+spread*c2*(0!=(Value&32)));
   lpset((t.x)+25,t.y+4,spread*c1*(0!=(Value&16))+c2*(0!=(Value&32)));
if (mono<2){
   if ((Value&48)==48)
   {
    lpset((t.x)+24,t.y+4,COL_HGR3);
    lpset((t.x)+25,t.y+4,COL_HGR3);
   }
}
   lpset((t.x)+26,t.y+4,c1*(0!=(Value&64)));
if (mono<2){
#ifdef BANK128
   if ((Value&64)&&(read128(Addr+1)&1))
#else
   if ((Value&64)&&(RAM[Addr+1]&1))
#endif
   {
    lpset((t.x)+26,t.y+4,COL_HGR3);
   }
}
   spread=osp;
  }
  if (!(gm&SPL)) return;
 }

 if ((gm&HRG)&&(gm&GRX)) if (!(gm&SPL)) return;

 if (Addr>1023 && Addr<2048 && (!(gm&PG2)) && (!mainbank128w))
 {
  struct tpoint t;
  char c;
  int method;

  t=relpix(Addr-1024);
  if (t.x==-1||t.y>24) return;
  method=0;
  if (gm&GRX)  if (!(gm&SPL)||(t.y<21)) method=1;
  if (method==1)
  {
   if (gm&HRG) return;
   xputc(11,t.x,t.y,(((Value>>4)<<8)+(Value%16)));
  }
  else
  {
   c=Value%64;
   if (Value>159) c=Value-128;
   if (c<32) c+=64;
   if (mousetext && Value>=96 && Value<=127) c=Value;
   {
    xputc(c,t.x,t.y,
     ((Value<64 || (Value<127 && mousetext))?bg:(Value<128)?fg+2:fg)+256*
     ((Value<64 || (Value<127 && mousetext))?fg:(Value<128)?bg+2:bg));
   }
  }
  return;
 }

 if (Addr>2047 && Addr<4096 && (gm&PG2) && (!mainbank128w) && (!store80))
 {
  struct tpoint t;
  char c;
  int method;

  t=relpix(Addr-2048);
  if (t.x==-1||t.y>24) return;
  method=0;
  if (gm&GRX)  if (!(gm&SPL)||(t.y<21)) method=1;
  if (method==1)
  {
   if (gm&HRG) return;
   xputc(223,t.x,t.y,(((Value>>4)<<8)+(Value%16)));
  }
  else
  {
   c=Value%64;
   if (Value>159) c=Value-128;
   if (c<32) c+=64;
   if (mousetext && Value>=96 && Value<=127) c=Value;
   {
    xputc(c,t.x,t.y,
     ((Value<64 || (Value<127 && mousetext))?bg:(Value<128)?fg+2:fg)+256*
     ((Value<64 || (Value<127 && mousetext))?fg:(Value<128)?bg+2:bg));
   }
  }
  return;
 }
}

byte Rd6502(register word Addr)
{
 extern int sbank;

#ifdef BANK128
 if (Addr<49152)  return read128(Addr);
#else
 if (Addr<49152)  return (byte) RAM[Addr];
#endif
 if (Addr>=53248) return (byte) readbank(Addr-53248);
 if (Addr>=0xC100 && Addr<=0xCFFF)
  if (sbank && ROM16K) return ROM[(Addr-0xC100)+12288];

 if (debugger) return 96;
 if (Addr==0xC015 || Addr==0xC017)
 {
  byte ReadAltROMIO( word Address );

  return ReadAltROMIO( Addr-0xC000 );
 }
#ifdef BANK128
 if (ROM16K)
 {
  extern int lcbank128, mainbank128r, mainbank128w;

  if (Addr==0xC013) return mainbank128r?0x8D:0x0D;
  if (Addr==0xC014) return mainbank128w?0x8D:0x0D;
  if (Addr==0xC016) return lcbank128   ?0x8D:0x0D;
  if (Addr==0xC018) return store80     ?0x8D:0x0D;
 }
#endif
 if (Addr==0xC01A) return gm&GRX?0x0D:0x8D;
 if (Addr==0xC01B) return gm&SPL?0x8D:0x0D;
 if (Addr==0xC01C) return gm&PG2?0x8D:0x0D;
 if (Addr==0xC01D) return gm&HRG?0x8D:0x0D;

 if (Addr==0xC01F) return mode80?0x8D:0x0D; /* 80-column mode? */

 if (Addr==0xC064 || Addr==0xC065)
 {
  extern byte ReadGameTimer(word Address);

  return ReadGameTimer(Addr&0xFF);
 }
 if (Addr==0xC070)
 {
  extern byte ResetGameTimer(word Address);

  return ResetGameTimer(Addr);
 }

 if (Addr>=49152 && Addr<=49167) {PC2APL(); return (byte) k;}
 if (Addr>=49168 && Addr<=49183 && (k!=-1)) {k&=0x7f; return C01(Addr%16);}
 if (Addr>=49184 && Addr<=49199); /* Cassette output toggle */
 if (Addr>=49200 && Addr<=49215) click();
 if (Addr>=49216 && Addr<=49231); /* Utility output strobe - nani yo? */
  if (Addr==49232) {gm|=GRX; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49233) {gm&=~GRX; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49234) {gm&=~SPL; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49235) {gm|=SPL; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49236 && (gm&PG2))
  {
   if (!((gm&GRX)&&(gm&HRG))) {gm&=~PG2; redrawtext(1); return 96;}
   if ((gm&PG2)&&(gm&GRX)&&(gm&HRG)&&(!flipmethod)&&hgron&&(!(gm&SPL)))
   {
    gm&=~PG2;
    pageflip();
   }
   else
   {
    gm&=~PG2;
    redrawtext(1);
   }
  }
  if (Addr==49237 && ((!ROM16K)||(!(store80||mode80))))
  {
   if (!((gm&GRX)&&(gm&HRG))) {gm|=PG2; redrawtext(2); return 96;}
   if ((!(gm&PG2))&&(gm&GRX)&&(gm&HRG)&&(!flipmethod)&&hgron&&(!(gm&SPL)))
   {
    gm|=PG2;
    pageflip();
    return 96;
   }
   else
   {
    gm|=PG2;
    redrawtext(2);
    return 96;
   }
  }
  if (Addr==49238) {gm&=~HRG; nullpixmap(); redrawtext(gm&PG2?2:1);}
  if (Addr==49239) {gm|=HRG; nullpixmap(); redrawtext(gm&PG2?2:1);}
 if (Addr==49240); /* Out0-off - nani yo? */
 if (Addr==49241); /* Out0-on - nani yo? */
 if (Addr==49242); /* Out1-off - nani yo? */
 if (Addr==49243); /* Out1-on - nani yo? */
 if (Addr==49244); /* Out2-off - nani yo? */
 if (Addr==49245); /* Out2-on - nani yo? */
 if (Addr==49246); /* Out3-off - nani yo? */
 if (Addr==49247); /* Out3-on - nani yo? */
 if (Addr==49248); /* Cassette input */
 if (Addr==49249)  if (joya()) return 128;
 if (Addr==49250)  if (joyb()) return 128;
 if (Addr==49251)  if (*shiftstate&3) return dqshift?128:0; else return 128;
 if (Addr==49252) return !joyenabled?96:joyx(); /* Pdl0 */
 if (Addr==49253) return !joyenabled?96:joyy(); /* Pdl1 */
 if (Addr==49254) return 96; /* Pdl2 - AG says ??? */
 if (Addr==49255) return 96; /* Pdl3 */
 if (Addr==49256); /* Cassette input */
 if (Addr==49257)  if (joya()) return 128;
 if (Addr==49258)  if (joyb()) return 128;
 if (Addr==49259)  if (*shiftstate&3) return 128;
 if (Addr==49260) return 126; /* Pdl0 */
 if (Addr==49261) return 127; /* Pdl1 */
 if (Addr==49262) return 128; /* Pdl2 */
 if (Addr==49263) return 129; /* Pdl3 */
 if (Addr>=49264 && Addr<=49279); /* Joystick strobe - nani yo? */

 if (Addr>49279 && Addr<49296) C08(Addr-49280);
 if (Addr>=49296 && Addr<=49311) return 0xFF; /* 1 */
 if (Addr>=49312 && Addr<=49327) return 0xFF; /* 2 */
 if (Addr>=49328 && Addr<=49343)              /* 3 */
 {
  return fake80;
 }
 if (Addr>=49344 && Addr<=49359) return 0xFF; /* 4 */
 if (Addr>=49360 && Addr<=49375) return ReadRawDiskIO (Addr); /* 5 */
 if (Addr>=49376 && Addr<=49391) return ReadDiskIO (Addr);
 if (Addr>=49392 && Addr<=49407) return dqhdv?96:ReadMassStorIO (Addr);

 if (Addr>=49408 && Addr<=49663) return PICROM[Addr-49408];           /* 1 */
 if (Addr>=49664 && Addr<=49919) return 255;                          /* 2 */
#ifdef BANK128
 if (Addr>=49920 && Addr<=50175 && ROM16K && loaded3)
 {
  extern char ROM3[256];

  if (!fake80) return ROM3[Addr-49920];
 }
#endif
 if (Addr>=49920 && Addr<=50175) return fake80?96:255;                /* 3 */
 if (Addr>=50176 && Addr<=50431) return 255;                          /* 4 */
 if (Addr>=50432 && Addr<=50687) return HDDROM[Addr-50432];           /* 5 */
 if (Addr>=50688 && Addr<=50943) return DISKROM[Addr-50688];          /* 6 */
 if (Addr>=50944 && Addr<=51199) return dqhdv?255:HDDROM[Addr-50944]; /* 7 */

 return 96; /* RTS */
}

static unsigned int flashloop=0;

#pragma warn -par
byte Loop6502(register M6502 *R)
{
 PC2APL();
 if (k==-1) return INT_QUIT;
 flashloop++;
 if (patchrom) ROM[12288-1101]=234;
 if ((flashloop&0x12)==0x12)
 {
  palette(COL_TXT_WHT2,0x00,0x00,0x00);
  palette(COL_TXT_WHT3,0xFF,0xFF,0xFF);
  palette(COL_TXT_AMB2,0x00,0x00,0x00);
  palette(COL_TXT_AMB3,0xAF,0xAF,0x00);
  palette(COL_TXT_GRN2,0x00,0x00,0x00);
  palette(COL_TXT_GRN3,0x00,0xAF,0x00);
 }
 else if ((flashloop&0x12)==0)
 {
  palette(COL_TXT_WHT2,0xFF,0xFF,0xFF);
  palette(COL_TXT_WHT3,0x00,0x00,0x00);
  palette(COL_TXT_AMB2,0xAF,0xAF,0x00);
  palette(COL_TXT_AMB3,0x00,0x00,0x00);
  palette(COL_TXT_GRN2,0x00,0xAF,0x00);
  palette(COL_TXT_GRN3,0x00,0x00,0x00);
 }

 pset(314,199,cpuinuse?COL_DRV_ON:0);
 pset(314,2,COL_DRV_OFF);
 pset(314,4,dlight1?COL_DRV_ON:COL_DRV_OFF);
 pset(316,4,dlight2?COL_DRV_ON:COL_DRV_OFF);
 pset(314,6,COL_DRV_OFF);
 pset(316,6,COL_DRV_OFF);
 pset(316,199,0);
 return 0;
}
#pragma warn +par

int brun(char *filename)
{
 unsigned short int ca,address,length;
 unsigned long int fl;
 FILE *file;
 char *errstr;

 file=fopen(filename,"rb");
 gotoxy(1,25);
 if (!file)
 {
  perror(filename);
  return -1;
 }
 fseek(file,0,SEEK_END);
 fl=ftell(file)-4;
 fseek(file,0,SEEK_SET);
 fread(&address,2,1,file);
 fread(&length,2,1,file);
 gotoxy(1,25);

 if (fl+address>49152) return -2;

 for (ca=address; fl; fl--, ca++) Wr6502(ca,fgetc(file));

 fclose(file);

 proc.PC.W=address;
 return 0;
}

void usage(void)
{
  fprintf (stderr,"Dapple v%s  Apple ][ Emulator",DappleVersion);
  fprintf (stderr,"\
Copyright (C) 2002 Steve Nickolas, portions by Holger Picker\n\
CPU Emulation Copyright (C) 1996, 1997, 2002 Marat Fayzullin, Alex Krasivsky,\n\
  Marcel de Kogel, Steve Nickolas, Holger Picker\n\
Usage:  DAPPLE [/Q] [/RESET] [/NOSPEAKER] [/ROM filename] [/BRUN filename]\n\
               [/D1 filename] [/D2 filename] [/H1 filename] [/H2 filename]\n\
               [/RUNFIX] [/NOSAVEINI] [/NOHD]\n\
\n\
        /Q : Quickstart (no menu on startup)\n\
        /RESET : Forces a soft reset if programs have been loaded\n\
        /NOSPEAKER : Disables the PC speaker on startup (can be re-enabled\n\
                     from the menu).\n\
        /ROM : Select initial BIOS ROM (if not found, the default search will\n\
               be used, as usual)\n\
        /BRUN : Run a machine language (PG2) program immediately on startup.\n\
                This may not always work.\n\
        /D1, /D2 : Set the disk image filenames.\n\
        /H1, /H2 : Set the hard disk image filenames.\n\
        /RUNFIX : Patch in screen dimensions, for programs that do not run\n\
                  properly with /BRUN.\n\
        /NOSAVEINI : Do not save INI settings on exit.\n\
        /NOHD : Disable the hard disk emulation on startup.\n\
");
}

void main (int argc, char **argv)
{
 FILE  *rom;
 unsigned int travel,cm;
 struct text_info ti;
 int initaddr=-1370;
 int ignini=0;
 extern char hd1[128],hd2[128];

 strcpy(hd1,"hdv1.hdv");
 strcpy(hd2,"hdv2.hdv");

 /* if (!isatty(fileno(stdin))) */
   freopen("con","r",stdin);

// if (argc>3) {usage(); return;}

 if (argc>1) if (!strcmp(argv[1],"/?")) {usage(); return;}

 harderr(critical_error_handler);

 directvideo=0;
 oldshift=*shiftstate;
#ifndef SAFE
 *shiftstate=96;
#endif

 gettextinfo(&ti);
 cm=ti.currmode;

 _setcursortype(_NOCURSOR);

// rom=fopen("dapple.chr","rb");
// if (rom)
// {
//  fread(&charmode,sizeof(charmode),1,rom);
//  fclose(rom);
// }

#ifdef BANK128
 rom=fopen("column80.rom","rb");
 loaded3=rom?1:0;
 if (rom)
 {
  extern char ROM3[256];

  fread(ROM3,256,1,rom);
  fclose(rom);
 }
#endif

 rom=fopen("disk.rom","rb");
 if (!rom)
 {
  printf ("disk ][ : ROM not available\n");
 }
 fread(DISKROM,256,1,rom);
 fclose(rom);
 rom=fopen("parallel.rom","rb");
 fread(PICROM,256,1,rom);
 fclose(rom);
 rom=fopen("massstor.rom","rb");
 fread(HDDROM,256,1,rom);
 fclose(rom);
// if (!imrs("dapple.pgx",&proc)) goto bow; /* successfully read image? */
 {
  void rdini(void);

  rdini();
 }

 proc.IPeriod=32767;

 InitDisk( 6 );

 if (argc>1)
 {
  int travel;

  for (travel=1; travel<argc; travel++)
  {
   if (!stricmp(argv[travel],"/nosaveini"))
   {
    ignini=1;
   }
   if (!stricmp(argv[travel],"/nohd"))
   {
    dqhdv=1;
   }
   if (!stricmp(argv[travel],"/xevious"))
   {
    ignini=1;
    mono=2;
    dqhdv=1;
   }
   if (!stricmp(argv[travel],"/rom"))
   {
    travel++;
    strcpy(rompath,argv[travel]);
   }
   if (!stricmp(argv[travel],"/brun"))
   {
    int xbload (char *filename);
    int laddr;

    travel++;
    laddr=xbload(argv[travel]);
    if (laddr==-1370)
    {
     _setcursortype(_NORMALCURSOR);
#ifndef SAFE
     *shiftstate=oldshift; /* DJGPP won't let me get away with this! */
#endif
     return;
    }
    initaddr=laddr;
   }
   if (!stricmp(argv[travel],"/d1"))
   {
    travel++;
    UnmountDisk(0);
    strcpy(DrvSt[0].DiskFN, argv[travel]);
    DrvSt[0].DiskType = UnknownType;
    MountDisk(0);
   }
   if (!stricmp(argv[travel],"/d2"))
   {
    travel++;
    UnmountDisk(1);
    strcpy(DrvSt[1].DiskFN, argv[travel]);
    DrvSt[1].DiskType = UnknownType;
    MountDisk(1);
   }
   if (!stricmp(argv[travel],"/h1"))
   {
    dqhdv=0;
    strcpy(hd1,argv[++travel]);
   }
   if (!stricmp(argv[travel],"/h2"))
   {
    dqhdv=0;
    strcpy(hd2,argv[++travel]);
   }
   if (!stricmp(argv[travel],"/q"))
   {
    if (initaddr==-1370)
     initaddr=-1;
   }
   if (!stricmp(argv[travel],"/nospeaker"))
   {
    smode=0;
   }
   if (!stricmp(argv[travel],"/reset")) initaddr=-1;
// if (!stricmp(argv[travel],"/patch")) patchrom=-1;
   if (!stricmp(argv[travel],"/runfix"))
   {
    RAM[32]=0;
    RAM[33]=40;
    RAM[34]=0;
    RAM[35]=24;
    RAM[50]=255;
   }
  }
 }

 InitMassStor( 7 );
 rom=fopen(rompath,"rb");
 if (!rom)
 {
  strcpy(rompath,"apple.rom");
  rom=fopen(rompath,"rb");
  if (!rom)
  {
   strcpy(rompath,"apple2o.rom");
   rom=fopen(rompath,"rb");
   if (!rom)
   {
    strcpy(rompath,"apple2m.rom");
    rom=fopen(rompath,"rb");
    if (!rom)
    {
     printf ("No BIOS ROMs found.");
     goto veow;
    }
   }
  }
 }
 {
  unsigned int l;
  fseek(rom,0,SEEK_END);
  l=ftell(rom);
  fseek(rom,0,SEEK_SET);
  ROM16K=(l==16128);
  if (l==20480) /* ApplePC/AppleWin 12K */
  {
   fseek(rom,8192,SEEK_SET);
   ROM16K=0;
  }
  else if (l==32768) /* this gets false positive on //c BIOS */
  {
   fseek(rom,16640,SEEK_SET);
   ROM16K=1;
  }
 }
 if (ROM16K) fread(&(ROM[12288]),3840,1,rom);
 fread(ROM,12288,1,rom);
 fclose(rom);
/* memset(RAMEXT,0,16384); */
 for (travel=0;travel<12288;travel++) RAMEXT[travel]=ROM[travel];
 for (travel=0;travel<4096;travel++) RAMEXT[travel+12288]=ROM[travel];

 if (patchrom) ROM[12288-1101]=234;

 Reset6502(&proc);
 Z80_Reset();
 if (initaddr!=-1370 && initaddr!=-1) proc.PC.W=initaddr;

bow:
 nullpixmap();
 if (initaddr==-1370) if (uimain(&proc)) goto eow;
 if (initaddr!=-1370) opengraph();
 gotoxy(1,25);
#ifndef NOXEXEC
 XRun6502(&proc);
#else
 Run6502(&proc);
#endif
 ShutdownMassStor();
 ShutdownDisk();
eow:
// rom=fopen("dapple.chr","wb");
// if (rom)
// {
//  fwrite(&charmode,sizeof(charmode),1,rom);
//  fclose(rom);
// }
 {
  void wrini(void);

  if (!ignini) wrini();
 }
 gmode(T80);
 textmode(cm);
 textattr(7);
 clrscr();
#ifndef SAFE
 *shiftstate=oldshift; /* DJGPP won't let me get away with this! */
#endif
veow:
 _setcursortype(_NORMALCURSOR);
}
