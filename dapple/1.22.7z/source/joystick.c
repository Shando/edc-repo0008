/*
 * DAPPLE, Apple ][, ][+, //e Emulator
 * Copyright 2002, 2003 Steve Nickolas, portions by Holger Picker
 *
 * Component:  JOYSTICK:  emulate Apple joystick through PC game port
 * Revision:   (1.20) 2002.1229
 * Some code was taken from Andrew Gregory's emulator
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include "dapple.h"

unsigned int GameMinX = 26, GameMinY = 26;
unsigned int GameMaxX = 27, GameMaxY = 27;
unsigned long ClockX, ClockY;                /* Timeouts for 556 timer */
unsigned int LeftAltDown = 0, RightAltDown = 0;

int joya(void)
{
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0;
 int86(0x15,&regs,&regs); /* al */
 {
  extern char *shiftstate;

  if ((*shiftstate & 8) == 8) return 255; /* Alt */
  return ((regs.h.al&0x10)==0)?255:0;
 }
}

int joyb(void)
{
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0;
 int86(0x15,&regs,&regs); /* al */
 {
  extern char *shiftstate;

  if ((*shiftstate & 11) > 8) return 255; /* Shift-Alt */
  return ((regs.h.al&0x20)==0)?255:0;
 }
}

/////////////////////////////////////////////////////////////////////////////

extern unsigned long cycle;

extern int joyenabled;

#pragma argsused
unsigned char ResetGameTimer( unsigned short Address )
{
    unsigned int ReadX, ReadY;
    union REGS regs;

    if (!joyenabled) goto nojoystick;

    /* Get the current position of the game controller */
    regs.h.ah=0x84;
    regs.x.dx=0x0001;
    int86(0x15,&regs,&regs);
    if (regs.x.cflag) goto nojoystick;
    ReadX=regs.x.ax; ReadY=regs.x.bx;

    /* Update maximum ranges */
    if ( ReadX < GameMinX )
    {
        GameMinX = ReadX;
    }
    if ( ReadY < GameMinY )
    {
        GameMinY = ReadY;
    }
    if ( ReadX > GameMaxX )
    {
        GameMaxX = ReadX;
    }
    if ( ReadY > GameMaxY )
    {
        GameMaxY = ReadY;
    }
    /* Convert PC readings to Apple */
    ReadX = ( ReadX - GameMinX ) * 256 / ( GameMaxX - GameMinX );
    ReadY = ( ReadY - GameMinY ) * 256 / ( GameMaxY - GameMinY );
    /* Calculate CPU clock tick at timeout */
    ClockX = cycle +7 + 11 * ReadX;
    ClockY = cycle +7 + 11 * ReadY;

nojoystick:
    return 0;
}

unsigned char ReadGameTimer( unsigned short Address )
{
  if ( Address == 0x64 )
  {
      return ( cycle > ClockX ) ? 0 : 255;  /* Game 0 has timed out */
  }
  if ( Address == 0x65 )
  {
      return ( cycle > ClockY ) ? 0 : 255;  /* Game 1 has timed out */
  }
  return 0;
}

