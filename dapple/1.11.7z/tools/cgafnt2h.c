/*
 * DAPPLE, Apple ][, ][+, //e Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 *
 * Component:  CGAFNT2H:  build tool to generate font header from 2K font
 * Revision:   (1.11) 2002.1224
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>

void main(void)
{
 unsigned char font[2048];
 FILE *file;
 FILE *src;
 int travel;

 file=fopen("dapple.fnt","rb");
 if (!file) {perror("cannot open font");return;}
 src=fopen("font.h","wb");
 if (!src) {perror("cannot open font.h");return;}

 fprintf(src,"/* File generated automatically from dapple.fnt by cgafnt2h - do not modify */\n");
 fprintf(src,"\n");
 fprintf(src,"char AppleFont[2048]=\n{");
 fread(font,1,2048,file);
 fclose(file);
 for (travel=0;travel<2048; travel++)
 {
  if (!(travel%8)) fprintf (src,"\n");
  fprintf (src," 0x%02X",font[travel]);
  if (travel<2047) fprintf (src,",");
 }
 fprintf (src,"\n};");
 fclose(src);
}