#include <bios.h>
#include <stdio.h>

typedef struct
{
 unsigned int head;
 unsigned int track;
 unsigned int sector;
} drvptr;

void sec2hts (drvptr *hts, unsigned int sector)
{
 unsigned int avgtrk;

 hts->sector=sector%18;
 avgtrk=(sector-hts->sector)/18;
 hts->head=avgtrk%2;
 hts->track=(avgtrk-hts->head)/2;

// hts->track++;
 hts->sector++;
}

void report (int err)
{
 switch (err)
 {
  case 0: return;
  case 1: printf ("Bad command"); break;
  case 2: printf ("Address mark not found"); break;
  case 3: printf ("Disk write protect"); exit (-1);
  case 4: printf ("Sector not found"); break;
  case 5: printf ("Reset failed"); break;
  case 6: printf ("Not same disk"); break;
  case 8: printf ("DMA overrun"); break;
  case 9: printf ("DMA crosses segment boundary"); break;
  case 10:printf ("Defective sector"); break;
  case 11:printf ("Defective track"); break;
  case 12:printf ("Unsupported track"); break;
  case 16:printf ("CRC failure"); break;
  case 17:printf ("CRC error, compensating - sector"); break;
  case 32:printf ("Disk controller failure"); exit(1);
  case 64:printf ("Seek error"); break;
  case 128:printf("Attachment failed to respond"); break;
  case 170:printf("Disk not ready"); break;
  case 204:printf("Write fault"); break;
  case 255:printf("Disk autodetect error"); exit(1);
  default:printf ("Unknown error $%02X");
 }
}

int llread (int sector, char *buf)
{
 drvptr hts;
 int e;

 sec2hts(&hts,sector);

 e=biosdisk(2,0,hts.head,hts.track,hts.sector,1,buf);
 if (e) report(e);
 if (e==17) printf ("%d\n",sector);
 if (e==0||e==17) return 0;
 if (e==3) return 1;
 return -1;
}

int llwrite (int sector, char *buf)
{
 drvptr hts;
 int e;

 sec2hts(&hts,sector);

 e=biosdisk(3,0,hts.head,hts.track,hts.sector,1,buf);
 if (e) report(e);
 if (e==0||e==17) return 0;
 if (e==17) printf ("%d\n",sector);
 if (e==3) return 1;
 return -1;
}

void main (int argc, char **argv)
{
 if (argc!=2)
 {
  printf ("usage: %s filename\n",argv[0]);
#ifdef GETDISK
  printf ("       Creates a 1.44MB .po image from a Dapple 0.8 floppy disk\n");
#else
  printf ("       Copies a 1.44MB .po image to a floppy disk compatible with Dapple 0.8\n");
#endif
  return;
 }

 #ifdef GETDISK
 {
  int travel;
  FILE *file;
  char buf[512];

  file=fopen(argv[1],"wb");
  if (!file) {perror (argv[1]); return;}

  for (travel=0; travel<2880; travel++)
  {
   if (llread(travel,buf)) printf (" - cannot read sector %d\n",travel);
   fwrite(buf,1,512,file);
  }

  fclose(file);
 }
 #else
 {
  int travel;
  FILE *file;
  char buf[512];

  file=fopen(argv[1],"rb");
  if (!file) {perror (argv[1]); return;}

  for (travel=0; travel<2880; travel++)
  {
   fread(buf,1,512,file);
   if (llwrite(travel,buf)) printf (" - cannot write sector %d\n",travel);
  }

  fclose(file);
 }
 #endif
}
