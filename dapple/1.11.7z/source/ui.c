/*
 * DAPPLE, Apple ][, ][+, //e Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 *
 * Component:  UI: F10 user interface and file dialog code
 * Revision:   (1.11) 2002.1224
 *
 * File dialog code (function fdialog() in file ui.c) is donated into the
 * public domain and may be extracted from the source tree for use in any
 * program without restriction.  This only applies to the function fdialog()
 * located in the file ui.c and to no other code, unless otherwise
 * specified.  The following applies to the remainder of the code:
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <conio.h>
#include <ctype.h>
#include <dir.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dapple.h"

#define _NOCURSOR      0
#define _SOLIDCURSOR   1
#define _NORMALCURSOR  2

extern enum {emu6502, emuZ80} cpuinuse;

extern unsigned char virtcopy;
extern void virtsetmonochrome(unsigned char mode);
extern unsigned char virtgetmonochrome();
extern void virtsethresmode(unsigned char mode);
extern unsigned char virtgethresmode();
extern void virtsetpalette(unsigned char mode);
extern unsigned char virtgetpalette();
extern void virtinit();

/* dapple.c */
extern unsigned char memnolc;
extern unsigned char keycapslock;
extern unsigned char keyswitchyz;
extern void memoryreset();
extern int smode;

/* cpu65c02.c */
extern void cpureset();

extern int patchrom;
extern unsigned char exitprogram;

extern int nof8;

/* maximum number of filenames for fdialog(), 16 bytes each */
#define MFN 2048

static char NULDSK [] = {"(Empty)"};
enum DiskTypes
{
    UnknownType = 0,
    RawType     = 1,
    DOSType     = 2,
    ProDOSType  = 3,
    SimsysType  = 4,
    XgsType     = 5
};

extern struct DriveState
{
    /* variables for each disk */
    char DiskFN[ 80 ]; /* MS-DOS filename of disk image */
    int DiskFH;        /* MS-DOS file handle of disk image */
    long DiskSize;     /* length of disk image file in bytes */
    enum DiskTypes DiskType; /* Type of disk image */
    int WritePro;      /* 0:write-enabled, !0:write-protected */
    int TrkBufChanged; /* Track buffer has changed */
    int TrkBufOld;     /* Data in track buffer needs updating before I/O */
    int ShouldRecal;
    /* variables used during emulation */
    int Track;    /* 0-70 */
    int Phase;    /* 0- 3 */
    int ReadWP;   /* 0/1  */
    int Active;   /* 0/1  */
    int Writing;  /* 0/1  */
} DrvSt[ 2 ];

int strright (char *tgt, char *src)
{
 int x=strlen(src);

 return !strcmp(&(tgt[strlen(tgt)-x]), src);
}

void fdialog (char *title, char *filename, char *tail, int optnew)
{
 char path[MAXPATH], cwd[MAXPATH];
 int fnnum=0, done=0, cur=0, scr=0, travel=0, gk;
 int drv;

 struct ffblk ffblk;

 typedef struct {char name[14]; int attr;} fnam;
 fnam fnames[MFN];

 _setcursortype(_NOCURSOR);
 clrscr();
 drv=getdisk();
 getcwd(cwd,MAXPATH);
top1:
 fnnum=0, done=0, cur=0, scr=0, travel=0;
 if (optnew)
 {
  fnnum=1;
  strcpy(fnames[0].name,"(New File)");
  fnames[0].attr=0;
 }
 fnnum++;
 strcpy(fnames[fnnum-1].name,"(Select Drive)");
 fnames[fnnum-1].attr=0;
 getcwd(path,MAXPATH);
 gotoxy(1,1);
 clreol();
 if (strlen(path)>35)
 {
  path[35]=0;
  cprintf ("%s...\r\n",path);
 }
 else
 {
  gotoxy(40-(strlen(path)/2),1);
  cprintf("%s\r\n",path);
 }
 cprintf("\
��������������������������������������������������������������������������������\
");
 done=findfirst("*.*",&ffblk,FA_DIREC);
 while (!done && (fnnum<2048))
 {
  strcpy(fnames[fnnum].name,ffblk.ff_name);
  fnames[fnnum].attr=(0!=(ffblk.ff_attrib&FA_DIREC));
  /* Custom mode for tail "._img_" */
  if (!strcmp(tail,"._img_"))
  {
   if ((fnames[fnnum].attr) || (strright(fnames[fnnum].name,".DSK"))
                            || (strright(fnames[fnnum].name,".IIE"))
                            || (strright(fnames[fnnum].name,".2MG"))
                            || (strright(fnames[fnnum].name,".DO"))
                            || (strright(fnames[fnnum].name,".PO"))
                            || (strright(fnames[fnnum].name,".NIB"))) fnnum++;
  }
  else
   if ((fnames[fnnum].attr) || (strright(fnames[fnnum].name,tail))) fnnum++;
  done=findnext(&ffblk);
 }
 gotoxy(1,23);
 clreol();
 cprintf("%s\r\n\
��������������������������������������������������������������������������������\
 Arrows move, <ENTER> selects, <ESC> exits              Folder names end in \"\\\"\
",title);
 gotoxy(1,3);
 for (travel=3; travel<23; travel++) {gotoxy(1,travel); clreol();}
top2:
 if (cur<scr) scr=cur-(cur%20); else while (scr+100<=cur) scr+=20;
 if (scr<0) scr=0;
 for (travel=scr; travel<(scr+20); travel++)
 {
  gotoxy(1,3+(travel-scr));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+20; travel<(scr+40); travel++)
 {
  gotoxy(17,3+(travel-(scr+20)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+40; travel<(scr+60); travel++)
 {
  gotoxy(33,3+(travel-(scr+40)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+60; travel<(scr+80); travel++)
 {
  gotoxy(49,3+(travel-(scr+60)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+80; travel<(scr+100); travel++)
 {
  gotoxy(65,3+(travel-(scr+80)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 textattr(0x07);
top3:
 gk=getch();
 if (!gk) {gk=getch(); gk*=(-1);}
 if (gk==27)
 {
  *filename=0;
  clrscr();
  chdir(cwd);
  _setcursortype(_NORMALCURSOR);
  return;
 }
 if (gk=='\r'||gk=='\n')
 {
  if (!strcmp(fnames[cur].name,"(Select Drive)"))
  {
   gotoxy(1,23);
   clreol();
   cprintf("Enter drive name or <ENTER> to cancel: ");
   _setcursortype(_NORMALCURSOR);
   fgets(filename,128,stdin); /* FIXME */
   gotoxy(1,23);
   clreol();
   cprintf("%s",title);
   _setcursortype(_NOCURSOR);
   filename[strlen(filename)-1]=0;
   if (!*filename) goto top2;
   setdisk(toupper(filename[0])-65);
   goto top1;
  }
  if (!strcmp(fnames[cur].name,"(New File)"))
  {
   gotoxy(1,23);
   clreol();
   cprintf("Type filename or <ENTER> to cancel: ");
   _setcursortype(_NORMALCURSOR);
   fgets(filename,128,stdin); /* FIXME */
   gotoxy(1,23);
   clreol();
   cprintf("%s",title);
   _setcursortype(_NOCURSOR);
   filename[strlen(filename)-1]=0;
   if (!*filename) goto top2;
   clrscr();
   setdisk(drv);
   chdir(cwd);
   _setcursortype(_NORMALCURSOR);
   return;
  }
  if (fnames[cur].attr)
  {
   chdir(fnames[cur].name);
   goto top1;
  }
  getcwd(filename,128);
  if (filename[strlen(filename)-1]!='\\') strcat(filename,"\\");
  strcat(filename,fnames[cur].name);
  clrscr();
  setdisk(drv);
  chdir(cwd);
  _setcursortype(_NORMALCURSOR);
  return;
 }

 if (gk==-71)
 {
  cur=0;
  goto top2;
 }
 if (gk==-72)
 {
  cur--;
  if (cur<0) cur=0;
  goto top2;
 }
 if (gk==-73)
 {
  cur-=100;
  if (cur<0) cur=0;
  goto top2;
 }
 if (gk==-75)
 {
  cur-=20;
  if (cur<0) cur=0;
  goto top2;
 }
 if (gk==-77)
 {
  cur+=20;
  if (cur>=fnnum) cur=fnnum-1;
  goto top2;
 }
 if (gk==-79)
 {
  cur=fnnum-1;
  goto top2;
 }
 if (gk==-80)
 {
  cur++;
  if (cur>=fnnum) cur=fnnum-1;
  goto top2;
 }
 if (gk==-81)
 {
  cur+=100;
  if (cur>=fnnum) cur=fnnum-1;
  goto top2;
 }
 goto top3;
}

int seldisk (char *filename, int drive)
{
 if (DrvSt[drive].DiskFH) UnmountDisk(drive);
 strcpy(DrvSt[drive].DiskFN, filename);
 DrvSt[drive].DiskType = UnknownType;
 MountDisk(drive);
 return DrvSt[drive].DiskFH;
}

char *diskname (int drive)
{
 if (DrvSt[drive].DiskFH) return DrvSt[drive].DiskFN;
 return NULDSK;
}


unsigned char reload (char *bios)
{
 FILE *file;
 extern int ROM16K;

 if (!*bios) return 0;
 cprintf ("Initializing Apple...");
 file=fopen(bios,"rb");
 if (!file)
 {
  perror(bios);
  cprintf("\rSorry, I can't seem to open that file.\r\n");
  cprintf("Press any key to continue... ");
  getch();
  return 0;
 }
 strcpy(rompath,bios);
 {
  unsigned int l;
  ROM16K=0;
  fseek(file,0,SEEK_END);
  l=ftell(file);
  fseek(file,0,SEEK_SET);
  ROM16K=(l==16128);
  if (l==20480) /* ApplePC/AppleWin 12K */
  {
   fseek(file,8192,SEEK_SET);
   ROM16K=0;
  }
  else if (l==32768) /* this gets false positive on //c BIOS */
  {
   fseek(file,16640,SEEK_SET);
   ROM16K=1;
  }
 }
 if (ROM16K) fread(&(ROM[12288]),3840,1,file);
 fread(ROM,12288,1,file);
 fclose(file);

/* init memory */
 memoryclear();
 memoryreset();

/* init display */
 virtinit();
 virtplot(314,2,COL_DRV_OFF);   /* slot #5 drive 1 off at the beginning */
 virtplot(314,4,COL_DRV_OFF);   /* slot #6 drive 1 off at the beginning */
 virtplot(316,4,COL_DRV_OFF);   /* slot #6 drive 2 off at the beginning */
 virtplot(314,6,COL_DRV_OFF);   /* slot #7 drive 1 off at the beginning */
 virtplot(316,6,COL_DRV_OFF);   /* slot #7 drive 2 off at the beginning */
 virtplot(314,199,cpuinuse?COL_DRV_ON:0);
 virtplot(316,199,0);

/* init processor */
 cpureset();
#ifdef EMUZ80
 Z80_Reset();
#endif
 cpuinuse=emu6502;
 return 1;
}


void uidisk (void)
{
 int x;
 char wip[128], hdr[16], bakf[128];

vtop:
 clrscr();
 cprintf("\
[ESC] - Return to main menu\r\n\
\r\n\
[1] - Drive 1: %-20s\r\n\
[C] - Disk type: %s\r\n\
\n\
[2] - Drive 2: %-20s\r\n\
[D] - Disk type: %s\r\n\
\n\
", diskname(0), (DrvSt[0].DiskType==RawType)?"Nibble   ":
                (DrvSt[0].DiskType==DOSType)?"DOS Order":
                (DrvSt[0].DiskType==SimsysType)?"SimSystem":
                (DrvSt[0].DiskType==XgsType)?"2MG/XGS":"ProDOS Order",
   diskname(1), (DrvSt[1].DiskType==RawType)?"Nibble   ":
                (DrvSt[1].DiskType==DOSType)?"DOS Order":
                (DrvSt[1].DiskType==SimsysType)?"SimSystem":
                (DrvSt[1].DiskType==XgsType)?"2MG/XGS":"ProDOS Order");

top:
 x=getch();
 if (x==27) return;
 if (x=='C'||x=='c')
 {
  if (DrvSt[0].DiskType>ProDOSType) goto vtop; /* special type */
  DrvSt[0].DiskType=(DrvSt[0].DiskType==RawType)?DOSType:
                    (DrvSt[0].DiskType==DOSType)?ProDOSType:RawType;
  goto vtop;
 }
 if (x=='D'||x=='d')
 {
  if (DrvSt[1].DiskType>ProDOSType) goto vtop; /* special type */
  DrvSt[1].DiskType=(DrvSt[1].DiskType==RawType)?DOSType:
                    (DrvSt[1].DiskType==DOSType)?ProDOSType:RawType;
  goto vtop;
 }
 if (x!=49 && x!=50) goto top; /* not '1' or '2' */
 x-=49;

 sprintf(hdr,"Drive %d (*.DSK, *.NIB, *.IIE, *.DO, *.PO, *.2MG)",x+1);
 fdialog(hdr,wip,"._img_",1);
 if (*wip) seldisk(wip,x);
 goto vtop;
}

void uiport (void)
{
 int x;
 char wip[128], hdr[16], bakf[128];
 extern char parallel[128];
 extern int TrackBufLen, dqhdv, fake80, tweakpic, dqshift;
 extern int joyenabled;

vtop:
 clrscr();
 cprintf("\
[ESC] - Return to main menu\r\n\
\r\n\
[1] - Parallel Port File: %-20s\r\n\
[6] - Disk ][ emulation mode: %s\r\n\
[7] - Hard Disk Interface: %s\r\n\
[A] - Preserve High Parallel: %s\r\n\
[J] - Joystick: %s\r\n\
[S] - Shift Key Modification: %s\r\n\
\n\
", parallel,
   TrackBufLen==6250?"Like real drives":"Like other emulators",
   dqhdv?"Off":"On",
   tweakpic?"Yes":"No",
   joyenabled?"Enabled":"Disabled",
   dqshift?"Off":"On");

top:
 x=getch();
 if (x==27) return;
 if (x==49)
 {
  sprintf(hdr,"Parallel Port: (Device may be entered as new file) (*.PRN)",x+1);
  fdialog(hdr,wip,".PRN",1);
  if (*wip) strcpy(parallel,wip);
  goto vtop;
 }
 if (x==54)
 {
  extern int FastMode;

  TrackBufLen=(TrackBufLen==6250)?0x1a00:6250;
  FastMode=(TrackBufLen==6250)?0:1;
  goto vtop;
 }
 if (x==55)
 {
  dqhdv=(!dqhdv);
  goto vtop;
 }
 if (x==65||x==97)
 {
  tweakpic=(!tweakpic);
  goto vtop;
 }
 if (x=='J'||x=='j')
 {
  joyenabled=!joyenabled;
  goto vtop;
 }
 if (x=='S'||x=='s')
 {
  dqshift=(!dqshift);
  goto vtop;
 }
 goto top;
}

void uikey () {
  extern int shiftshutoff;

  unsigned char x;
  unsigned char update;

  update = 1;
  do {
    if (update) {
      update = 0;
      clrscr();
      cprintf ("\
[ESC] - Return to main menu\r\n\
\r\n\
[C] - Reverse Caps Lock: %s\r\n\
[M] - Manipulate Caps Lock: %s\r\n\
[S] - Switch keys 'Y' and 'Z': %s\r\n\
[P] - Print screen on F8: %s\r\n\
\r\n\
Caps Lock manipulation settings will not\r\n\
take effect until the next time Dapple\r\n\
is run.\r\n\
\r\n",
   (keycapslock ? "Yes" : "No"),
   (shiftshutoff? "No" : "Yes"),
   (keyswitchyz ? "Yes" : "No"),
   (nof8        ? "No" : "Yes"));
   } /* if (update) */

    x = getch();
    switch (x) {
      case 'c' :
      case 'C' :
        keycapslock = !keycapslock;
        update = 1;
        break;
      case 'M': case 'm':
        shiftshutoff = !shiftshutoff;
        update = 1;
        break;
      case 's' :
      case 'S' :
        keyswitchyz = !keyswitchyz;
        update = 1;
        break;
      case 'P': case 'p':
        nof8=!nof8;
        update=1;
        break;
    } /* switch (x) */
  } /* do */
  while (x != 27);
} /* uikey */

void uibio (void)
{
 int x;
 char wip[128];

vtop:
 clrscr();
 cprintf ("\
[ESC] - Return to main menu\r\n\
\r\n\
[S] - Select ROM file (%s)\r\n\
[1] - Apple ][ - Monitor    %c\r\n\
[2] - Apple ][ - Autostart  %c\r\n\
[3] - Apple ][ Plus         %c\r\n\
[4] - Apple //e - ][ Title  %c\r\n\
[5] - Apple //e Enhanced    %c\r\n\
\r\n\
[M] - Maximum ][/][+ RAM [%s]\r\n\
\r\n\
(RAM in //e mode is always 128K)\r\n\
\r\n\
",rompath,
  0!=strstr(rompath,"apple2m.rom")?42:32,
  0!=strstr(rompath,"apple2o.rom")?42:32,
  0!=strstr(rompath,"apple.rom")?42:32,
  0!=strstr(rompath,"apple2eo.rom")?42:32,
  0!=strstr(rompath,"apple2ee.rom")?42:32,
  memnolc?"48K":"64K"
);
top:
 x=getch();
 if (x==27) return;
 if (x==49/* '1' */) reload("apple2m.rom");
 if (x==50/* '2' */) reload("apple2o.rom");
 if (x==51/* '3' */) reload("apple.rom");
 if (x==52/* '4' */) reload("apple2eo.rom");
 if (x==53/* '5' */) reload("apple2ee.rom");
 if (x=='M'||x=='m') memnolc=!memnolc;
 if (x=='S'||x=='s')
 {
  fdialog("BIOS Image (*.ROM)",wip,".ROM",1);
  reload(wip);
 }
 goto vtop;
}

int xbsave (char *filename, int address, int length, int usehdr)
{
 FILE *file;

 file=fopen(filename,"wb");
 if (!file) return -1;
 if (usehdr)
 {
  fwrite(&address,1,2,file);
  fwrite(&length,1,2,file);
 }
 fwrite(&(RAM[address]),1,length,file);
 fclose(file);
 return 0;
}

int absave (char *filename)
{
 FILE *file;
 int address, length;
 int *ptr;

 file=fopen(filename,"wb");
 if (!file) return -1;
 ptr=(int*) (&(RAM[0xAA72U]));
 address=*ptr;
 ptr=(int*) (&(RAM[0xAA60U]));
 length=*ptr;
 fwrite(&address,1,2,file);
 fwrite(&length,1,2,file);
 fwrite(&(RAM[address]),1,length,file);
 fclose(file);
 return 0;
}

int fman(void)
{
 int brun(char *filename); /* in dapple.c */
 int x,address,length;
 int laddr;
 char wip[128],addrw[128],lenw[128];
 int xbload (char *filename);

 laddr=-1370;
vtop:
 clrscr();
 cprintf ("\
[ESC] - Return to main menu\r\n\
\r\n\
[R] - BLOAD PG2 file\r\n\
[W] - BSAVE PG2 or BIN file\r\n\
[X] - Execute last PG2 file loaded\r\n\
[L] - LOAD FP file (imperfect)\r\n\
[S] - SAVE FP file (imperfect)\r\n\
\r\n\
");
top:
 x=getch();
 if (x==27) return 0;
 if (x=='X'||x=='x') if (laddr==-1370)
 {
  cprintf ("A file must first be loaded.\r");
  goto top;
 }
 if (x=='X'||x=='x') if (laddr!=-1370) { cpusetpc(laddr); return -2;}
 if (x=='L'||x=='S'||x=='l'||x=='s') goto top2;
 if (x!='R'&&x!='W'&&x!='r'&&x!='w') goto vtop;
 fdialog("Name of image (*.PG2)",wip,".PG2",toupper(x)!='R');
 if (!*wip) goto vtop;
 if (x=='R'||x=='r') {laddr=xbload(wip);goto vtop;}
 cprintf ("Enter address (or 'AUTO' to ask DOS 3.3): ");
 fgets(addrw,128,stdin); /* FIXME */
 addrw[strlen(addrw)-1]=0;
 if (!stricmp(addrw,"AUTO"))
 {
  absave(wip);
  goto vtop;
 }
 address=atoi(addrw);
 cprintf ("Enter length: ");
 fgets(lenw,128,stdin); /* FIXME */
 lenw[strlen(lenw)-1]=0;
 length=atoi(lenw);
 cprintf ("Add PG2 header? (y/n) ");
 x=0; while (x!='Y'&&x!='y'&&x!='N'&&x!='n') x=getch();
 xbsave(wip,address,length,(x=='Y'||x=='y'));
 goto vtop;
top2:
 fdialog("Name of program (*.FP)",wip,".FP",toupper(x)!='L');
 if (!*wip) goto vtop;
 if (x=='L'||x=='l') loadbas(wip); else savebas(wip);
 goto vtop;
}

void uivid(void)
{
  unsigned char x;
  unsigned char update;

  update = 1;
  do {
    if (update) {
      update = 0;
      clrscr();

      cprintf ("\
[ESC] - Return to main menu\r\n\
\n\
[C] - Color screen                  %c\r\n\
[G] - Green screen                  %c\r\n\
[M] - Monochrome screen (white)     %c\r\n\
[A] - Amber screen                  %c\r\n\
Note: Lo-res graphics remain in color.\r\n\
\n\
      Hi-res mode:\r\n\
[S] - Standard hires display        %c\r\n\
[R] - RGB hires display             %c\r\n\
\n\
      Lo-res/Hi-res color palette:\r\n\
[0] - Palette 0 (Apple IIgs)        %c\r\n\
[1] - Palette 1 (Standard)          %c\r\n\
[2] - Palette 2 (ApplePC-like)      %c\r\n\
[3] - Palette 3 (MESS-like)         %c\r\n\
[4] - Palette 4 (PC-like 16-color)  %c\r\n\
"
  ,virtgetmonochrome()==0?42:32
  ,virtgetmonochrome()==2?42:32
  ,virtgetmonochrome()==1?42:32
  ,virtgetmonochrome()==3?42:32
  ,virtgethresmode()==0?42:32
  ,virtgethresmode()==1?42:32
  ,virtgetpalette()==0?42:32
  ,virtgetpalette()==1?42:32
  ,virtgetpalette()==2?42:32
  ,virtgetpalette()==3?42:32
  ,virtgetpalette()==4?42:32
  );
    } /* if (update) */

    x=getch();
    switch (x) {
      case '0' :
        virtsetpalette(0);
        update = 1;
        break;
      case '1' :
        virtsetpalette(1);
        update = 1;
        break;
      case '2' :
        virtsetpalette(2);
        update = 1;
        break;
      case '3' :
        virtsetpalette(3);
        update = 1;
        break;
      case '4' :
        virtsetpalette(4);
        update = 1;
        break;
     case 'a' :
     case 'A' :
        virtsetmonochrome(3);
        update = 1;
        break;
      case 'c' :
      case 'C' :
        virtsetmonochrome(0);
        update = 1;
        break;
      case 'g' :
      case 'G' :
        virtsetmonochrome(2);
        update = 1;
        break;
      case 'm' :
      case 'M' :
        virtsetmonochrome(1);
        update = 1;
        break;
      case 'r' :
      case 'R' :
        virtsethresmode(1);
        update = 1;
        break;
      case 's' :
      case 'S' :
        virtsethresmode(0);
        update = 1;
        break;
    } /* switch */
  }
  while (x != 27);

}

void uisnd(void)
{
 int x;
 extern int sounddelay;

vtop:
 clrscr();
 cprintf ("\
[ESC] - Return to main menu\r\n\
\r\n\
[S] - Speaker      (%s)\r\n\
[Q] - Speaker Type (%s)  \r\n\
",smode?"enabled":"disabled",
 sounddelay==0?"Dapple Standard (fast, raspy)":
 sounddelay==1?"Dapple TC2 (slower but cleaner)":
 sounddelay==2?"Andrew Gregory's speaker code":
               "??? - Invalid code specified!"
);
top:
 x=getch();
 if (x==27) return;
 if (x=='S'||x=='s') smode=!smode;
 if (x=='Q'||x=='q') {sounddelay++; if (sounddelay>2) sounddelay=0;}
 goto vtop;
}

void charset(void)
{
 int x;

vtop:
 clrscr();
 cprintf("\
[ESC] - Return to main menu\r\n\
\r\n\
[A] - USA        %c\r\n\
[F] - France     %c\r\n\
[G] - Germany    %c\r\n\
[E] - UK         %c\r\n\
[D] - Denmark 1  %c\r\n\
[W] - Sweden     %c\r\n\
[I] - Italy      %c\r\n\
[S] - Spain      %c\r\n\
[J] - Japan      %c\r\n\
[N] - Norway     %c\r\n\
[K] - Denmark 2  %c\r\n\
\r\n\
",charmode==USA?42:32,
  charmode==France?42:32,
  charmode==Germany?42:32,
  charmode==UK?42:32,
  charmode==Denmark1?42:32,
  charmode==Sweden?42:32,
  charmode==Italy?42:32,
  charmode==Spain?42:32,
  charmode==Japan?42:32,
  charmode==Norway?42:32,
  charmode==Denmark2?42:32
);
top:
 x=getch();
 if (x==27) return;
 if (x=='A'||x=='a') charmode=USA;
 if (x=='F'||x=='f') charmode=France;
 if (x=='G'||x=='g') charmode=Germany;
 if (x=='E'||x=='e') charmode=UK;
 if (x=='D'||x=='d') charmode=Denmark1;
 if (x=='W'||x=='w') charmode=Sweden;
 if (x=='I'||x=='i') charmode=Italy;
 if (x=='S'||x=='s') charmode=Spain;
 if (x=='J'||x=='j') charmode=Japan;
 if (x=='N'||x=='n') charmode=Norway;
 if (x=='K'||x=='k') charmode=Denmark2;
 goto vtop;
}

void uimain(void)
{
 char x;
 char wip[128];

vtop:
 gmode(T80);
 clrscr();
 _setcursortype(_NORMALCURSOR);
 cprintf ("\
             Dapple v%s\r\n\
        (C) 2002 Steve Nickolas\r\n\
    small portions by Holger Picker\r\n\
",DappleVersion);
 printf ("\
\r\n\
[ESC] - Resume emulation\r\n\
\r\n\
[B] - BIOS select\r\n\
[C] - Character set select\r\n\
[D] - Disk select\r\n\
[F] - File import/export\r\n\
[K] - Keyboard options\r\n\
[L] - Load image\r\n\
[N] - Sound options\r\n\
[P] - Port options\r\n\
[S] - Save image\r\n\
[V] - Video options\r\n\
[W] - Wait states\r\n\
");
 printf("[Q] - Quit to DOS\r\n\r\n");

top:
 x=getch();

 if (x==27)
 {
  _setcursortype(_NOCURSOR);
  clrscr();
  opengraph();
  virtcopy = 1;
  return;
 }

  switch (x) {

    case 'b' :
    case 'B' :
      uibio();
      goto vtop;

    case 'c' :
    case 'C' :
      charset();
      goto vtop;

    case 'd' :
    case 'D' :
      uidisk();
      goto vtop;

    case 'f' :
    case 'F' :
      if (!fman()) goto vtop;
      _setcursortype(_NOCURSOR);
      clrscr();
      opengraph();
      virtcopy = 1;
      return;

    case 'k' :
    case 'K' :
      uikey();
      goto vtop;

    case 'l' :
    case 'L' :
      fdialog("Name of image (*.PGX)",wip,".PGX",0);
      if (!*wip) goto vtop;
      imrs(wip);
      goto vtop;

    case 'n' :
    case 'N' :
      uisnd();
      goto vtop;

    case 'p' :
    case 'P' :
      uiport();
      goto vtop;

    case 'q' :
    case 'Q' :
      printf ("Quit to DOS: Are you sure? (y/n) ");
      x=getch();
      if (x=='Y'||x=='y') {
        cpuinuse=emu6502;
        exitprogram = 1;
        return;
      }
      goto vtop;

    case 's' :
    case 'S' :
      fdialog("Name of image (*.PGX)",wip,".PGX",1);
      if (!*wip) goto vtop;
      immk(wip);
      goto vtop;

    case 'v' :
    case 'V' :
      uivid();
      goto vtop;

    case 'w' :
    case 'W' : {
      extern unsigned int hold;
      unsigned int tmphold;

      printf ("Enter delay in hex (ENTER keeps current $%04X): ",hold);
      fgets(wip,128,stdin);
      if (*wip=='\n') goto vtop;
      if (!sscanf(wip,"%04x",&tmphold)) goto vtop;
      hold=tmphold&0x7FFF;
      goto vtop;
    }
  } /* switch (x) */

 goto top;
}
