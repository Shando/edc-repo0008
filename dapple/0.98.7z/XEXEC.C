/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  XEXEC: Replacement for M6502's Run6502()
 * Revision:   (Diana 0.93) 2002.1108
 *             0.33 "LOST KEY WEEKEND"
 */

#include "m6502.h"

int  Z80_Execute (void);
extern enum {emu6502, emuZ80} cpuinuse;

unsigned long ClockTick=0;
static int ctdif;
extern int hold;

word XRun6502(M6502 *R)
{
  register pair J,K;
  register byte I;

  for(;;)
  {
#ifdef DEBUG
    /* Turn tracing on when reached trap address */
    if(R->PC.W==R->Trap) R->Trace=1;
#endif

    ctdif=0;

    ctdif=R->ICount; // uso.
    if (cpuinuse==emuZ80) Z80_Execute(); else Exec6502(R);
    ClockTick+=(ctdif-R->ICount); // uso.

    if (hold)
    {//uso.
     int travel;

     for (travel=1; travel<hold; travel++);
    }

    /* If cycle counter expired... */
    if(R->ICount<=0 || cpuinuse==emuZ80)
    {
      /* If we have come after CLI, get INT_? from IRequest */
      /* Otherwise, get it from the loop handler            */
      if(R->AfterCLI && cpuinuse!=emuZ80)
      {
        I=R->IRequest;            /* Get pending interrupt     */
        R->ICount+=R->IBackup-1;  /* Restore the ICount        */
        R->AfterCLI=0;            /* Done with AfterCLI state  */
      }
      else
      {
        I=Loop6502(R);            /* Call the periodic handler */
        R->ICount=R->IPeriod;     /* Reset the cycle counter   */
      }

      if(I==INT_QUIT) return(R->PC.W); /* Exit if INT_QUIT     */
      if(I) Int6502(R,I);              /* Interrupt if needed  */
    }
  }

  /* Execution stopped */
//  return(R->PC.W);
}
