/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  HGR:  hi-res screen manipulation
 * Revision:   (0.67a) 2002.0907
 *             0.33 "LOST KEY WEEKEND"
 */

#include <stdio.h>
#include <conio.h>
#include "dapple.h"

int autoplot=1;

void xpset (int x,int y,int c)
{
 pset(x,y,c);
}

struct tpoint hrelpix (int addr)
{
 /* by 1/3 (40), 1/8 (128), 1 (1024) */
 int by40,by128,by1024;

 struct tpoint t;

 int a;

 t.y=((addr-(addr%1024))/1024); /* one line for each 1024 */
 by1024=addr%1024;
 t.y+=(8*((by1024-(by1024%128))/128));
 by128=by1024%128;
 t.y+=(64*((by128-(by128%40))/40));
 t.x=(by128%40)*7;
 return t;
}
