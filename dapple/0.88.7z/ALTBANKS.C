unsigned char bankram1[49152];
unsigned char bankram2[16384];