/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  UI: F10 user interface and file dialog code
 * Revision:   (Diana 0.90pt1) 2002.1030
 *             0.33 "LOST KEY WEEKEND"
 *
 * File dialog code (function fdialog() in file ui.c) is donated into the
 * public domain and may be extracted from the source tree for use in any
 * program without restriction.  This only applies to the function fdialog()
 * located in the file ui.c and to no other code, unless otherwise
 * specified.  For license information on the remainder of the program, view
 * license.txt
 *
 */

#include <conio.h>
#include <ctype.h>
#include <dir.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "m6502.h"
#include "dapple.h"

#define _NOCURSOR      0
#define _SOLIDCURSOR   1
#define _NORMALCURSOR  2

extern enum {emu6502, emuZ80} cpuinuse;

extern int patchrom;

/* maximum number of filenames for fdialog(), 16 bytes each */
#define MFN 2048

struct rgb PALETTE[256];

char ROM3[256];

static char NULDSK [] = {"(Empty)"};
enum DiskTypes
{
    UnknownType = 0,
    RawType     = 1,
    DOSType     = 2,
    ProDOSType  = 3,
    SimsysType  = 4,
    XgsType     = 5
};

extern struct DriveState
{
    /* variables for each disk */
    char DiskFN[ 80 ]; /* MS-DOS filename of disk image */
    int DiskFH;        /* MS-DOS file handle of disk image */
    long DiskSize;     /* length of disk image file in bytes */
    enum DiskTypes DiskType; /* Type of disk image */
    int WritePro;      /* 0:write-enabled, !0:write-protected */
    int TrkBufChanged; /* Track buffer has changed */
    int TrkBufOld;     /* Data in track buffer needs updating before I/O */
    int ShouldRecal;
    /* variables used during emulation */
    int Track;    /* 0-70 */
    int Phase;    /* 0- 3 */
    int ReadWP;   /* 0/1  */
    int Active;   /* 0/1  */
    int Writing;  /* 0/1  */
} DrvSt[ 2 ];

int debugger=0;

int strright (char *tgt, char *src)
{
 int x=strlen(src);

 return !strcmp(&(tgt[strlen(tgt)-x]), src);
}

void fdialog (char *title, char *filename, char *tail, int optnew)
{
 char path[MAXPATH], cwd[MAXPATH];
 int fnnum=0, done=0, cur=0, scr=0, travel=0, gk;

 struct ffblk ffblk;

 typedef struct {char name[14]; int attr;} fnam;
 fnam fnames[MFN];

 _setcursortype(_NOCURSOR);
 clrscr();
 getcwd(cwd,MAXPATH);
top1:
 fnnum=0, done=0, cur=0, scr=0, travel=0;
 if (optnew)
 {
  fnnum=1;
  strcpy(fnames[0].name,"(New File)");
  fnames[0].attr=0;
 }
 getcwd(path,MAXPATH);
 gotoxy(1,1);
 clreol();
 if (strlen(path)>35)
 {
  path[35]=0;
  printf ("%s...\n",path);
 }
 else
 {
  gotoxy(40-(strlen(path)/2),1);
  printf("%s\n",path);
 }
 printf("\
��������������������������������������������������������������������������������\
");
 done=findfirst("*.*",&ffblk,FA_DIREC);
 while (!done && (fnnum<2048))
 {
  strcpy(fnames[fnnum].name,ffblk.ff_name);
  fnames[fnnum].attr=(0!=(ffblk.ff_attrib&FA_DIREC));
  /* Custom mode for tail "._img_" */
  if (!strcmp(tail,"._img_"))
  {
   if ((fnames[fnnum].attr) || (strright(fnames[fnnum].name,".DSK"))
                            || (strright(fnames[fnnum].name,".IIE"))
                            || (strright(fnames[fnnum].name,".2MG"))
                            || (strright(fnames[fnnum].name,".DO"))
                            || (strright(fnames[fnnum].name,".PO"))
                            || (strright(fnames[fnnum].name,".NIB"))) fnnum++;
  }
  else
   if ((fnames[fnnum].attr) || (strright(fnames[fnnum].name,tail))) fnnum++;
  done=findnext(&ffblk);
 }
 gotoxy(1,23);
 clreol();
 printf("%s\n\
��������������������������������������������������������������������������������\
 Arrows move, <ENTER> selects, <ESC> exits              Folder names end in \"\\\"\
",title);
 gotoxy(1,3);
 for (travel=3; travel<23; travel++) {gotoxy(1,travel); clreol();}
top2:
 if (cur<scr) scr=cur-(cur%20); else while (scr+100<=cur) scr+=20;
 if (scr<0) scr=0;
 for (travel=scr; travel<(scr+20); travel++)
 {
  gotoxy(1,3+(travel-scr));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+20; travel<(scr+40); travel++)
 {
  gotoxy(17,3+(travel-(scr+20)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+40; travel<(scr+60); travel++)
 {
  gotoxy(33,3+(travel-(scr+40)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+60; travel<(scr+80); travel++)
 {
  gotoxy(49,3+(travel-(scr+60)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 for (travel=scr+80; travel<(scr+100); travel++)
 {
  gotoxy(65,3+(travel-(scr+80)));
  if (travel>=fnnum)
  {
   textattr(0x07);
   cprintf ("%-16c",32);
  }
  else
  {
   if (travel==cur) textattr(0x70); else textattr(0x07);
   cprintf (" %-13s%c ",fnames[travel].name,fnames[travel].attr?'\\':32);
  }
 }
 textattr(0x07);
top3:
 gk=getch();
 if (!gk) {gk=getch(); gk*=(-1);}
 if (gk==27)
 {
  *filename=0;
  clrscr();
  chdir(cwd);
  _setcursortype(_NORMALCURSOR);
  return;
 }
 if (gk=='\r'||gk=='\n')
 {
  if (!strcmp(fnames[cur].name,"(New File)"))
  {
   gotoxy(1,23);
   clreol();
   cprintf("Type filename or <ENTER> to cancel: ");
   _setcursortype(_NORMALCURSOR);
   fgets(filename,128,stdin);
   gotoxy(1,23);
   clreol();
   printf("%s",title);
   _setcursortype(_NOCURSOR);
   filename[strlen(filename)-1]=0;
   if (!*filename) goto top2;
   clrscr();
   chdir(cwd);
   _setcursortype(_NORMALCURSOR);
   return;
  }
  if (fnames[cur].attr)
  {
   chdir(fnames[cur].name);
   goto top1;
  }
  getcwd(filename,128);
  if (filename[strlen(filename)-1]!='\\') strcat(filename,"\\");
  strcat(filename,fnames[cur].name);
  clrscr();
  chdir(cwd);
  _setcursortype(_NORMALCURSOR);
  return;
 }

 if (gk==-71)
 {
  cur=0;
  goto top2;
 }
 if (gk==-72)
 {
  cur--;
  if (cur<0) cur=0;
  goto top2;
 }
 if (gk==-73)
 {
  cur-=100;
  if (cur<0) cur=0;
  goto top2;
 }
 if (gk==-75)
 {
  cur-=20;
  if (cur<0) cur=0;
  goto top2;
 }
 if (gk==-77)
 {
  cur+=20;
  if (cur>=fnnum) cur=fnnum-1;
  goto top2;
 }
 if (gk==-79)
 {
  cur=fnnum-1;
  goto top2;
 }
 if (gk==-80)
 {
  cur++;
  if (cur>=fnnum) cur=fnnum-1;
  goto top2;
 }
 if (gk==-81)
 {
  cur+=100;
  if (cur>=fnnum) cur=fnnum-1;
  goto top2;
 }
 goto top3;
}

int seldisk (char *filename, int drive)
{
 if (DrvSt[drive].DiskFH) UnmountDisk(drive);
 strcpy(DrvSt[drive].DiskFN, filename);
 DrvSt[drive].DiskType = UnknownType;
 MountDisk(drive);
 return DrvSt[drive].DiskFH;
}

char *diskname (int drive)
{
 if (DrvSt[drive].DiskFH) return DrvSt[drive].DiskFN;
 return NULDSK;
}

void reload (char *bios, M6502 *proc)
{
 FILE *file;
 extern int ROM16K;

 if (!*bios) return;
 printf ("Initializing Apple...");
 file=fopen(bios,"rb");
 if (!file)
 {
  perror(bios);
  printf("\rSorry, I can't seem to open that file.\n");
  printf("Press any key to continue... ");
  getch();
  return;
 }
 strcpy(rompath,bios);
 {
  unsigned int l;
  ROM16K=0;
  fseek(file,0,SEEK_END);
  l=ftell(file);
  fseek(file,0,SEEK_SET);
  ROM16K=(l==16128);
  if (l==20480) /* ApplePC/AppleWin 12K */
  {
   fseek(file,8192,SEEK_SET);
   ROM16K=0;
  }
  else if (l==32768) /* this gets false positive on //c BIOS */
  {
   fseek(file,16640,SEEK_SET);
   ROM16K=1;
  }
 }
 if (ROM16K) fread(&(ROM[12288]),3840,1,file);
 fread(ROM,1,12288,file);
 fclose(file);
 memset(RAM,0,49152);
 memset(RAMEXT,0,16384);
 if (patchrom) ROM[12288-1101]=234;
 rbank=BANK0;
 wbank=BANK0;
 Reset6502(proc);
 {
  cpuinuse=emu6502;
 }
}

void uidisk (void)
{
 int x;
 char wip[128], hdr[16], bakf[128];

vtop:
 clrscr();
 printf("\
[ESC] - Return to main menu\n\
\n\
[1] - Drive 1: %-20s\n\
[C] - Disk type: %s\n\
\n\
[2] - Drive 2: %-20s\n\
[D] - Disk type: %s\n\
\n\
", diskname(0), (DrvSt[0].DiskType==RawType)?"Nibble   ":
                (DrvSt[0].DiskType==DOSType)?"DOS Order":
                (DrvSt[0].DiskType==SimsysType)?"SimSystem":
                (DrvSt[0].DiskType==XgsType)?"2MG/XGS":"ProDOS Order",
   diskname(1), (DrvSt[1].DiskType==RawType)?"Nibble   ":
                (DrvSt[1].DiskType==DOSType)?"DOS Order":
                (DrvSt[1].DiskType==SimsysType)?"SimSystem":
                (DrvSt[1].DiskType==XgsType)?"2MG/XGS":"ProDOS Order");

top:
 x=getch();
 if (x==27) return;
 if (x=='C'||x=='c')
 {
  if (DrvSt[0].DiskType>ProDOSType) goto vtop; /* special type */
  DrvSt[0].DiskType=(DrvSt[0].DiskType==RawType)?DOSType:
                    (DrvSt[0].DiskType==DOSType)?ProDOSType:RawType;
  goto vtop;
 }
 if (x=='D'||x=='d')
 {
  if (DrvSt[1].DiskType>ProDOSType) goto vtop; /* special type */
  DrvSt[1].DiskType=(DrvSt[1].DiskType==RawType)?DOSType:
                    (DrvSt[1].DiskType==DOSType)?ProDOSType:RawType;
  goto vtop;
 }
 if (x!=49 && x!=50) goto top; /* not '1' or '2' */
 x-=49;

 sprintf(hdr,"Drive %d (*.DSK, *.NIB, *.IIE, *.DO, *.PO, *.2MG)",x+1);
 fdialog(hdr,wip,"._img_",1);
 if (*wip) seldisk(wip,x);
 goto vtop;
}

void uiport (void)
{
 int x;
 char wip[128], hdr[16], bakf[128];
 extern char parallel[128];
 extern int TrackBufLen, dqhdv, fake80, tweakpic;

vtop:
 clrscr();
 printf("\
[ESC] - Return to main menu\n\
\n\
[1] - Parallel Port File: %-20s\n\
[3] - Fake terminal card: %s\n\
[6] - Disk ][ Buffer: %u\n\
[7] - Hard Disk Interface: %s\n\
[A] - Preserve High Parallel: %s\n\
\n\
", parallel,
   fake80?"Yes":"No",
   TrackBufLen,
   dqhdv?"Off":"On",
   tweakpic?"Yes":"No");

top:
 x=getch();
 if (x==27) return;
 if (x==49)
 {
  sprintf(hdr,"Parallel Port: (Device may be entered as new file) (*.PRN)",x+1);
  fdialog(hdr,wip,".PRN",1);
  if (*wip) strcpy(parallel,wip);
  goto vtop;
 }
 if (x==51)
 {
  fake80=96-fake80;
  goto vtop;
 }
 if (x==54)
 {
  TrackBufLen=(TrackBufLen==6250)?0x1a00:6250;
  goto vtop;
 }
 if (x==55)
 {
  dqhdv=(!dqhdv);
  goto vtop;
 }
 if (x==65)
 {
  tweakpic=(!tweakpic);
  goto vtop;
 }
 goto top;
}

void uibio (M6502 *proc)
{
 int x;
 char wip[128];

vtop:
 clrscr();
 printf ("\
[ESC] - Return to main menu\n\
\n\
[S] - Select ROM file (%s)\n\
[1] - Apple ][ - Monitor    %c\n\
[2] - Apple ][ - Autostart  %c\n\
[3] - Apple ][ Plus         %c\n\
[4] - Apple //e - ][ Title  %c\n\
[5] - Apple //e Enhanced    %c\n\
[L] - Language card [%s]\n\
\n\
",rompath,
  0!=strstr(rompath,"apple2m.rom")?42:32,
  0!=strstr(rompath,"apple2o.rom")?42:32,
  0!=strstr(rompath,"apple.rom")?42:32,
  0!=strstr(rompath,"apple2eo.rom")?42:32,
  0!=strstr(rompath,"apple2ee.rom")?42:32,
  membankon?"enabled":"disabled"
);
top:
 x=getch();
 if (x==27) return;
 if (x==49/* '1' */) reload("apple2m.rom",proc);
 if (x==50/* '2' */) reload("apple2o.rom",proc);
 if (x==51/* '3' */) reload("apple.rom",proc);
 if (x==52/* '4' */) reload("apple2eo.rom",proc);
 if (x==53/* '5' */) reload("apple2ee.rom",proc);
 if (x=='L'||x=='l') membankon=!membankon;
 if (x=='S'||x=='s')
 {
  fdialog("BIOS Image (*.ROM)",wip,".ROM",1);
  reload(wip,proc);
 }
 goto vtop;
}

int xbsave (char *filename, int address, int length, int usehdr)
{
 FILE *file;

// if ((unsigned)(address+length)>(unsigned)49151) return -1;
 file=fopen(filename,"wb");
 if (!file) return -1;
 if (usehdr)
 {
  fwrite(&address,1,2,file);
  fwrite(&length,1,2,file);
 }
 fwrite(&(RAM[address]),1,length,file);
 fclose(file);
 return 0;
}

int absave (char *filename)
{
 FILE *file;
 int address, length;
 int *ptr;

 file=fopen(filename,"wb");
 if (!file) return -1;
 ptr=(int*) (&(RAM[0xAA72U]));
 address=*ptr;
 ptr=(int*) (&(RAM[0xAA60U]));
 length=*ptr;
 fwrite(&address,1,2,file);
 fwrite(&length,1,2,file);
 fwrite(&(RAM[address]),1,length,file);
 fclose(file);
 return 0;
}

int fman(void)
{
 int brun(char *filename); /* in dapple.c */
 int x,address,length;
 int laddr;
 char wip[128],addrw[128],lenw[128];
 int xbload (char *filename);
 extern M6502 *_proc;

 laddr=-1370;
vtop:
 clrscr();
 printf ("\
[ESC] - Return to main menu\n\
\n\
[R] - BLOAD PG2 file\n\
[W] - BSAVE PG2 or BIN file\n\
[X] - Execute last PG2 file loaded\n\
[L] - LOAD FP file\n\
[S] - SAVE FP file\n\
\n\
");
top:
 x=getch();
 if (x==27) return 0;
 if (x=='X'||x=='x') if (laddr==-1370)
 {
  printf ("A file must first be loaded.");
  goto top;
 }
 if (x=='X'||x=='x') if (laddr!=-1370) {_proc->PC.W=laddr; return -2;}
 if (x=='L'||x=='S'||x=='l'||x=='s') goto top2;
 if (x!='R'&&x!='W'&&x!='r'&&x!='w') goto vtop;
 fdialog("Name of image (*.PG2)",wip,".PG2",toupper(x)!='R');
 if (!*wip) goto vtop;
 if (x=='R'||x=='r') {laddr=xbload(wip);goto vtop;}
 printf ("Enter address (or 'AUTO' to ask DOS 3.3): ");
 fgets(addrw,128,stdin);
 addrw[strlen(addrw)-1]=0;
 if (!stricmp(addrw,"AUTO"))
 {
  absave(wip);
  goto vtop;
 }
 address=atoi(addrw);
 printf ("Enter length: ");
 fgets(lenw,128,stdin);
 lenw[strlen(lenw)-1]=0;
 length=atoi(lenw);
 printf ("Add PG2 header? (y/n) ");
 x=0; while (x!='Y'&&x!='y'&&x!='N'&&x!='n') x=getch();
 xbsave(wip,address,length,(x=='Y'||x=='y'));
 goto vtop;
top2:
 fdialog("Name of program (*.FP)",wip,".FP",toupper(x)!='L');
 if (!*wip) goto vtop;
 if (x=='L'||x=='l') loadbas(wip); else savebas(wip);
 goto vtop;
}

void uivid(void)
{
 int x;
 extern int flipmethod;

vtop:
 clrscr();
 printf ("\
[ESC] - Return to main menu\n\
\n\
[S] - Color spreading (%s) \n\
[A] - APL2EM emulation            %c\n\
[C] - Color screen                %c\n\
[G] - Green screen                %c\n\
[M] - Monochrome screen (white)   %c\n\
[R] - Amber screen                %c\n\
[F] - Page flipping method        %s\n\
\n\
Note: Lo-res graphics remain in color.\n\
\n\
",spread?"enabled":"disabled"
 ,mono==3?42:32
 ,mono==0?42:32
 ,mono==2?42:32
 ,mono==1?42:32
 ,mono==4?42:32
 ,flipmethod?"Draw from Apple memory":"Draw from PC memory   "
);
top:
 x=getch();
 if (x==27) return;
 if (x=='S'||x=='s') spread=!spread;
 if (x=='A'||x=='a') {fg=COL_TXT_WHT1;bg=COL_TXT_WHT0;mono=3;}
 if (x=='C'||x=='c') {fg=COL_TXT_WHT1;bg=COL_TXT_WHT0;mono=0;}
 if (x=='G'||x=='g') {fg=COL_TXT_GRN1;bg=COL_TXT_GRN0;mono=2;}
 if (x=='M'||x=='m') {fg=COL_TXT_WHT1;bg=COL_TXT_WHT0;mono=1;}
 if (x=='R'||x=='r') {fg=COL_TXT_AMB1;bg=COL_TXT_AMB0;mono=4;}
 if (x=='F'||x=='f') flipmethod=!flipmethod;
 goto vtop;
}

void uisnd(void)
{
 int x;
 extern int sounddelay;

vtop:
 clrscr();
 printf ("\
[ESC] - Return to main menu\n\
\n\
[S] - Speaker      (%s)\n\
[Q] - Speaker Type (%s)  \n\
",smode?"enabled":"disabled",
 sounddelay==0?"Dapple Standard (fast, raspy)":
 sounddelay==1?"Dapple TC2 (slower but cleaner)":
 sounddelay==2?"Andrew Gregory's speaker code":
               "??? - Invalid code specified!"
);
top:
 x=getch();
 if (x==27) return;
 if (x=='S'||x=='s') smode=!smode;
 if (x=='Q'||x=='q') {sounddelay++; if (sounddelay>2) sounddelay=0;}
 goto vtop;
}

void charset(void)
{
 int x;

vtop:
 clrscr();
 printf("\
[ESC] - Return to main menu\n\
\n\
[A] - USA        %c\n\
[F] - France     %c\n\
[G] - Germany    %c\n\
[E] - UK         %c\n\
[D] - Denmark 1  %c\n\
[W] - Sweden     %c\n\
[I] - Italy      %c\n\
[S] - Spain      %c\n\
[J] - Japan      %c\n\
[N] - Norway     %c\n\
[K] - Denmark 2  %c\n\
\n\
",charmode==USA?42:32,
  charmode==France?42:32,
  charmode==Germany?42:32,
  charmode==UK?42:32,
  charmode==Denmark1?42:32,
  charmode==Sweden?42:32,
  charmode==Italy?42:32,
  charmode==Spain?42:32,
  charmode==Japan?42:32,
  charmode==Norway?42:32,
  charmode==Denmark2?42:32
);
top:
 x=getch();
 if (x==27) return;
 if (x=='A'||x=='a') charmode=USA;
 if (x=='F'||x=='f') charmode=France;
 if (x=='G'||x=='g') charmode=Germany;
 if (x=='E'||x=='e') charmode=UK;
 if (x=='D'||x=='d') charmode=Denmark1;
 if (x=='W'||x=='w') charmode=Sweden;
 if (x=='I'||x=='i') charmode=Italy;
 if (x=='S'||x=='s') charmode=Spain;
 if (x=='J'||x=='j') charmode=Japan;
 if (x=='N'||x=='n') charmode=Norway;
 if (x=='K'||x=='k') charmode=Denmark2;
 goto vtop;
}

void jctrl(void)
{
 int x;
 extern int joyenabled;

vtop:
 clrscr();
 printf ("\
[ESC] - Return to main menu\n\
\n\
[J] - Joystick controls (%s)\n\
[C] - Calibrate joystick\n\
",joyenabled?"enabled":"disabled");
top:
 x=getch();
 if (x==27) return;
 if (x=='C'||x=='c') {calibrate(); goto vtop;}
 if (x=='J'||x=='j') {joyenabled=!joyenabled; goto vtop;}
 goto top;
}

void secret(M6502 *proc)
{
 int x;
 unsigned int brk;

vtop:
 clrscr();
 printf ("\
[ESC] - Return to main menu\n\
\n\
[1] - Crash into the monitor\n\
");
top:
 x=getch();
 if (x==27) return;
 if (x!=49) goto vtop;
 for (brk=0; (brk<49152)&&(RAM[brk]!=0); brk++);
 proc->PC.W=brk;
 clrscr();
 printf ("\
You have just crashed the emulated\n\
Apple into the monitor.  It will take\n\
effect as soon as you return to the\n\
emulation.\n\
\n\
Press any key to go to the main menu. ");
 if (!getch()) getch();
}

int uimain(M6502 *proc)
{
 int x;
 char wip[128];

vtop:
 gmode(T80);
 clrscr();
 _setcursortype(_NORMALCURSOR);
#ifdef BANK128
 printf ("Warning:  This is unstable code.  Use at your own risk.  Diana pt%s\n\n",DianaVersion);
#endif
 printf ("\
             Dapple v%s\n\
        (C) 2002 Steve Nickolas\n\
     (C) 1996-1997 Marcel de Kogel\n\
     (C) 1996-1997 Marat Fayzullin\n\
          and Alex Krasivsky\n\
",DappleVersion);
 printf ("\
\n\
[ESC] - Resume emulation\n\
\n\
[B] - BIOS select\n\
[C] - Character set\n\
[D] - Disk select\n\
[F] - File import/export\n\
[J] - Joystick options\n\
[L] - Load image\n\
[N] - Sound options\n\
[P] - Port options\n\
[S] - Save image\n\
[V] - Video options\n\
");
#ifdef SHELL
 printf("[!] - Shell to DOS\n\n");
#endif
 printf("[Q] - Quit to DOS\n\n");

top:
 x=getch();
 if (x==27)
 {
  _setcursortype(_NOCURSOR);
  clrscr();
  opengraph();
  redrawtext(1+(0!=(gm&PG2)));
  return 0;
 }
#ifdef SHELL
 if (x==33)
 {
#ifndef SAFE
  extern char oldshift;
  extern char *shiftstate;

  *shiftstate=oldshift; /* DJGPP won't let me get away with this! */
#endif
  clrscr();
  printf("Shell to DOS - Type 'EXIT' to return to Dapple.\n");
  system("");
#ifndef SAFE
  *shiftstate=96; /* DJGPP won't let me get away with this! */
#endif
  goto vtop;
 }
#endif
 if (x=='B'||x=='b')
 {
  uibio(proc);
  goto vtop;
 }
 if (x=='C'||x=='c')
 {
  charset();
  goto vtop;
 }
 if (x=='D'||x=='d')
 {
  uidisk();
  goto vtop;
 }
 if (x=='F'||x=='f')
 {
  if (!fman()) goto vtop;
  _setcursortype(_NOCURSOR);
  clrscr();
  opengraph();
  redrawtext(1+(0!=(gm&PG2)));
  return 0;
 }
 if (x=='J'||x=='j')
 {
  jctrl();
  goto vtop;
 }
 if (x=='L'||x=='l')
 {
  fdialog("Name of image (*.PGX)",wip,".PGX",0);
  if (!*wip) goto vtop;
  imrs(wip,proc);
  goto vtop;
 }
 if (x=='N'||x=='n')
 {
  uisnd();
  goto vtop;
 }
 if (x=='P'||x=='p')
 {
  uiport();
  goto vtop;
 }
 if (x=='S'||x=='s')
 {
  fdialog("Name of image (*.PGX)",wip,".PGX",1);
  if (!*wip) goto vtop;
  immk(wip,proc);
  goto vtop;
 }
 if (x=='V'||x=='v')
 {
  uivid();
  goto vtop;
 }
 if (x=='W'||x=='w')
 {
  extern int hold;
  int tmphold;

  printf ("Enter delay in hex (ENTER keeps current $%04X): ",hold);
  fgets(wip,128,stdin);
  if (*wip=='\n') goto vtop;
  if (!sscanf(wip,"%04x",&tmphold)) goto vtop;
  hold=tmphold&0x7FFF;
  goto vtop;
 }
 if (x=='Q'||x=='q')
 {
  printf ("Quit to DOS: Are you sure? (y/n) ");
  x=getch();
  if (x=='Y'||x=='y')
  {
   cpuinuse=emu6502;
   return -1;
  }
  goto vtop;
 }
 if (x=='x')
 {
  secret(proc);
  goto vtop;
 }
 goto top;
}
