/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  Z80EMU: functions related to emulation of Soft80
 * Revision:   (0.67a) 2002.0907
 *             0.33 "LOST KEY WEEKEND"
 * Note: current version is a DUMMY FILE
 */

#include "z80.h"

int Z80_IRQ;

/* from m6502.h */

#define INT65_NONE  0            /* No interrupt required      */
#define INT65_IRQ   1            /* Standard IRQ interrupt     */
#define INT65_NMI   2            /* Non-maskable interrupt     */
#define INT65_QUIT  3            /* Exit the emulation         */

typedef struct
{
  byte A,P,X,Y,S;     /* CPU registers and program counter   */
  pair PC;

  int IPeriod,ICount; /* Set IPeriod to number of CPU cycles */
                      /* between calls to Loop6502()         */
  byte IRequest;      /* Set to the INT_IRQ when pending IRQ */
  byte AfterCLI;      /* Private, don't touch                */
  int IBackup;        /* Private, don't touch                */
  void *User;         /* Arbitrary user data (ID,RAM*,etc.)  */
  byte TrapBadOps;    /* Set to 1 to warn of illegal opcodes */
  word Trap;          /* Set Trap to address to trace from   */
  byte Trace;         /* Set Trace=1 to start tracing        */
} M6502;
byte Loop6502(register M6502 *R);
void Wr6502(register word Addr,register byte Value);
byte Rd6502(register word Addr);

#pragma argsused
void Z80_Out (byte Port,byte Value)
{
}

#pragma argsused
byte Z80_In (byte Port)
{
 return 0;
}

/* $FEED opcode handling */
#pragma argsused
void Z80_Patch(Z80_Regs *R)
{
}

void Z80_Reti (void)
{
}

void Z80_Retn (void)
{
}

int Z80_Interrupt(void)
{
 return 0;
}