/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *   Source code for personal use only
 *   If you alter this code, send me a copy: steve@dosius.zzn.com
 *
 * Component:  PSET:  pixel manipulation functions (replaces BGI)
 * Revision:   (0.67a) 2002.0907
 *             0.33 "LOST KEY WEEKEND"
 */

#include <dos.h>

static union REGS regs;
#define VIDEO int86(16,&regs,&regs);

extern int fg, bg;
extern char AppleFont[2048];

void pset (unsigned int x, unsigned int y, unsigned int c)
{
 static char far *screen=MK_FP(0xA000,0x0000);

 screen[(y*320)+x]=c;
}

unsigned int point (unsigned int x, unsigned int y)
{
 static char far *screen=MK_FP(0xA000,0x0000);

 return screen[(y*320)+x];
}

void gmode (unsigned int mode)
{
 regs.x.ax=mode%256;
 VIDEO;
}

void gputc (char c, unsigned int cx, unsigned int cy)
{
 int Y,x,y,FG,BG;
 char ch;

 if (bg&8) {FG=254; BG=255;} else {FG=fg; BG=bg;}
 if (FG==7) FG=15; else if (BG==7) BG=15;

 x=(cx-1)*7+20;
 y=(cy-1)*8;

 for (Y=y; Y<y+8; Y++)
 {
  ch=AppleFont[(c*8+(Y-y))];
  pset (x,Y,(ch&128)?FG:BG);
  pset (x+1,Y,(ch&64)?FG:BG);
  pset (x+2,Y,(ch&32)?FG:BG);
  pset (x+3,Y,(ch&16)?FG:BG);
  pset (x+4,Y,(ch&8)?FG:BG);
  pset (x+5,Y,(ch&4)?FG:BG);
  pset (x+6,Y,(ch&2)?FG:BG);
 }
}

void xputc (char c, unsigned int cx, unsigned int cy, unsigned int attr)
{
 int Y,x,y,FG,BG;
 char ch;
 FG=attr%256;
 BG=attr>>8;

 x=(cx-1)*7+20;
 y=(cy-1)*8;

 for (Y=y; Y<y+8; Y++)
 {
  ch=AppleFont[(c*8+(Y-y))];
  pset (x,Y,(ch&128)?FG:BG);
  pset (x+1,Y,(ch&64)?FG:BG);
  pset (x+2,Y,(ch&32)?FG:BG);
  pset (x+3,Y,(ch&16)?FG:BG);
  pset (x+4,Y,(ch&8)?FG:BG);
  pset (x+5,Y,(ch&4)?FG:BG);
  pset (x+6,Y,(ch&2)?FG:BG);
 }
}

void xputcs (unsigned char c, unsigned int cx, unsigned int attr)
{
 int Y,x,y,FG,BG;
 char ch;
 FG=attr%256;
 BG=attr>>8;

 x=cx*7;
 y=192;

 for (Y=y; Y<y+8; Y++)
 {
  ch=AppleFont[(c*8+(Y-y))];
  pset (x,Y,(ch&128)?FG:BG);
  pset (x+1,Y,(ch&64)?FG:BG);
  pset (x+2,Y,(ch&32)?FG:BG);
  pset (x+3,Y,(ch&16)?FG:BG);
  pset (x+4,Y,(ch&8)?FG:BG);
  pset (x+5,Y,(ch&4)?FG:BG);
  pset (x+6,Y,(ch&2)?FG:BG);
 }
}

