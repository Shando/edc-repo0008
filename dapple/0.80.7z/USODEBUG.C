/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *   Source code for personal use only
 *   If you alter this code, send me a copy: steve@dosius.zzn.com
 *
 * Component:  USODEBUG: The Usotsuki Debugger code
 * Revision:   (0.67c) 2002.0907
 *             0.33 "LOST KEY WEEKEND"
 */

#include <stdio.h>
#include <string.h>
#include "dapple.h"
#include "m6502.h"
extern M6502 *_proc;

/* Information on the opcodes is defined in two components:
   the name of the opcode in printf() format, and a method used to determine
   what variables should be fed into the printf() and how far the IP should
   be pushed ahead.
   Opcodes are given in the format used by the Apple ][ disassembler. */

typedef enum {Nothing, Byte, Word, Relative} NumberSize;

typedef struct
{
 char Description[20];
 NumberSize Method;
}
Opcode;

Opcode Ops[256]=
{
 "BRK",Nothing,                 /* $00 */
 "ORA ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ORA $%02X",Byte,
 "ASL $%02X",Byte,
 "???",Nothing,
 "PHP",Nothing,                 /* $08 */
 "ORA #$%02X",Byte,
 "ASL",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ORA $%04X",Word,
 "ASL $%04X",Word,
 "???",Nothing,
 "BPL $%04X",Relative,          /* $10 */
 "ORA ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ORA $%02X,X",Byte,
 "ASL $%02X,X",Byte,
 "???",Nothing,
 "CLC",Nothing,                 /* $18 */
 "ORA $%04X,Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ORA $%04X,X",Word,
 "ASL $%04X,X",Word,
 "???",Nothing,
 "JSR $%04X",Word,              /* $20 */
 "AND ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "BIT $%02X",Byte,
 "AND $%02X",Byte,
 "ROL $%02X",Byte,
 "???",Nothing,
 "PLP",Nothing,                 /* $28 */
 "AND #$%02X",Byte,
 "ROL",Byte,
 "???",Nothing,
 "BIT $%04X",Word,
 "AND $%04X",Word,
 "ROL $%04X",Word,
 "???",Nothing,
 "BMI $%04X",Relative,          /* $30 */
 "AND ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "AND $%02X,X",Byte,
 "ROL $%02X,X",Byte,
 "???",Nothing,
 "SEC",Nothing,                 /* $38 */
 "AND $%04X,Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "AND $%04X,X",Word,
 "ROL $%04X,X",Word,
 "???",Nothing,
 "RTI",Nothing,                 /* $40 */
 "EOR ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "EOR $%02X",Byte,
 "LSR $%02X",Byte,
 "???",Nothing,
 "PHA",Nothing,                 /* $48 */
 "EOR #$%02X",Byte,
 "LSR",Nothing,
 "???",Nothing,
 "JMP $%04X",Word,
 "EOR $%04X",Word,
 "LSR $%02X",Word,
 "???",Nothing,
 "BVC $%04X",Relative,          /* $50 */
 "EOR ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "EOR $%02X,X",Byte,
 "LSR $%02X,X",Byte,
 "???",Nothing,
 "CLI",Nothing,                 /* $58 */
 "EOR $%04X,Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "EOR $%04X,X",Word,
 "LSR $%04X,X",Word,
 "???",Nothing,
 "RTS",Nothing,                 /* $60 */
 "ADC ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ADC $%02X",Byte,
 "ROR $%02X",Byte,
 "???",Nothing,
 "PLA",Nothing,                 /* $68 */
 "ADC #$%02X",Byte,
 "ROR",Nothing,
 "???",Nothing,
 "JMP ($%04X)",Word,
 "ADC $%04X",Word,
 "ROR $%04X",Word,
 "???",Nothing,
 "BVS $%04X",Relative,          /* $70 */
 "ADC ($%02X),Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ADC $%02X,X",Byte,
 "ROR $%02X,X",Byte,
 "???",Nothing,
 "SEI",Nothing,                 /* $78 */
 "ADC $%04X,Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "ADC $%04X,X",Word,
 "ROR $%04X,X",Word,
 "???",Nothing,
 "???",Nothing,                 /* $80 */
 "STA ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "STY $%02X",Byte,
 "STA $%02X",Byte,
 "STX $%02X",Byte,
 "???",Nothing,
 "DEY",Nothing,                 /* $88 */
 "???",Nothing,
 "TXA",Nothing,
 "???",Nothing,
 "STY $%04X",Word,
 "STA $%04X",Word,
 "STX $%04X",Word,
 "???",Nothing,
 "BCC $%04X",Relative,          /* $90 */
 "STA ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "STY $%02X,X",Byte,
 "STA $%02X,X",Byte,
 "STX $%02X,Y",Byte,
 "???",Nothing,
 "TYA",Nothing,                 /* $98 */
 "STA $%04X,Y",Word,
 "TXS",Nothing,
 "???",Nothing,
 "???",Nothing,
 "STA $%04X,X",Word,
 "???",Nothing,
 "???",Nothing,
 "LDY #$%02X",Byte,             /* $A0 */
 "LDA ($%02X,X)",Byte,
 "LDX #$%02X",Byte,
 "???",Nothing,
 "LDY $%02X",Byte,
 "LDA $%02X",Byte,
 "LDX $%02X",Byte,
 "???",Nothing,
 "TAY",Nothing,                 /* $A8 */
 "LDA #$%02X",Byte,
 "TAX",Nothing,
 "???",Nothing,
 "LDY $%04X",Word,
 "LDA $%04X",Word,
 "LDX $%04X",Word,
 "???",Nothing,
 "BCS $%04X",Relative,          /* $B0 */
 "LDA ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "LDY $%02X,X",Byte,
 "LDA $%02X,X",Byte,
 "LDX $%02X,Y",Byte,
 "???",Nothing,
 "CLV",Nothing,                 /* $B8 */
 "LDA $%04X,Y",Word,
 "TSX",Nothing,
 "???",Nothing,
 "LDY $%04X,X",Word,
 "LDA $%04X,X",Word,
 "LDX $%04X,Y",Word,
 "???",Nothing,
 "CPY #$%02X",Byte,             /* $C0 */
 "CMP ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "CPY $%02X",Byte,
 "CMP $%02X",Byte,
 "DEC $%02X",Byte,
 "???",Nothing,
 "INY",Nothing,                 /* $C8 */
 "CMP #$%02X",Byte,
 "DEX",Nothing,
 "???",Nothing,
 "CPY $%04X",Word,
 "CMP $%04X",Word,
 "DEC $%04X",Word,
 "???",Nothing,
 "BNE $%04X",Relative,          /* $D0 */
 "CMP ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "CMP $%02X,X",Byte,
 "DEC $%02X,X",Byte,
 "???",Nothing,
 "CLD",Nothing,                 /* $D8 */
 "CMP $%04X,Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "CMP $%04X,X",Word,
 "DEC $%04X,X",Word,
 "???",Nothing,
 "CPX #$%02X",Byte,             /* $E0 */
 "SBC ($%02X,X)",Byte,
 "???",Nothing,
 "???",Nothing,
 "CPX $%02X",Byte,
 "SBC $%02X",Byte,
 "INC $%02X",Byte,
 "???",Nothing,
 "INX",Nothing,                 /* $E8 */
 "SBC #$%02X",Byte,
 "NOP",Nothing,
 "???",Nothing,
 "CPX $%04X",Word,
 "SBC $%04X",Word,
 "INC $%04X",Word,
 "???",Nothing,
 "BEQ $%04X",Relative,          /* $F0 */
 "SBC ($%02X),Y",Byte,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "SBC $%02X,X",Byte,
 "INC $%02X,X",Byte,
 "???",Nothing,
 "SED",Nothing,                 /* $F8 */
 "SBC $%04X,Y",Word,
 "???",Nothing,
 "???",Nothing,
 "???",Nothing,
 "SBC $%04X,X",Word,
 "INC $%04X,X",Word,
 "???",Nothing
};

/* dasm()
   Disassemble one opcode:
   given a buffer in which to copy the disassembly and the current IP,
   returns the new IP. */

int dasm(char *output, unsigned short int address)
{
 /* Addresses used by branch ops are relative to address+2, signed char */
 unsigned int num;
 signed char Rel;
 unsigned int p1,p2;
 unsigned int op;
 char Desc[128];

 /* We must keep the compiler from promoting signed values, so often we
    explicitly cast to unsigned char. */
 op=(unsigned char)Rd6502(address);

 if (Ops[op].Method==Nothing) /* Just the opcode */
 {
  sprintf (output,"%04X:  %02X            %s",address,op,Ops[op].Description);
  return address+1;
 }
 if (Ops[op].Method==Byte) /* Two byte opcode */
 {
  sprintf (Desc,Ops[op].Description,(unsigned char)(p1=Rd6502(address+1)));
  sprintf (output,"%04X:  %02X%02X          %s",address,op,(unsigned char)p1,Desc);
  return address+2;
 }
 if (Ops[op].Method==Word) /* Three byte opcode */
 {
  p1=(unsigned char)Rd6502(address+1);
  p2=(unsigned char)Rd6502(address+2);
  num=p1+(p2<<8); /* Construct low-endian number */
  sprintf (Desc,Ops[op].Description,num);
  sprintf (output,"%04X:  %02X%02X%02X        %s",address,op,p1,p2,Desc);
  return address+3;
 }
 if (Ops[op].Method==Relative) /* Two byte opcode */
 {
  /* This is a little tricky... The relative address is a signed char. */
  Rel=Rd6502(address+1);
  num=(address+2);
  num+=Rel; /* this CAN subtract; remember a+(-b) is the same as a-b */
  sprintf (Desc,Ops[op].Description,(unsigned int)num);
  sprintf (output,"%04X:  %02X%02X          %s",address,op,(unsigned char)Rel,Desc);
  return address+2;
 }
 /* error : should never reach this point but placate compilers */
 return -1;
}

void dispdasm()
{
 int travel;
 extern int debugger;
 char disassembly[40];

 debugger=1;
 for (travel=0; travel<38; travel++) disassembly[travel]=32;
 disassembly[38]=0;
 dasm(disassembly,(_proc->PC).W);
 disassembly[strlen(disassembly)]=32;
 for (travel=0;travel<38;travel++) xputcs(disassembly[travel],travel,COL_DASM);
 debugger=0;
}

void undispdasm()
{
 int travel;
 for (travel=0;travel<38;travel++) xputcs(32,travel,0);
}
