/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997 Marat Fayzullin, Alex Krasivsky (M6502)
 * Copyright 1996, 1997 Marcel de Kogel (Z80Em)
 *
 * Component:  PAGEFLIP: routines for off-screen pixmap and quick flipping
 * Revision:   (Diana 0.90) 2002.1102
 *             0.33 "LOST KEY WEEKEND"
 */

#include <dos.h>

static unsigned char far ascreen[64000];

void apset (unsigned int x, unsigned int y, unsigned int c)
{
 ascreen[(y*320)+x]=c;
}

void pageflip (void)
{
 int tmp;
 static unsigned char far *screen=MK_FP(0xA000,0x0000);
 unsigned int travel;

 for (travel=0; travel<64000; travel++)
 {
  tmp=screen[travel];
  screen[travel]=ascreen[travel];
  ascreen[travel]=tmp;
 }
}

void nullpixmap(void)
{
 unsigned int travel;

 for (travel=0; travel<64000; travel++) ascreen[travel]=0;
}
