/*
 * DAPPLE, Apple ][, ][+, //e Emulator
 * Copyright 2002, 2003 Steve Nickolas, portions by Holger Picker
 *
 * Component:  ALT:  Handle the <Alt> keys appropriately
 * Revision:   (1.24) 2003.0105
 * Some code was taken from Andrew Gregory's emulator
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <dos.h>

void interrupt ( far *OldInt15Handler )( void );

extern unsigned int LeftAltDown, RightAltDown;

static int ExtendedScanCode = 0;

#pragma argsused
void interrupt Int15Handler( unsigned bp, unsigned di, unsigned si,
                             unsigned ds, unsigned es, unsigned dx,
                             unsigned cx, unsigned bx, unsigned ax,
                             unsigned ip, unsigned cs, unsigned flags)
{
    static unsigned ah, al;

    ah = ax >> 8;
    al = ax & 0xff;

    if ( ah == 0x85 )
    {
        /* SysReq key pressed */
    }
    if ( ah == 0x4f )
    {
        /* now handle keypress */
        ah = 0x86;
        flags |= 1; /* set carry */
        if ( al == 0x38 )
        {
            /* An Alt key has been pressed */
            if ( ExtendedScanCode )
            {
                RightAltDown = 1;
            }
            else
            {
                LeftAltDown = 1;
            }
            /* and ignore it */
            flags ^= 1;
        }
        if ( al == 0xb8 )
        {
          /* An Alt key has been released */
          if ( ExtendedScanCode )
          {
              RightAltDown = 0;
          }
          else
          {
              LeftAltDown = 0;
          }
          /* and ignore it */
          flags ^= 1;
        }
        ExtendedScanCode = 0;
        if ( al == 0xe0 )
        {
            ExtendedScanCode = 1;
        }
        ax = ( ah << 8 ) | al;
        return;
    }

    _BX = bx;
    _CX = ax; /* Save ax */
     ax = FP_SEG( (void far *)OldInt15Handler ); /* Put address of old vector */
     bx = FP_OFF( (void far *)OldInt15Handler ); /* on the stack */
    _AX = _CX; /* Restore ax */
    /* Restore other registers */
    /* this has been DEBUG assembled:
    asm pop bp;
    asm pop di;
    asm pop si;
    asm pop ds;
    asm pop es;
    asm pop dx;
    asm pop cx; */
    __emit__ (0x5D, 0x5F, 0x5E, 0x1F, 0x07, 0x5A, 0x59);
    __emit__( 0xcb ); /* RETF - Indirect far jump to old vector */
}

void interrupt ( far * GetVect( int intnum ) )()
{
    int es, bx;
    void interrupt ( far * isr )();

    int Es; Es=_ES;
    _AH = 0x35;
    _AL = intnum;
    geninterrupt(0x21);
    bx = _BX;
    es = _ES;
    isr = MK_FP( es, bx );
    _ES=Es;
    return isr;
}

void SetVect( int intnum, void interrupt ( far * isr )() )
{
  int ds; ds=_DS;
  _AH = 0x25;
  _AL = intnum;
  _DS = FP_SEG( isr );
  _DX = FP_OFF( isr );
  geninterrupt(0x21);
  _DS=ds;
}

void inst15(void)
{
 OldInt15Handler = GetVect( 0x15 );
 SetVect( 0x15, Int15Handler );
}

void uninst15(void)
{
 SetVect(0x15,OldInt15Handler);
}
