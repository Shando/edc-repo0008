#include <stdio.h>

void main (int argc, char **argv)
{
 unsigned short int address;
 unsigned short int length;
 int inp, travel;
 FILE *file;

 if (argc==1)
 {
  fprintf(stderr,"usage: headpg2 filename.ext\n");
  return;
 }

 for (travel=1; travel<argc; travel++)
 {
  file=fopen(argv[travel],"rb");
  if (!file) {perror (argv[travel]); return;}
  inp=fgetc(file);
  address=inp;
  inp=fgetc(file);
  address+=(inp<<8);
  inp=fgetc(file);
  length=inp;
  inp=fgetc(file);
  length+=(inp<<8);
  printf ("%s: A %u ($%04X), L %u ($%04X)\n",argv[travel],
                                             address,address,length,length);
  fclose(file);
 }
}
