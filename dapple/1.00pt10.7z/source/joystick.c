/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997, 2002 Marat Fayzullin, Alex Krasivsky (M6502)
 *
 * Component:  JOYSTICK:  emulate Apple joystick through PC game port
 * Revision:   (Wing 1.00pt9) 2002.1219
 *             0.33 "LOST KEY WEEKEND"
 * Some code was taken from Andrew Gregory's emulator
 */

#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include "m6502.h"
#include "dapple.h"

unsigned int GameMinX = 26, GameMinY = 26;
unsigned int GameMaxX = 27, GameMaxY = 27;
unsigned long ClockX, ClockY;                /* Timeouts for 556 timer */
unsigned int LeftAltDown = 0, RightAltDown = 0;

int joya(void)
{
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0;
 int86(0x15,&regs,&regs); /* al */
 {
  extern char *shiftstate;

  if ((*shiftstate & 8) == 8) return 255; /* Alt */
  return ((regs.h.al&0x10)==0)?255:0;
 }
}

int joyb(void)
{
 union REGS regs;

 regs.h.ah=0x84;
 regs.x.dx=0;
 int86(0x15,&regs,&regs); /* al */
 {
  extern char *shiftstate;

  if ((*shiftstate & 12) == 12) return 255; /* Ctrl-Alt, or AltGr */
  return ((regs.h.al&0x20)==0)?255:0;
 }
}

/////////////////////////////////////////////////////////////////////////////

extern unsigned long ClockTick;

#pragma argsused
byte ResetGameTimer( word Address )
{
    unsigned int ReadX, ReadY;
    union REGS regs;

    /* Get the current position of the game controller */
    regs.h.ah=0x84;
    regs.x.dx=0x0001;
    int86(0x15,&regs,&regs);
    if (regs.x.cflag) goto nojoystick;
    ReadX=regs.x.ax; ReadY=regs.x.bx;

    /* Update maximum ranges */
    if ( ReadX < GameMinX )
    {
        GameMinX = ReadX;
    }
    if ( ReadY < GameMinY )
    {
        GameMinY = ReadY;
    }
    if ( ReadX > GameMaxX )
    {
        GameMaxX = ReadX;
    }
    if ( ReadY > GameMaxY )
    {
        GameMaxY = ReadY;
    }
    /* Convert PC readings to Apple */
    ReadX = ( ReadX - GameMinX ) * 256 / ( GameMaxX - GameMinX );
    ReadY = ( ReadY - GameMinY ) * 256 / ( GameMaxY - GameMinY );
    /* Calculate CPU clock tick at timeout */
    ClockX = ClockTick +7 + 11 * ReadX;
    ClockY = ClockTick +7 + 11 * ReadY;

nojoystick:
    return 0;
}

byte ReadGameTimer( word Address )
{
  if ( Address == 0x64 )
  {
      return ( ClockTick > ClockX ) ? 0 : 255;  /* Game 0 has timed out */
  }
  if ( Address == 0x65 )
  {
      return ( ClockTick > ClockY ) ? 0 : 255;  /* Game 1 has timed out */
  }
  return 0;
}

