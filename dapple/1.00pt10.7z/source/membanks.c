/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997, 2002 Marat Fayzullin, Alex Krasivsky (M6502)
 *
 * Component:  MEMBANKS:  Language card bank storage
 * Revision:   (Wing 1.00pt9) 2002.1219
 *             0.33 "LOST KEY WEEKEND"
 */

unsigned char ROM[16384];
unsigned char RAMEXT[16384];
