/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997, 2002 Marat Fayzullin, Alex Krasivsky (M6502)
 *
 * Component:  DAPPLE:  main functions
 * Revision:   (Wing 1.00pt10) 2002.1220
 *             0.33 "LOST KEY WEEKEND"
 *
 * Graphics chroma data (0x00-0x17) provided to Usenet by Robert Munafo
 * and given to the author by Holger Picker.  See dapple.h for alternate
 * names for the colors.
 *
 * Foreign character translation derived from experimentation and Epson
 * RX-80 documentation.
 *
 * Some information was provided to Usenet by Jon Bettencourt and given to
 * the author by Holger Picker.
 *
 * Some information regarding 128K memory banking was provided by David
 * Empson and Holger Picker.  The author greatly appreciates your help.
 * Thanks a million!
 */

#include "m6502.h"
#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include "dapple.h"

#ifdef EMUZ80
int Z80_Execute (void);
#endif

int sounddelay=2;
int dqhdv=1;

/* Memory Handling */
static unsigned char dappleram[49152];
       unsigned char *RAM=dappleram;

unsigned char DISKROM[256], PICROM[256];
extern unsigned char HDDROM[256]; /* no room here! */

unsigned char memauxread;               /* read motherboard ram or aux ram                      */
unsigned char memauxwrite;              /* write motherboard ram or aux ram                     */
unsigned char memstore80;
unsigned char memintcxrom;              /* read from slot rom $c100-$cfff or internal rom       */
unsigned char memslotc3;                /* read from slot rom $c300-$c3ff or internal rom       */
unsigned char memlcaux;                 /* read $0-$1ff + $d000-$ffff from main or aux memory   */
unsigned char memlcramr;                /* read LC RAM or ROM?                                  */
unsigned char memlcramw;                /* write LC RAM or ROM?                                 */
unsigned char memlcbank2;               /* read from LC bank 1 or LC bank 2                     */
unsigned char memann3;                  /* annunciator #3                                       */
unsigned char membankon;                /* Is there a LC card installed?                        */
void memoryreset();
void memoryclear();
extern void reload (char *bios, M6502 *proc);

Charset charmode=USA;

int ROM16K=0;

/* disk.c */
void InitDisk( int slot );
void ShutdownDisk( void );
void DiskReset( void );
byte ReadDiskIO( word Address );
void WriteDiskIO( word Address, byte Data );

void WriteParallel( word Address, byte Data );

/* video.c: graphic display */
extern unsigned int virtcachemode;
extern unsigned char virt80col;
extern unsigned char virtaltchar;
extern unsigned char virtiou;
extern unsigned char virtdhres;
extern unsigned char virtvideobyte;
extern unsigned char virtscreen[64000];
#define virtplot(x,y,c) virtscreen[(y*320)+x]=c
extern void virtreset();
extern void virtsetmode();
extern void virtsethresmode(unsigned char mode);	/* 0 = standard, 1 = RGB */
extern unsigned char virtgethresmode();
extern void virtsetmonochrome(unsigned char mode);	/* 0 = colour, 1 = white, 2 = green, 3 = amber */
extern unsigned char virtgetmonochrome();
extern void virtpalettesetd(register unsigned char index, register unsigned char r,
                            register unsigned char b,     register unsigned char g);
extern void virtputpalette();
extern void virtline(unsigned int rastline);
extern void virtscreencopy();
extern void virtwrite0400(register unsigned int addr);
extern void virtwrite0800(register unsigned int addr);
extern void virtwrite2000(register unsigned int addr);
extern void virtwrite2000aux(register unsigned int addr);
extern void virtwrite4000(register unsigned int addr);
extern void virtwrite4000aux(register unsigned int addr);
static unsigned int rasterline = 0;


word XRun6502(M6502 *R);

#define _NOCURSOR      0
#define _SOLIDCURSOR   1
#define _NORMALCURSOR  2

int joyenabled=1;
int hold=0;

extern int hdd;
char rompath[128]={"apple.rom"};
//static char cmap[16]={0,4,1,5,3,7,2,9,6,13,8,12,10,14,11,15};
#ifdef SAFE
char *shiftstate=1047;
#else
char *shiftstate=MK_FP(0,1047);
#endif
char oldshift;
int dqshift=1;

static int k=0,d=0,hd=0,osp;
int gm, smode=1;
int fontloaded=0;
int drawtext=1;
int debugstep=0, debugtrace=0;
int dlight1=0, dlight2=0;
enum {emu6502, emuZ80} cpuinuse=emu6502;

#include "font.h"

static M6502 proc;

M6502 *_proc=&proc;

enum DiskTypes
{
    UnknownType = 0,
    RawType     = 1,
    DOSType     = 2
};

extern struct DriveState
{
    /* variables for each disk */
    char DiskFN[ 80 ]; /* MS-DOS filename of disk image */
    int DiskFH;        /* MS-DOS file handle of disk image */
    long DiskSize;     /* length of disk image file in bytes */
    enum DiskTypes DiskType; /* Type of disk image */
    int WritePro;      /* 0:write-enabled, !0:write-protected */
    int TrkBufChanged; /* Track buffer has changed */
    int TrkBufOld;     /* Data in track buffer needs updating before I/O */
    int ShouldRecal;
    /* variables used during emulation */
    int Track;    /* 0-70 */
    int Phase;    /* 0- 3 */
    int ReadWP;   /* 0/1  */
    int Active;   /* 0/1  */
    int Writing;  /* 0/1  */
} DrvSt[ 2 ];


int critical_error_handler (int errval, int ax, int bp, int si)
{
 char far *deviceDriver;
 char AllowedActions;
 int CanIgnore=0, CanFail=0;
 char ah, al;
 deviceDriver=MK_FP(bp, si+10);
 ah=ax/256;
/* al=ax%256; */
 /* Generate ARIF message from AH flags */
 AllowedActions=ah;
 if ((ah&0x80)&&(((struct devhdr far *)(deviceDriver-10))->dh_attr&0x8000))
 {
  if (deviceDriver[0]=='P'&&
      deviceDriver[1]=='R'&&
      deviceDriver[2]=='N')
  {
   static char errnam[3];
   int travel;

   switch (errval)
   {
    case 1:  strcpy(errnam,"UN"); break;
    case 3:  strcpy(errnam,"RQ"); break;
    case 5:  strcpy(errnam,"PR"); break;
    case 9:  strcpy(errnam,"OP"); break;
    case 10: strcpy(errnam,"WF"); break;
    default: strcpy(errnam,"??"); break;
   }
   for (travel=0;travel<3;travel++) xputcs(32,travel,COL_LPTERR%256);
   for (travel=0;errnam[travel];travel++) xputcs(errnam[travel],travel,COL_LPTERR%256);
   if (kbhit())
   {
    for (travel=0;travel<3;travel++) xputcs(32,travel,COL_LPTERR%256);
    if (!getch()) getch();
    hardresume(3);
   }
   hardresume(1);
  }
 }
 if (AllowedActions & 32)  CanIgnore=-1;
 if (AllowedActions & 8)   CanFail=-1;
 if (CanIgnore) hardresume (0);
 if (CanFail)   hardresume (3);
 gmode(3);
 cprintf ("FATAL I/O ERROR, CANNOT RECOVER  #%04X  DEVICE @%04X:%04X",errval,si,bp);
 hardresume(2);
 return 2;
}

void linput (char *x)
{
 _setcursortype(_SOLIDCURSOR);
 fgets(x,128,stdin);
 _setcursortype(_NOCURSOR);
}

void opengraph(void)
{
 gmode(0x13);
 virtputpalette();
}

void click(void)
{
 if (!smode) return;
 if (sounddelay!=2)
 {
  sound(40);
  delay(sounddelay);
  nosound();
 }
 else
 {
  int al;
  // Toggle the speaker
  al=inportb(0x61);
  al ^= 0x02;
  al &= 0xfe;
  outportb(0x61,al);
 }
}


void PC2APL (void)
{
 int x;

 x=bioskey(1);
 if (/*kbhit()*/ x)
 {
  if (x==-1)
  {

   k=0;
   cpuinuse=emu6502;
   DiskReset();
   Reset6502(&proc);
#ifdef EMUZ80
   Z80_Reset();
#endif
   memoryreset();
   virtreset();
   x=bioskey(0);
   return;
  } /* Ctrl-Break */

  x=getch();
  if (!x) {x=getch(); x*=(-1);}
  if (x>=0&&x<=127) {k=x+128; return;}
  if (x>127 && x<256)
  {
   switch (x)
   {/* Foreign Keyboard Support */
    case 128:
     k='C'+128;
     return;
    case 129:
     k='u'+128;
     if (charmode==Germany) k='}'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='~'+128;
     return;
    case 130:
     k='e'+128;
     if (charmode==France) k='{'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='`'+128;
     if (charmode==Italy) k=']'+128;
     return;
    case 131: k='a'+128; return;
    case 132:
     k='a'+128;
     if (charmode==Germany||charmode==Sweden) k='{'+128;
     return;
    case 133:
     k='a'+128;
     if (charmode==France) k='@'+128;
     if (charmode==Italy) k='{'+128;
     return;
    case 134:
     k='a'+128;
     if (charmode==Denmark1||charmode==Sweden
       ||charmode==Norway||charmode==Denmark2) k='}'+128;
     return;
    case 135:
     k='c'+128;
     if (charmode==France) k='\\'+128;
     return;
    case 136:
     k='e'+128;
     return;
    case 137: k='e'+128; return;
    case 138:
     k='e'+128;
     if (charmode==France||charmode==Italy) k='}'+128;
     return;
    case 139: k='i'+128; return;
    case 140: k='i'+128; return;
    case 141:
     k='i'+128;
     if (charmode==Italy) k='~'+128;
     return;
    case 142:
     k='A'+128;
     if (charmode==Germany||charmode==Sweden) k='['+128;
     return;
    case 143:
     k='A'+128;
     if (charmode==Denmark1||charmode==Sweden
       ||charmode==Norway||charmode==Denmark2) k=']'+128;
     return;
    case 144:
     k='E'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='@'+128;
     return;
    case 145:
     k='e'+128;
     if (charmode==Denmark1||charmode==Norway||charmode==Denmark2) k='{'+128;
     return;
    case 146:
     k='E'+128;
     if (charmode==Denmark1||charmode==Norway||charmode==Denmark2) k='['+128;
     return;
    case 147: k='o'+128; return;
    case 148:
     k='o'+128;
     if (charmode==Germany||charmode==Sweden) k='|'+128;
     return;
    case 149:
     k='o'+128;
     if (charmode==Italy) k='|'+128;
     return;
    case 150: k='u'+128; return;
    case 151:
     k='u'+128;
     if (charmode==France) k='|'+128;
     if (charmode==Italy) k='`'+128;
     return;
    case 152: k='y'+128; return;
    case 153:
     k='O'+128;
     if (charmode==Germany||charmode==Sweden) k='\\'+128;
     return;
    case 154:
     k='U'+128;
     if (charmode==Germany) k=']'+128;
     if (charmode==Sweden||charmode==Norway||charmode==Denmark2) k='^'+128;
     return;
    case 155: k='c'+128; return;
    case 156:
     k='L'+128;
     if (charmode==UK) k='#'+128;
     return;
    case 157:
     k='Y'+128;
     if (charmode==Japan) k='\\'+128;
     return;
    case 158:
     k='P'+128;
     if (charmode==Spain) k='#'+128;
     return;
    case 159: k='f'+128; return;
    case 160:
     k='a'+128;
     return;
    case 161: k='i'+128; return;
    case 162: k='o'+128; return;
    case 163: k='u'+128; return;
    case 164:
     k='n'+128;
     if (charmode==Spain) k='|'+128;
     return;
    case 165:
     k='N'+128;
     if (charmode==Spain) k='\\'+128;
     return;
    case 225:
     if (charmode==Germany) {k='~'+128; return;}
   }
  }
  if (x==-72) {k=11+128; return;}
  if (x==-75) {k=8+128;  return;}
  if (x==-77) {k=21+128; return;}
  if (x==-80) {k=10+128; return;}
  if (x==-68) {if (uimain(&proc)) k=-1;  return;}
  if (x==-107) {k=-1; return;}
  if (x==-112 && (!ROM16K)) Wr6502(1012,0); /* not necessary for //e */
  if (x==-83) {k=255; return;}
  if (x==-66) prtsc();
  if (x==-60)   /* toggle hresmode via <F2> */
  {
    virtsethresmode( (virtgethresmode() + 1) & 0x1);
  }
  if (x==-61)   /* toggle monochrome/colour via <F3> */
  {
   virtsetmonochrome( (virtgetmonochrome() + 1) & 0x3);
  }
#ifdef DEBUG
  if (x==-62)
  {
   proc.Trace=1; /* this doesn't do anything for the Z80, but who cares for
                    now? -uso. */
  }
#endif
  if (x==-67||x==-112)
  {
   k=0;
   cpuinuse=emu6502;
   DiskReset();
   Reset6502(&proc);
#ifdef EMUZ80
   Z80_Reset();
#endif
   memoryreset();
   virtreset();
   return;
  }

 }
}


/*-------------------------------------*/


void memoryreset()
{
  memauxread    = 0;
  memauxwrite   = 0;
  memintcxrom   = 0;            /* read from slot rom $c100-$cfff               */
  memslotc3     = 0x80;         /* read slot rom                                */
  memlcaux      = 0;            /* read $0-$1ff + $d000-$ffff from main memory  */
  memlcramr     = 0;            /* read ROM                                     */
  memlcramw     = 0;            /* write ROM?                                   */
  memlcbank2    = 0;            /* read from LC bank 1                          */
  memstore80    = 0;            /* 80 store off                                 */
  memann3       = 0x80;         /* annunciator #3 on                            */
} /* MemoryReset */


/*-------------------------------------*/


void memoryclear()
{
  memset(RAM,0,49152);
  memset(RAMEXT,0,16384);
  memset(bankram1,0,49152);
  memset(bankram2,0,16384);
} /* MemoryClear */


/*-------------------------------------*/


void Wr6502(register word addr, register byte val)
{

  if (addr < 0xc000) {
    if (addr < 0x2000) {
      if (addr < 0x400) {
        if (addr < 0x200) {
/* $0000 - $01ff */
          if (memlcaux)         { bankram1[addr] = val; return; }                       /* aux 64 */
          else                  { RAM[addr]      = val; return; }                       /* main 64 */
        }
        else {
/* $0200 - $03ff */
          if (memauxwrite)      { bankram1[addr] = val; return; }                       /* aux 64 */
          else                  { RAM[addr]      = val; return; }                       /* main 64 */
        }
      }
      else {
        if (addr < 0x800) {
/* $0400 - $07ff */
          if (memstore80) {
            if (gm&PG2) {
              if (bankram1[addr] != val) {
                                bankram1[addr] = val;                                   /* aux 64 */
/*                              virtwrite0400aux(Addr); used with 80col */
              }
              return;
            }
            else {
              if (RAM[addr] != val) {
                                RAM[addr] = val;                                        /* main 64 */
                                virtwrite0400(addr);
              }
              return;
            }
          } /* if (memstore80) */
          else {
            if (memauxwrite) {
              if (bankram1[addr] != val) {
                                bankram1[addr] = val;                                   /* aux 64 */
/*                              virtwrite0400aux(addr); used with 80col */
              }
              return;
            }
            else {
              if (RAM[addr] != val) {
                                RAM[addr] = val;                                        /* main 64 */
                                virtwrite0400(addr);
              }
              return;
            }
          } /* else if (memstore80) */
        } /* if (addr < 0x800 */
        else {
          if (addr < 0xc00) {
/* $0800 - $0bff */
            if (memauxwrite) {
              if (bankram1[addr] != val) {
                                bankram1[addr] = val;                                   /* aux 64 */
/*                              virtwrite0800aux(addr); used with 80col */
              }
              return;
            }
            else {
              if (RAM[addr] != val) {
                                RAM[addr] = val;                                        /* main 64 */
                                virtwrite0800(addr);
              }
              return;
            }
          }
          else {
/* $0c00 - $1fff */
            if (memauxwrite)    { bankram1[addr] = val; return; }                       /* aux 64 */
            else                { RAM[addr]      = val; return; }                       /* main 64 */
          }
        }
      }
    } /* if (addr < 0x2000) */
    else {
      if (addr < 0x4000) {
/* $2000 - $3fff */
        if ((memstore80) && (gm&HRG)) {
          if (gm&PG2) {
            if (bankram1[addr] != val) {
                                bankram1[addr] = val;                                   /* aux 64 */
                                virtwrite2000aux(addr);
            }
            return;
          }
          else {
            if (RAM[addr] != val) {
                                RAM[addr] = val;                                        /* main 64 */
                                virtwrite2000(addr);
            }
            return;
          }
        }
        else {
          if (memauxwrite) {
            if (bankram1[addr] != val) {
                                bankram1[addr] = val;                                   /* aux 64 */
                                virtwrite2000aux(addr);
            }
            return;
          }
          else {
            if (RAM[addr] != val) {
                                RAM[addr] = val;                                        /* main 64 */
                                virtwrite2000(addr);
            }
            return;
          }
        }
      }
      else {
        if (addr < 0x6000) {
/* $4000 - $5fff */
          if (memauxwrite) {
            if (bankram1[addr] != val) {
                                bankram1[addr] = val;                                   /* aux 64 */
                                virtwrite4000aux(addr);
            }
            return;
          }
          else {
            if (RAM[addr] != val) {
                                RAM[addr] = val;                                        /* main 64 */
                                virtwrite4000(addr);
            }
            return;
          }
        }
        else {
/* $6000 - $bfff */
          if (memauxwrite)      { bankram1[addr] = val; return; }                       /* aux 64 */
          else                  { RAM[addr]      = val; return; }                       /* main 64 */
        }
      }
    }
  } /* if (addr < 0xc000) */
  else {
    if (addr >= 0xd000) {
      if (!memlcramw) {
        return;                         /* ROM is the same for whatever memlcaux is set to */
      }
      else {
        if (memlcaux) {
          if (addr < 0xe000) {
            if (memlcbank2) {
              bankram2[(addr-0xd000)+0x3000] = val;
              return;
            }
          }
          bankram2[addr-0xd000] = val;
          return;
        }
        else {
          if (addr < 0xe000) {
            if (memlcbank2) {
              RAMEXT[(addr-0xd000)+0x3000] = val;
              return;
            }
          }
          RAMEXT[addr-0xd000] = val;
          return;
        }
      } /* else if (memlcramw) */
    } /* if (addr => 0xd000 */
    else {

 /* test for softswitch area */
      if (addr <= 0xc0ff) {

      if (debugger) return;

        if (addr <= 0xc00f) {
          if (ROM16K) { /* only on Apple//e */
            switch (addr) {
              case 0xc000 : { if (memstore80) {
                                memstore80 = 0;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc001 : { if (!memstore80) {
                                memstore80 = 0x80;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc002 : { memauxread        = 0;    return; }
              case 0xc003 : { memauxread        = 0x80; return; }
              case 0xc004 : { memauxwrite       = 0;    return; }
              case 0xc005 : { memauxwrite       = 0x80; return; }
              case 0xc006 : { memintcxrom       = 0;    return; }        /* SLOTCXROM Off */
              case 0xc007 : { memintcxrom       = 0x80; return; }        /* SLOTCXROM On */
              case 0xc008 : { memlcaux          = 0;    return; }
              case 0xC009 : { memlcaux          = 0x80; return; }
              case 0xc00a : { memslotc3         = 0;    return; }        /* SLOTC3ROM Off */
              case 0xc00b : { memslotc3         = 0x80; return; }        /* SLOTC3ROM On */
              case 0xc00c : { if (virt80col) {
                                virt80col = 0;
                                virtdhres = 0;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc00d : { if (!virt80col) {
                                virt80col = 0x80;
                                if (!memann3) { virtdhres = 0x80; }
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc00e : { if (virtaltchar) {                /* only update if there was a change */
                                virtaltchar = 0;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc00f : { if (!virtaltchar) {               /* only update if there was a change */
                                virtaltchar = 0x80;
                                virtsetmode();
                              }
                              return;
                            }
            } /* switch */
          } /* if (ROM16K) */
          else return;
        } /* if (addr <= 0xc00f */

        if (addr <= 0xc01f) {
          if (k!=-1) k&=0x7f;
          return;
        }

        if (addr <= 0xc02f)                             return;   /* Cassette output toggle */

        if (addr <= 0xc03f)     { click(); /*click();*/ return; } /* Speaker */

        if (addr <= 0xc04f)                             return;   /* Utility output strobe - nani yo? */

        if (addr <= 0xc06f) {
          switch (addr) {
            case 0xc050 : { if (!(gm&GRX)) {
                              gm|=GRX;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc051 : { if (gm&GRX) {
                              gm&=~GRX;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc052 : { if (gm&SPL) {
                              gm&=~SPL;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc053 : { if (!(gm&SPL)) {
                              gm|=SPL;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc054 : { if (gm&PG2) {
                              gm &= ~PG2;
                              if (!memstore80) {
                                virtcachemode = (((virtcachemode & 0xfe) + 2) & 0xfe) | (virtcachemode & 0xff00);
                                virtsetmode();
                              }
                            }
                            return;
                          }
            case 0xc055 : { if (!(gm&PG2)) {
                              gm |= PG2;
                              if (!memstore80) {
                                virtsetmode();
                              }
                            }
                            return;
                          }
            case 0xc056 : { if (gm&HRG) {
                              gm&=~HRG;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc057 : { if (!(gm&HRG)) {
                              gm|=HRG;
                              virtsetmode();
                            }
                            return;
                          }

            case 0xc058 : return; /* Out0-off - nani yo? */
            case 0xc059 : return; /* Out0-on - nani yo? */
            case 0xc05a : return; /* Out1-off - nani yo? */
            case 0xc05b : return; /* Out1-on - nani yo? */
            case 0xc05c : return; /* Out2-off - nani yo? */
            case 0xc05d : return; /* Out2-on - nani yo? */
            case 0xc05e : {
                            if (virtiou) {
                              memann3 = 0;		/* annunciator#3 off */
                              if (!virtdhres) {
                                if (virt80col) {
                                  virtdhres = 0x80;	/* double hires on   */
                                  virtsetmode();
                                }
                              }
                            }
                            return;
                          }
            case 0xc05f : {
                            if (virtiou) {
                              memann3 = 0x80;           /* annunciator#3 on */
                              if (virtdhres) {
                                virtdhres = 0;          /* double hires off */
                                virtsetmode();
                              }
                            }
                            return;
                          }
            case 0xc060 :
            case 0xc068 : return; /* Cassette input */
            case 0xc061 :
            case 0xc069 : return;
            case 0xc062 :
            case 0xc06a : return;
            case 0xc063 :
            case 0xc06b : return;
            case 0xc064 :
            case 0xc06c : return; /* Pdl0 */
            case 0xc065 :
            case 0xc06d : return; /* Pdl1 */
            case 0xc066 :
            case 0xc06e : return; /* Pdl2 */
            case 0xc067 :
            case 0xc06f : return; /* Pdl3 */
          } /* switch (addr) */
        } /* if (addr <= 0xc06f */

        if (addr == 0xc070) {
          extern byte ResetGameTimer(word Address);
          ResetGameTimer(addr);
          return;
        }

        if (addr <= 0xc07f) {
          switch (addr) {
/* The following still has to be included :
C073 49367 BANKSEL       ECG W    Memory Bank Select for > 128K
C07E 49278 IOUDISON      EC  W    Disable IOU
           RDIOUDIS      EC   R7  Status of IOU Disabling
C07F 49279 IOUDISOFF     EC  W    Enable IOU
           RDDHIRES      EC   R7  Status of Double HiRes
*/
            case 0xc07e : { virtiou = 0;    return; }
            case 0xc07f : { virtiou = 0x80; return; }

          } /* switch */
          return;
        }

/* Language Card Handling */
        if (addr <= 0xc08f) {
          switch (addr) {
            case 0xc080 :
            case 0xc084 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc081 :
            case 0xc085 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
            case 0xc082 :
            case 0xc086 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc083 :
            case 0xc087 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
            case 0xc088 :
            case 0xc08c : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc089 :
            case 0xc08d : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
            case 0xc08a :
            case 0xc08e : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc08b :
            case 0xc08f : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
          } /* switch */
        }

/* Slot #1 Softswitches: Parallel Port */
        if (addr >= 0xc090 && addr <= 0xc09f) {
          WriteParallel (addr, val);    return;
        }

/* Slot #5 Softswitches */
        if (addr >= 0xc0d0 && addr <= 0xc0df) {
          WriteRawDiskIO (addr, val);   return;
        }

/* Slot #6 Softswitches */
        if (addr >= 0xc0e0 && addr <= 0xc0ef) {
          WriteDiskIO (addr, val);      return;
        }

/* Slot #7 Softswitches */
        if (addr >= 0xc0f0 && addr <= 0xc0ff && (!dqhdv)) {
          WriteMassStorIO (addr, val);  return;
        }


/* The remaining addresses between 0xc000 and 0xc0ff are simply ignored. */
        return;
      } /* if (addr <= 0xc0ff */

      if (memintcxrom) { return; }

/* Slot #4: Z80 */
// if (Addr>=50432 && Addr<=50687)
#ifdef EMUZ80
        if (addr==0xc400) {
          if (cpuinuse==emuZ80) { /* from manual */
            cpuinuse=emu6502;
            return;
          }
          cpuinuse=emuZ80;
          return;
        }
#endif
        return;
    } /* else (if addr >= 0xd000 */
  } /* else (if (addr < 0xc000 */
}




/*-------------------------------------*/


byte Rd6502(register word addr)
{

  if (addr < 0xc000) {
    if (addr < 0x2000) {
      if (addr < 0x400) {
        if (addr < 0x200) {
/* $0000 - $01ff */
          if (memlcaux)         { return bankram1[addr]; }                      /* aux 64 */
          else                  { return RAM[addr]; }                           /* main 64 */
        }
        else {
/* $0200 - $03ff */
          if (memauxread)       { return bankram1[addr]; }                      /* aux 64 */
          else                  { return RAM[addr]; }                           /* main 64 */
        }
      }
      else {
        if (addr < 0x800) {
/* $0400 - $07ff */
          if (memstore80) {
            if (gm&PG2)         { return bankram1[addr]; }                      /* aux 64 */
            else                { return RAM[addr]; }                           /* main 64 */
          }
          else {
            if (memauxread)     { return bankram1[addr]; }                      /* aux 64 */
            else                { return RAM[addr]; }                           /* main 64 */
          }
        }
        else {
/* $0800 - $1fff */
          if (memauxread)       { return bankram1[addr]; }                      /* aux 64 */
          else                  { return RAM[addr]; }                           /* main 64 */
        }
      }
    } /* if (addr < 0x2000) */
    else {
      if (addr < 0x4000) {
/* $2000 - $3fff */
        if ((memstore80) && (gm&HRG)) {
          if (gm&PG2)           { return bankram1[addr]; }                      /* aux 64 */
          else                  { return RAM[addr]; }                           /* main 64 */
        }
        else {
          if (memauxread)       { return bankram1[addr]; }                      /* aux 64 */
          else                  { return RAM[addr]; }                           /* main 64 */
        }
      }
      else {
/* $4000 - $bfff */
        if (memauxread)         { return bankram1[addr]; }                      /* aux 64 */
        else                    { return RAM[addr]; }                           /* main 64 */
      }
    }
  } /* if (addr < 0xc000) */
  else {
    if (addr >= 0xd000) {
      if (!memlcramr) {
        return ROM[addr-0xd000];        /* ROM is the same for whatever memlcaux is set to */
      }
      else {
        if (memlcaux) {
          if (addr < 0xe000) {
            if (memlcbank2) {
              return bankram2[(addr-0xd000)+0x3000];
            }
          }
          return bankram2[addr-0xd000];
        }
        else {
          if (addr < 0xe000) {
            if (memlcbank2) {
              return RAMEXT[(addr-0xd000)+0x3000];
            }
          }
          return RAMEXT[addr-0xd000];
        }
      } /* else if (memlcramr) */
    } /* if (addr => 0xd000 */
    else {

 /* test for softswitch area */
      if (addr <= 0xc0ff) {

        if (addr <= 0xc00f) { return (byte) k; }        /* keyboard */

        if (debugger) return 0x0d;      /* avoid accessing softswitches from the debugger */

        if (addr <= 0xc01f) {
          if (ROM16K) {
            switch (addr) {
              case 0xc010 :     { if (k!=-1) k&=0x7f;
                                  return k&0x7f;        /* not correct (undefined so far) */
                                }
              case 0xc011 :     return (memlcbank2  | (k&0x7f));
              case 0xc012 :     return (memlcramr   | (k&0x7f));
              case 0xc013 :     return (memauxread  | (k&0x7f));
              case 0xc014 :     return (memauxwrite | (k&0x7f));
              case 0xc015 :     return (memintcxrom | (k&0x7f));
              case 0xc016 :     return (memlcaux    | (k&0x7f));
              case 0xc017 :     return (memslotc3   | (k&0x7f));
              case 0xc018 :     return (memstore80  | (k&0x7f));
              case 0xc019 :     return (rasterline<192) ? ((k&0x7f)|0x80) : (k&0x7f);
              case 0xc01a :     return (gm&GRX)     ? (k&0x7f) : ((k&0x7f)|0x80);
              case 0xc01b :     return (gm&SPL)     ? ((k&0x7f)|0x80) : (k&0x7f);
              case 0xc01c :     return (gm&PG2)     ? ((k&0x7f)|0x80) : (k&0x7f);
              case 0xc01d :     return (gm&HRG)     ? ((k&0x7f)|0x80) : (k&0x7f);
              case 0xc01e :     return (virtaltchar | (k&0x7f));
              case 0xc01f :     return (virt80col   | (k&0x7f));
            } /* switch */
          }
          else {
            if (k!=-1) k&=0x7f;
            return k&0x7f;      /* not correct (undefined so far) */
          }
        }


        if (addr <= 0xc02f)                             return k&0x7f;    /* Cassette output toggle */

        if (addr <= 0xc03f)     { click();              return k&0x7f; } /* Speaker */

        if (addr <= 0xc04f)                             return k&0x7f;   /* Utility output strobe - nani yo? */

        if (addr <= 0xc06f) {
          switch (addr) {
            case 0xc050 : { if (!(gm&GRX)) {
                              gm|=GRX;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc051 : { if (gm&GRX) {
                              gm&=~GRX;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc052 : { if (gm&SPL) {
                              gm&=~SPL;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc053 : { if (!(gm&SPL)) {
                              gm|=SPL;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc054 : { if (gm&PG2) {
                              gm &= ~PG2;
                              if (!memstore80) {
                                virtcachemode = (((virtcachemode & 0xfe) + 2) & 0xfe) | (virtcachemode & 0xff00);
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc055 : { if (!(gm&PG2)) {
                              gm |= PG2;
                              if (!memstore80) {
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc056 : { if (gm&HRG) {
                              gm&=~HRG;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc057 : { if (!(gm&HRG)) {
                              gm|=HRG;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }

            case 0xc058 : return virtvideobyte; /* Out0-off - nani yo? */
            case 0xc059 : return virtvideobyte; /* Out0-on - nani yo? */
            case 0xc05a : return virtvideobyte; /* Out1-off - nani yo? */
            case 0xc05b : return virtvideobyte; /* Out1-on - nani yo? */
            case 0xc05c : return virtvideobyte; /* Out2-off - nani yo? */
            case 0xc05d : return virtvideobyte; /* Out2-on - nani yo? */
            case 0xc05e : {
                            if (virtiou) {
                              memann3 = 0;		/* annunciator#3 off */
                              if (virt80col) {
                                if (!virtdhres) {
                                  virtdhres = 0x80;	/* double hires on   */
                                  virtsetmode();
                                }
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc05f : {
                            if (virtiou) {
                              memann3 = 0x80;           /* annunciator#3 on */
                              if (virtdhres) {
                                virtdhres = 0;          /* double hires off */
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc060 : return 255; // was nothing here -uso.
            case 0xc068 : return 0x00; /* Cassette input */
            case 0xc061 :
            case 0xc069 : if (joya()) {
                            return 128;
                          } else {
                            return 0;
                          }
            case 0xc062 :
            case 0xc06a : if (joyb()) {
                            return 128;
                          } else {
                            return 0;
                          }
            case 0xc063 :
            case 0xc06b : if (*shiftstate&3) return dqshift?128:0; else return 128;
            case 0xc064 :
            case 0xc06c :       {
                                  extern byte ReadGameTimer(word Address);
                                  return ReadGameTimer(addr&0xFF);
                                }
            case 0xc065 :
            case 0xc06d :       {
                                  extern byte ReadGameTimer(word Address);
                                  return ReadGameTimer(addr&0xFF);
                                }
            case 0xc066 :
            case 0xc06e : return 0xa0; /* Pdl2 */
            case 0xc067 :
            case 0xc06f : return 0xa0; /* Pdl3 */
          } /* switch (addr) */
        } /* if (addr <= 0xc06f */

        if (addr == 0xc070) {
          extern byte ResetGameTimer(word Address);
          ResetGameTimer(addr);
          return 0xa0;
        }

        if (addr <= 0xc07f) {
          switch (addr) {
/* The following still has to be included :
C073 49367 BANKSEL       ECG W    Memory Bank Select for > 128K
C07E 49278 IOUDISON      EC  W    Disable IOU
           RDIOUDIS      EC   R7  Status of IOU Disabling
C07F 49279 IOUDISOFF     EC  W    Enable IOU
           RDDHIRES      EC   R7  Status of Double HiRes
*/
            case 0xc07e : {
                            if (ROM16K) { return ((virtiou)   | (virtvideobyte & 0x7f)); }
                            else { return virtvideobyte; }
                          }
            case 0xc07f : {
                            if (ROM16K) { return ((virtdhres) | (virtvideobyte & 0x7f)); }
                            else { return virtvideobyte; }
                          }

          } /* switch */
          return virtvideobyte;
        }

/* Language Card Handling */
        if (addr <= 0xc08f) {
          switch (addr) {
            case 0xc080 :
            case 0xc084 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return (k&0x7f);
                          }
            case 0xc081 :
            case 0xc085 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (k&0x7f);
                          }
            case 0xc082 :
            case 0xc086 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return (k&0x7f);
                          }
            case 0xc083 :
            case 0xc087 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (k&0x7f);
                          }
            case 0xc088 :
            case 0xc08c : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return (k&0x7f);
                          }
            case 0xc089 :
            case 0xc08d : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (k&0x7f);
                          }
            case 0xc08a :
            case 0xc08e : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return (k&0x7f);
                          }
            case 0xc08b :
            case 0xc08f : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (k&0x7f);
                          }
          } /* switch */
        }

/* Slot #1 Softswitches: Parallel Port */
        if (addr >= 0xc090 && addr <= 0xc09f) {
/*        return ReadParallel (addr); */
          return 0xa0;
        }

/* Slot #5 Softswitches */
        if (addr >= 0xc0d0 && addr <= 0xc0df) {
          return ReadRawDiskIO (addr);
        }

/* Slot #6 Softswitches */
        if (addr >= 0xc0e0 && addr <= 0xc0ef) {
          return ReadDiskIO (addr);
        }

/* Slot #7 Softswitches */
        if (addr >= 0xc0f0 && addr <= 0xc0ff && (!dqhdv)) {
          return dqhdv? 0xa0 : ReadMassStorIO (addr);
        }

/* The remaining addresses between 0xc000 and 0xc0ff are simply ignored. */
        return 0xa0;
      } /* if (addr <= 0xc0ff */
      else {
/* $c100 - $cfff */
        if (memintcxrom) return ROM[(addr-0xc100)+12288];
        else {
          if (addr <= 0xc1ff) return PICROM[addr-0xc100];       /* 1 */
          if (addr <= 0xc2ff) return 0xff;                      /* 2 */
          if (addr <= 0xc3ff) {                                 /* 3 */
            if (ROM16K) {
              if (memslotc3) { return 0xff; }
              else           { return ROM[(addr-0xc100)+12288]; }       /* copy of INTCXROM */
            }
            else             { return 0xff; }
          }
          if (addr <= 0xc4ff) return 0xff;                                      /* 4 */
          if (addr <= 0xc5ff) return HDDROM[addr-0xc500];                       /* 5 */
          if (addr <= 0xc6ff) return DISKROM[addr-0xc600];                      /* 6 */
          if (addr <= 0xc7ff) return dqhdv ? 0xff : HDDROM[addr-0xc700];        /* 7 */
          if (addr >= 0xc800) return ROM[(addr-0xc100)+12288];
          return 0xff;
        }
      } /* else if (addr <= 0xc0ff */
    } /* else if (addr >= 0xd000) */
  } /* else if (addr < 0xc000) */
} /* rd6502() */




static unsigned int flashloop=0;

#pragma warn -par
byte Loop6502(register M6502 *R)
{
 if (rasterline > 265) {
   rasterline = 0;
   PC2APL();
   if (!proc.Trace) proc.IPeriod=65; /* fix problem returning from debugger:
                                           slows down to a crawl */
   if (k==-1) return INT_QUIT;
   flashloop++;
   if ((flashloop&0x12)==0x12)
   {
     virtpalettesetd(COL_TXT_WHT2,0x00,0x00,0x00);
     virtpalettesetd(COL_TXT_WHT3,0xFF,0xFF,0xFF);
     virtpalettesetd(COL_TXT_AMB2,0x00,0x00,0x00);
     virtpalettesetd(COL_TXT_AMB3,0xBF,0x5F,0x00); // Changed //
     virtpalettesetd(COL_TXT_GRN2,0x00,0x00,0x00);
     virtpalettesetd(COL_TXT_GRN3,0x00,0xAF,0x00);
   }
   else if ((flashloop&0x12)==0)
   {
     virtpalettesetd(COL_TXT_WHT2,0xFF,0xFF,0xFF);
     virtpalettesetd(COL_TXT_WHT3,0x00,0x00,0x00);
     virtpalettesetd(COL_TXT_AMB2,0xFF,0xBF,0x00);
     virtpalettesetd(COL_TXT_AMB3,0x00,0x00,0x00);
     virtpalettesetd(COL_TXT_GRN2,0x00,0xAF,0x00);
     virtpalettesetd(COL_TXT_GRN3,0x00,0x00,0x00);
   }

   virtscreencopy();
   return 0;
 }
 else {
   if (rasterline <= 191) {
     virtline(rasterline);
   }
   rasterline++;
   return 0;
 }
}
#pragma warn +par

int brun(char *filename)
{
 unsigned short int ca,address,length;
 unsigned long int fl;
 FILE *file;
 char *errstr;

 file=fopen(filename,"rb");
 gotoxy(1,25);
 if (!file)
 {
  perror(filename);
  return -1;
 }
 fseek(file,0,SEEK_END);
 fl=ftell(file)-4;
 fseek(file,0,SEEK_SET);
 fread(&address,2,1,file);
 fread(&length,2,1,file);
 gotoxy(1,25);

 if (fl+address>49152) return -2;

 for (ca=address; fl; fl--, ca++) Wr6502(ca,fgetc(file));

 fclose(file);

 proc.PC.W=address;
 return 0;
}

void main (int argc, char **argv)
{
 FILE  *rom;
 unsigned int travel,cm;
 struct text_info ti;
 int initaddr=-1370;
 int ignini=0;
 extern char hd1[128],hd2[128];

 stdprn->flags|=_F_BIN; /* makes the printer a binary file? */

 strcpy(hd1,"hdv1.hdv");
 strcpy(hd2,"hdv2.hdv");

 /* if (!isatty(fileno(stdin))) */
   freopen("con","r",stdin);

// if (argc>3) {usage(); return;}

 harderr(critical_error_handler);

 oldshift=*shiftstate;
#ifndef SAFE
 *shiftstate=96;
#endif

 gettextinfo(&ti);
 cm=ti.currmode;

 _setcursortype(_NOCURSOR);


 rom=fopen("disk.rom","rb");
 if (!rom)
 {
  printf ("disk ][ : ROM not available\n");
 }
 fread(DISKROM,256,1,rom);
 fclose(rom);
 rom=fopen("parallel.rom","rb");
 fread(PICROM,256,1,rom);
 fclose(rom);
 rom=fopen("massstor.rom","rb");
 fread(HDDROM,256,1,rom);
 fclose(rom);
 {
  void rdini(void);

  rdini();
 }

  proc.IPeriod = 65;    /* 65 clock cycles per 280 raster lines => one screen refresh */

 InitDisk( 6 );

 if (argc>1)
 {
  int travel;

  for (travel=1; travel<argc; travel++)
  {
   if (!stricmp(argv[travel],"/nosaveini"))
   {
    ignini=1;
   }
   if (!stricmp(argv[travel],"/nohd"))
   {
    dqhdv=1;
   }
   if (!stricmp(argv[travel],"/green"))
   {
    virtsetmonochrome(2);
   }
   if (!stricmp(argv[travel],"/white"))
   {
    virtsetmonochrome(1);
   }
   if (!stricmp(argv[travel],"/amber"))
   {
    virtsetmonochrome(3);
   }
   if (!stricmp(argv[travel],"/color"))
   {
    virtsetmonochrome(0);
   }
   if (!stricmp(argv[travel],"/rom"))
   {
    travel++;
    strcpy(rompath,argv[travel]);
   }
   if (!stricmp(argv[travel],"/d1"))
   {
    travel++;
    UnmountDisk(0);
    strcpy(DrvSt[0].DiskFN, argv[travel]);
    DrvSt[0].DiskType = UnknownType;
    MountDisk(0);
   }
   if (!stricmp(argv[travel],"/d2"))
   {
    travel++;
    UnmountDisk(1);
    strcpy(DrvSt[1].DiskFN, argv[travel]);
    DrvSt[1].DiskType = UnknownType;
    MountDisk(1);
   }
   if (!stricmp(argv[travel],"/h1"))
   {
    dqhdv=0;
    strcpy(hd1,argv[++travel]);
   }
   if (!stricmp(argv[travel],"/h2"))
   {
    dqhdv=0;
    strcpy(hd2,argv[++travel]);
   }
   if (!stricmp(argv[travel],"/q"))
   {
    if (initaddr==-1370)
     initaddr=-1;
   }
   if (!stricmp(argv[travel],"/nospeaker"))
   {
    smode=0;
   }
  }
 }

 InitMassStor( 7 );

/* automatic search for rom file */

 rom=fopen(rompath,"rb");
 if (!rom) {
   strcpy(rompath,"apple.rom");
   rom=fopen(rompath,"rb");
   if (!rom) {
     strcpy(rompath,"apple2o.rom");
     rom=fopen(rompath,"rb");
     if (!rom) {
       strcpy(rompath,"apple2m.rom");
       rom=fopen(rompath,"rb");
       if (!rom) {
         strcpy(rompath,"apple2eo.rom");
         rom=fopen(rompath,"rb");
         if (!rom) {
           printf ("No BIOS ROMs found.");
           goto veow;
         }
       }
     }
   }
 }
 fclose(rom);
 /* load rom, reset softswitches and init the video display */
 reload(rompath,&proc);

 proc.Trap=0xFFFF;
 proc.Trace=0;

 if (initaddr!=-1370 && initaddr!=-1) proc.PC.W=initaddr;

bow:

 if (initaddr==-1370) if (uimain(&proc)) goto eow;
 if (initaddr!=-1370) opengraph();
 gotoxy(1,25);
#ifndef NOXEXEC
 XRun6502(&proc);
#else
 Run6502(&proc);
#endif
 ShutdownMassStor();
 ShutdownDisk();
eow:
 {
  void wrini(void);

  if (!ignini) wrini();
 }
 gmode(T80);
 textmode(cm);
 textattr(7);
 clrscr();
#ifndef SAFE
 *shiftstate=oldshift; /* DJGPP won't let me get away with this! */
#endif
veow:
 _setcursortype(_NORMALCURSOR);
}
