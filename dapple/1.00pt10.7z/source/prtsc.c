/*
 * Print Dapple screen to Epson FX-80/RX-80 compatible printer, test code
 */
#include <stdio.h>

unsigned int point (unsigned int x, unsigned int y);

extern unsigned char virtscreen[64000];
#define virtgetpixel(x,y) virtscreen[(y*320)+x]

void prtsc (void)
{
 int i,j;

 fprintf (stdprn,"%cA%c",27,2);
 for (i=0;i<200;i++)
 {
  fprintf (stdprn,"%c*%c%c%c",27,4,128,2);
  for (j=0; j<319; j++)
  {
   if (virtgetpixel(j,i))
     fprintf (stdprn,"%c%c",0,0);
    else
     fprintf (stdprn,"%c%c",192,192);
  }
 }
 fprintf (stdprn,"%c%c2",0,27);
}
