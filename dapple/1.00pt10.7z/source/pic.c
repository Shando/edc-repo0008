/*
 * DAPPLE, Dosius' Apple, Apple ][/][+ Emulator
 * Copyright 2002 Steve Nickolas, portions by Holger Picker
 * Copyright 1996, 1997, 2002 Marat Fayzullin, Alex Krasivsky (M6502)
 *
 * Component:  PIC: Parallel interface
 * Revision:   (Wing 1.00pt9) 2002.1219
 *             0.33 "LOST KEY WEEKEND"
 * Code was taken from Andrew Gregory's emulator
 */

#include <stdio.h>
#include <string.h>

#define COL_DRV_OFF  0x24
#define COL_DRV_ON   0x25

extern unsigned char virtscreen[64000];
#define virtplot(x,y,c) virtscreen[(y*320)+x]=c
extern void virtscreencopy();
extern unsigned char virtcopy;

int tweakpic=0;

#ifdef DEFPAR
char parallel[128] = {DEFPAR};
#else
char parallel[128] = {"dapple.prn"};
#endif

#pragma argsused
void WriteParallel( unsigned int Address, unsigned char Data )
{
    FILE *file;

    switch ( Address & 0x0f )
    {
    case 0x00:
        virtplot(316,199,COL_DRV_ON);
        virtcopy = 1;
        virtscreencopy();
        /* load output port */
        if(!stricmp(parallel,"prn"))
        {
         fputc(tweakpic?Data:Data&0x7F,stdprn);
         fflush(stdprn);
         virtplot(316,199,0);
         virtcopy = 1;
         break;
        }
        file=fopen(parallel,"ab");
        if (file)
        {
         fputc(tweakpic?Data:Data&0x7F,file);
         fclose (file);
        }
        virtplot(316,199,0);
        virtcopy = 1;
    }
}
