#ifndef f_STDAFX_H

#define WINVER 0x0501

#include <vd2/system/vdtypes.h>

#endif
