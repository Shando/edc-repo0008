#ifndef f_STDAFX_H
#define f_STDAFX_H

#include <vd2/system/vdtypes.h>

#endif
