#include <stdafx.h>
#include <menu.inl>
