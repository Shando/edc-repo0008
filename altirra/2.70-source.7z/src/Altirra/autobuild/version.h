#ifndef AT_VERSION_H 
#define AT_VERSION_H 
#define AT_VERSION "2.70" 
#define AT_VERSION_PRERELEASE 0 
#endif 
