#ifndef f_AT_DEBUGGERLOG_H
#define f_AT_DEBUGGERLOG_H

#include <at/atcore/logging.h>

typedef ATLogChannel ATDebuggerLogChannel;

void ATInitDebuggerLogging();

#endif
