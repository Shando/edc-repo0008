#define _SECURE_SCL 0
#include <vd2/system/vdtypes.h>
