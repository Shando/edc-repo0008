#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <algorithm>
#include <string>
#include <vector>
#include <vd2/system/vdtypes.h>
