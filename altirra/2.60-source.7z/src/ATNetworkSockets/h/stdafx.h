#define WIN32_LEAN_AND_MEAN
#define _SECURE_SCL 0

#include <vd2/system/vdtypes.h>
#include <windows.h>
