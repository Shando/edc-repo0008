//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by atui.rc
//
#define IDD_CONFIGURE_ACCEL             301
#define IDC_STATIC_AVAILABLECOMMANDS    1001
#define IDC_AVAILCOMMANDS               1002
#define IDC_STATIC_QUICKSEARCH          1003
#define IDC_FILTER                      1004
#define IDC_STATIC_BOUNDCOMMANDS        1005
#define IDC_BOUNDCOMMANDS               1006
#define IDC_STATIC_SHORTCUT             1007
#define IDC_HOTKEY                      1008
#define IDC_REMOVE                      1009
#define IDC_ADD                         1010
#define IDC_RESET                       1011
#define IDC_CONTEXT                     1012
#define IDC_CHECK1                      1013
#define IDC_KEYUP                       1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        302
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           301
#endif
#endif
