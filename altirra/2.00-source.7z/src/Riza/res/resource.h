//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Riza.rc
//
#define IDC_RESCALE_IMAGE               1003
#define IDC_USE_OPENGL                  1004
#define IDC_REMOVE_DUPES                1005
#define IDC_WIDTH                       1006
#define IDC_HEIGHT                      1007
#define IDC_STATIC_OPENGL               1008
#define IDC_STATIC_WIDTH                1009
#define IDC_DRAW_CURSOR                 1010
#define IDC_POSITION_TRACKMOUSE         1011
#define IDC_POSITION_FIXED              1012
#define IDC_PANNING_DESKTOP             1013
#define IDC_PANNING_ACTIVEWINDOW        1014
#define IDC_RADIO5                      1015
#define IDC_PANNING_ACTIVECLIENT        1015
#define IDC_POSITION_X                  1016
#define IDC_POSITION_Y                  1017
#define IDD_SCREENCAP_OPTS              28444
#define IDC_STATIC_HEIGHT               1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
