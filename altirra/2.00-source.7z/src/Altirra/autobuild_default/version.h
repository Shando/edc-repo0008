#ifndef AT_VERSION_H
#define AT_VERSION_H

#define AT_VERSION "dev"
#define AT_VERSION_PRERELEASE 1

#endif
