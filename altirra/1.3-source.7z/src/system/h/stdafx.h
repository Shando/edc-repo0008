#define _WIN32_WINNT 0x0400
#include <vd2/system/vdtypes.h>
#include <vd2/system/atomic.h>
#include <vd2/system/thread.h>
#include <vd2/system/error.h>
#include <windows.h>
#include <process.h>
#include <intrin.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <ctype.h>
