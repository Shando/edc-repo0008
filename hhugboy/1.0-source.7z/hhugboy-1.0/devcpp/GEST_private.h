/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef GEST_PRIVATE_H
#define GEST_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.712"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	712
#define COMPANY_NAME	"hhug.me"
#define FILE_VERSION	"1.0.0.712"
#define FILE_DESCRIPTION	"hhugboy GB emulator"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"taizou 2013"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"hhugboy.exe"
#define PRODUCT_NAME	"hhugboy"
#define PRODUCT_VERSION	"1.0.0.712"

#endif /*GEST_PRIVATE_H*/
