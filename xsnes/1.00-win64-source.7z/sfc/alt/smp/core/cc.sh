g++-4.5 -std=gnu++0x -I../../../.. -o generate generate.cpp
