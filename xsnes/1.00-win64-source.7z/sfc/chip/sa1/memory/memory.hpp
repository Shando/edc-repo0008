uint8 bus_read(unsigned addr);
void bus_write(unsigned addr, uint8 data);
uint8 vbr_read(unsigned addr);

alwaysinline void op_io();
alwaysinline uint8 op_read(unsigned addr);
alwaysinline void op_write(unsigned addr, uint8 data);

uint8 mmcrom_read(unsigned addr);
void mmcrom_write(unsigned addr, uint8 data);

uint8 mmcbwram_read(unsigned addr);
void mmcbwram_write(unsigned addr, uint8 data);

uint8 mmc_sa1_read(unsigned addr);
void mmc_sa1_write(unsigned addr, uint8 data);

uint8 bitmap_read(unsigned addr);
void bitmap_write(unsigned addr, uint8 data);
