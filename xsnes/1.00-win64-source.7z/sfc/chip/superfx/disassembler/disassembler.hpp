void disassemble_opcode(char* output);
void disassemble_alt0(char* output);
void disassemble_alt1(char* output);
void disassemble_alt2(char* output);
void disassemble_alt3(char* output);
