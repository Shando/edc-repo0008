uint8 mmio_read(unsigned addr);
void mmio_write(unsigned addr, uint8 data);
