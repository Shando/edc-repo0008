#include <sfc/cpu/cpu.hpp>
#include <sfc/smp/smp.hpp>
#include <sfc/dsp/dsp.hpp>
#include <sfc/ppu/ppu.hpp>
