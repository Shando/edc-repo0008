#include <sfc/slot/satellaview/satellaview.hpp>
#include <sfc/slot/sufamiturbo/sufamiturbo.hpp>
