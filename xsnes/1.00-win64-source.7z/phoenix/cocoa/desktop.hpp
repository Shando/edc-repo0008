namespace phoenix {

struct pDesktop {
  static Size size();
  static Geometry workspace();
};

}
