namespace resource {
  extern const uint8_t advanced[611];
  extern const uint8_t audio[592];
  extern const uint8_t cheatEditor[937];
  extern const uint8_t folder[1176];
  extern const uint8_t game[1490];
  extern const uint8_t home[606];
  extern const uint8_t hotkeys[587];
  extern const uint8_t input[812];
  extern const uint8_t server[408];
  extern const uint8_t stateManager[378];
  extern const uint8_t timing[897];
  extern const uint8_t unverified[1675];
  extern const uint8_t up[652];
  extern const uint8_t video[662];
};
