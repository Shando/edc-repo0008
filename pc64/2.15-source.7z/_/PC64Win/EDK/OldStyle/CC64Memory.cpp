#include <EDK.h>
#include "General.h"
#include "CC64.h"
                
#define Class CC64
