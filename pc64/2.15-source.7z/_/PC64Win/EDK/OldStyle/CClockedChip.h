#ifndef CClockedChip_h
#define CClockedChip_h

#define CClockedChip Chip

