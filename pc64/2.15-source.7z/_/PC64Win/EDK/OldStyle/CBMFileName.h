#ifndef CBMFileName_h
#define CBMFileName_h

class CBMFileName : public Object {
public:

  CString Name;
  flag fDirectory;
  flag fOverwrite;
  flag fWildcards;
  char cType;
  char cMode;
  byte bUnit;
  byte bRecordLength;

  void Parse(CString NewName, int iChannel = 2, int iMaxLength = 16);
  flag Match(char* pcStart, char* pcEnd);

  inline operator CString() {
    return Name;
  }

  CBMFileName();
};

#endif
