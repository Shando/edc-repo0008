#ifndef CIECDisasm_h
#define CIECDisasm_h

#include "CIECMaster.h"

class CIECDisasm : public Object {
public:

  HWND hwnd;

  CLine ATN;
  CLine Clock;
  CLine Data;

  CIECDisasm(CIECMaster* pIECMaster);

};

#endif
