#ifndef CClockMaster_h
#define CClockMaster_h

#include "CClockedChip.h"

#define CClockMaster Chip

#undef Next

#endif
