#ifndef CPort_h
#define CPort_h

class CPort : public Port {
public:
  //void Init(const char* pcName, Object* pObject, pfnbb fnOnChange);
};

/*extern*/ void __cdecl MySetPort();
/*extern*/ void __cdecl MyGetPort();

#define SetPort(Port, Label) \
  __asm lea ECX,Port \
  __asm call MySetPort

#define GetPort(Port) \
  __asm lea EAX,Port \
  __asm call MyGetPort

inline void Connect(CPort& Port1, CPort& Port2) { Port1.ConnectTo(Port2); }
inline void Disconnect(CPort& Port) { Port.Disconnect(); }

#endif
