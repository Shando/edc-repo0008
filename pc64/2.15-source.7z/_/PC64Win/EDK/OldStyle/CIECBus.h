#ifndef CIECBus_h
#define CIECBus_h

#include "CLine.h"

class CIECBus : public Object {
public:

  CLine Reset;
  CLine SRQ;
  CLine ATN;
  CLine Clock;
  CLine Data;

};

#endif
