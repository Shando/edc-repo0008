#ifndef CLine_h
#define CLine_h

class CLine : public Line {
};


extern void __cdecl MySetHigh();
#define SetHigh(MyLine, Label) \
  __asm lea EAX,MyLine \
  __asm call MySetHigh


extern void __cdecl MySetLow();
#define SetLow(MyLine, Label) \
  __asm lea EAX,MyLine \
  __asm call MySetLow


extern void __cdecl MyTestHigh();
#define TestHigh(MyLine) \
  __asm lea EAX,MyLine \
  __asm call MyTestHigh


inline void Connect(CLine& Line1, CLine& Line2) { Line1.ConnectTo(Line2); }
inline void Connect(Line& Line1, CLine& Line2) { Line1.ConnectTo(Line2); }
inline void Connect(CLine& Line1, Line& Line2) { Line1.ConnectTo(Line2); }
inline void Disconnect(CLine& Line) { Line.Disconnect(); }

#endif
