#ifndef CIECMaster_h
#define CIECMaster_h

#include "CIECBus.h"
#include "CIECDevice.h"

class CIECMaster : public CIECBus {
public:

  CIECDevice* apDevice[32];
  int iDevice;

  CPU65xx* pCPU;
  byte* pbKernal;

  CIECMaster();
};

#endif
