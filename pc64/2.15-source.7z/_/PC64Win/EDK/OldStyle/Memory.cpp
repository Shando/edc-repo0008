////////////////////////////////////////////////////////////////////////////////
// Memory.cpp -- this file is part of the Emulator Developers Kit
// available at http://ourworld.compuserve.com/homepages/pc64/develop.htm
//
// For allocating persistent and emulator memory.


#include <EDK.h>

/*
#define Kb * 1024
#define Mb * 1024 Kb


void global AllocNormal(void*& pMem, int iSize);
void global FreeNormal(void*& pMem);

// for allocating persistent memory
void global MemAlloc(void*& pMem, int iSize);
void global MemFree(void*& pMem);

#define malloc(x) (error("do not use malloc(), use MemAlloc() instead\nin file " __FILE__ " at line %d", __LINE__), NULL)

// pointers can change after loading to a different address
void global RegisterPtr(void*& pPtr);

// for converting between function pointers and magic numbers
Event global BeforeSave;
Event global AfterLoad;

void global SaveSnapshot(void*& pMem);
void global LoadSnapshot(void*& pMem);

void global EmuAlloc(void*& pMem, int iSize);
void global EmuFree(void*& pMem, int iSize);



class Heap {

  byte* pbStartMem;
  byte* pbEndMem;
  byte* pbEndReserved;
  int iGranularity;

public:

  // constructor
  Heap() {
    pbStartMem = NULL;
    pbEndMem = NULL;
    pbEndReserved = NULL;
    int iGranularity = 4096;
  }

  // destructor
  Heap() {
    if (pbStartMem != NULL) {
      free(pbStartMem);
      pbStartMem = NULL;
    }
  }

  // allocate memory
  void global AllocMem(void*& pMem, int iSize);


  void global SaveSnapshot(void*& pMem);
  void global LoadSnapshot(void*& pMem);



};


// allocate memory
void global Heap::AllocMem(void*& pMem, int iSize) {

  // check parameters
  assert(&pMem != NULL);
  assert(iSize > 0);
  assert(iSize <= 16 Mb);


  //
  //if (iSize <= 256


  byte* pbNewEnd = pbEndMem + iSize;





  // allocate new at end of heap



}


// reading 4096 bytes from C:\Test.dat at offset 550239 failed
// in file blah.cpp at line 100


WriteFile hevent


void global Heap::SaveSnapshot(byte*& pbMem, int& iSize) {

  int iSize = 16 + (pbEndMem - pbStartMem + 7) & ~8;
  win(pMem = malloc(iSize));
  *(dword*)(pbMem + 0) = MAKEFOURCC('H', 'e', 'a', 'p');
  *(byte*)(pbMem + 4) = pbStartMem;
  *(int*)(pbMem + 8) = pbEndMem - pbStartMem;
  *(int*)(pbMem + 12) = iGranularity;

  BeforeSave.Broadcast();
  memcpy(pbMem + 16, pbStartMem, iSize - 16);
  AfterLoad.Broadcast();

}


void global Heap::LoadSnapshot(const byte* pbMem, int iSize) {


  memcpy(pbMem + 16, pbStartMem, iSize - 16);




  AfterLoad.Broadcast();


}




void Test() {

  byte* p = malloc(1024);

}
*/