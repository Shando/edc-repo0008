#include <EDK.h>
#include "General.h"
#include "CClockMaster.h"
