// old style check whether calling OnXxx assembler functions will destroy EBX/ESI/EDI
// TODO: delete that when the EDK works

#include <EDK.h>

#ifdef _DEBUG

static int iDepth;
static int aiSaveEBX[256];
static int aiSaveESI[256];
static int aiSaveEDI[256];


void SaveRegs() {
  __asm {
    mov EAX,iDepth
    mov aiSaveEBX[EAX*4],EBX
    mov aiSaveESI[EAX*4],ESI
    mov aiSaveEDI[EAX*4],EDI
    inc AL
    jne OK
    int 3
  OK:
    mov iDepth,EAX
  }
}


void CompareRegs(Object* p) {
  __asm {
    mov EAX,p
    mov EAX,iDepth
    and EAX,EAX
    jne OK
    int 3
  OK:
    dec AL
    mov iDepth,EAX
    cmp aiSaveEBX[EAX*4],EBX
    je EBXOK
    int 3
  EBXOK:
    cmp aiSaveESI[EAX*4],ESI
    je ESIOK
    int 3
  ESIOK:
    cmp aiSaveEDI[EAX*4],EDI
    je EDIOK
    int 3
  EDIOK:
  }
}

#endif
