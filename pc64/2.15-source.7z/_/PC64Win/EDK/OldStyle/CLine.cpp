#include <EDK.h>
#include "General.h"
#include "CLine.h"

#undef SetHigh
#undef SetLow
#undef TestHigh

static Line* p;

gproc(MySetHigh)
  mov p,EAX
  } if (!p->IsOutputHigh()) { p->SetOutputHigh(); } __asm {
  ret
endp


gproc(MySetLow)
  mov p,EAX
  } if (!p->IsOutputLow()) { p->SetOutputLow(); } __asm {
  ret
endp


gproc(MyTestHigh)
  mov p,EAX
  } static flag f = p->IsInputHigh(); __asm {
  cmp f,0
  ret
endp
