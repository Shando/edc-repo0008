////////////////////////////////////////////////////////////////////////////////
// Version.h -- this file is part of the Personal C64 Emulator
// available at http://ourworld.compuserve.com/homepages/pc64/develop.htm

#ifdef _DEBUG
  #define TITLE "PC64Win " VERSION " (Debug)"
#else
  #define TITLE "PC64Win " VERSION
#endif
#define VERSION "BETA 2.15"
#define HEXVER 0x0215
