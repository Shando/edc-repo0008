#include <EDK.h>
#include "General.h"
#include "CMsg.h"

#define Class CMsg

/*
  pfnv pfnNext;              // event handler of next message
  Object* pNextObject;     // parent object of next message
  Object* pObject;         // object which contains this CMsg
  pfnv pfnOnMsg;             // event handler when message occurs
*/

CMsg::CMsg() {
  pfnNext = NULL;
  pNextObject = NULL;
  pObject = NULL;
  pfnOnMsg = NULL;
}

CMsg::~CMsg() {
}

/*
  pfnv pfnNext;              // event handler of next message
  Object* pNextObject;     // parent object of next message
  CMsg* pLastMsg;           // last message in list
  CMsg* pFirstMsg;          // first message in list
*/

CSendMsg::CSendMsg() {
  pfnNext = NULL;
  pNextObject = NULL;
  pLastMsg = (CMsg*)this;
  pFirstMsg = (CMsg*)this;
}

CSendMsg::~CSendMsg() {
}

void Connect(CMsg& Msg, CSendMsg& SendMsg) {
  if (Msg.pfnOnMsg != NULL) {
    SendMsg.pLastMsg->pfnNext = Msg.pfnOnMsg;
    SendMsg.pLastMsg->pNextObject = Msg.pObject;
    SendMsg.pLastMsg = &Msg;
  }
}

void Disconnect(CMsg& /*Msg*/) {
}
