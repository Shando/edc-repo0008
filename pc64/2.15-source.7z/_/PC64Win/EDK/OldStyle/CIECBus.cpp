#include <EDK.h>
#include "General.h"
#include "CIECBus.h"

#define Class CIECBus
