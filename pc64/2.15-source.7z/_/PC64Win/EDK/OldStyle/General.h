#include "Version.h"
#include "Resource.h"

#define gproc(Name) \
  __declspec(naked) void __cdecl Name() { \
    __asm {

#define endp \
    } \
  }

#define resolve(x) x
#define fn(Name) resolve(Class)##Name

#define proc(Name) \
  __declspec(naked) void fn(Name)() { \
    __asm {

#define index(Number) \
  __asm _emit ((Number)) & 0xFF \
  __asm _emit ((Number) >> 8) & 0xFF \
  __asm _emit ((Number) >> 16) & 0xFF \
  __asm _emit ((Number) >> 24) & 0xFF
#define ip(Name) ((pfnv)((int)(Name) + 4))
#define fni(Name) ip(fn(Name))
#define fnia(Name) (fn(Name) + 4)
#define GetIndex(Address) (*(int*)((int)(Address) - 4))
#define GetIndexFromEBX __asm mov EBX,[EBX-4]

#define ThisReg ESI
#define mvar(Name) ([ThisReg]MSVC4Bug.##Name)

extern void __cdecl trace(char* pcFormat, ...);

extern HANDLE OpenFile(const char* pcName);
extern void ReadFile(HANDLE hFile, void* pBuffer, int Size);
extern void WriteFile(HANDLE hFile, const void* pBuffer, int Size);
extern const CString& GetDefaultDirectory();

#define global
