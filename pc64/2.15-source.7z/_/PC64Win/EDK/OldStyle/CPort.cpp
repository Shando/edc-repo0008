#include <EDK.h>
#include "General.h"
#include "CPort.h"

#undef SetPort
#undef GetPort

static Port* p;
static byte b;

gproc(MySetPort)
  mov p,ECX
  mov b,AL
  } p->SetOutput(b); __asm {
  ret
endp

gproc(MyGetPort)
  mov p,EAX
  } b = p->GetInput(); __asm {
  mov AL,b
  ret
endp
