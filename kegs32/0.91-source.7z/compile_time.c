
const char rcsid_compile_time_c[] = "@(#)$KmKId: compile_time.c,v 1.2 2002-11-14 01:02:44-05 kadickey Exp $";

char g_compile_time[] = "Compiled: " __DATE__ " " __TIME__ ;

