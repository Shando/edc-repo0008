
const char rcsid_compile_time_c[] = "@(#)$Header: compile_time.c,v 1.1 96/10/12 17:49:19 kentd Exp $";

char g_compile_time[] = "Compiled: " __DATE__ " " __TIME__ ;

