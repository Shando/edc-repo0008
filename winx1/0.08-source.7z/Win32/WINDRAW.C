// -----------------------------------------------------------------------------------
//  ����Xmil���痬�p�����Ă������Draw���[�`�� ^^;�B
//  �����ă��C���̂��͂邩�ɏo���������񂾂���`�i��
// -----------------------------------------------------------------------------------

#include	"..\win32\common.h"
#include	<ddraw.h>
#include	"..\win32\resource.h"
#include	"..\win32\winx1.h"
#include	"..\win32\windraw.h"

extern	HINSTANCE	hInst;
extern	HWND	hWndMain;
extern	int	fullscreen;
extern	BYTE	Draw_AllFlash;

static	LPDIRECTDRAW2		dd = NULL;
static	LPDIRECTDRAWSURFACE	prsurf = NULL;
static	LPDIRECTDRAWSURFACE	bksurf = NULL;
static	LPDIRECTDRAWCLIPPER	clipper = NULL;
static	LPDIRECTDRAWPALETTE	pal = NULL;
static	PALETTEENTRY		palentry[256];
static	LPDIRECTDRAWSURFACE	fddled = NULL;

	BYTE	palchanged = 0;
static	BYTE	SCREENMODE = 0;
static	RECT	rect200 = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};

	WORD	fcount = 0;

	PALETTE_TABLE	WinX1_Palette[128];
	BYTE	WinDraw_ScreenMap[SCREEN_WIDTH * SCREEN_HEIGHT];
	BYTE	WinDraw_RenewalLine[SCREEN_HEIGHT+2];

	BYTE	x2mode = 1;
	WORD	putlines = SCREEN_HEIGHT;

	WORD	WinX1_Pal16[128];
	WORD	WinX1_Pal16B;
	WORD	WinX1_Pal16R;
	WORD	WinX1_Pal16G;

	int	winx=0, winy=0;
	int	winh=0, winw=0;

extern	BYTE	FDD_LED;
	BYTE	FDD_LED_SW;

void WinDraw_InitWindowSize(WORD width, WORD height) {

	RECT	rectWindow, rectClient;
	int	scx, scy;

	GetWindowRect(hWndMain, &rectWindow);
	GetClientRect(hWndMain, &rectClient);
	winw = width + (rectWindow.right - rectWindow.left)
					- (rectClient.right - rectClient.left);
	winh = height + (rectWindow.bottom - rectWindow.top)
					- (rectClient.bottom - rectClient.top);

	scx = GetSystemMetrics(SM_CXSCREEN);
	scy = GetSystemMetrics(SM_CYSCREEN);

	if (scx < winw)
		winx = (scx - winw) / 2;
	else if (winx < 0)
		winx = 0;
	else if ((winx + winw) > scx)
		winx = scx - winw;
	if (scy < winh)
		winy = (scy - winh) / 2;
	else if (winy < 0)
		winy = 0;
	else if ((winy + winh) > scy)
		winy = scy - winh;
}

void WinDraw_ChangeMode(int flag) {
	DWORD	winstyle, winstyleex;
	HMENU	hmenu = GetMenu(hWndMain);

	fullscreen = flag;
	winstyle = GetWindowLong(hWndMain, GWL_STYLE);
	winstyleex = GetWindowLong(hWndMain, GWL_EXSTYLE);
	if (fullscreen)
	{
		RECT rect;
		GetWindowRect(hWndMain, &rect);
		winx = rect.left;
		winy = rect.top;

		winstyle = (winstyle | WS_POPUP)
						& (~(WS_CAPTION | WS_OVERLAPPED | WS_SYSMENU));
		winstyleex |= WS_EX_TOPMOST;
		SetWindowLong(hWndMain, GWL_STYLE, winstyle);
		SetWindowLong(hWndMain, GWL_EXSTYLE, winstyleex);
		CheckMenuItem(hmenu, IDM_TOGGLEFULLSCREEN, MF_CHECKED);
	}
	else
	{
		winstyle = (winstyle | WS_CAPTION | WS_OVERLAPPED | WS_SYSMENU)
																& ~WS_POPUP;
		winstyleex &= ~WS_EX_TOPMOST;
		SetWindowLong(hWndMain, GWL_STYLE, winstyle);
		SetWindowLong(hWndMain, GWL_EXSTYLE, winstyleex);

		MoveWindow(hWndMain, winx, winy, winw, winh, TRUE);

		CheckMenuItem(hmenu, IDM_TOGGLEFULLSCREEN, MF_UNCHECKED);
	}
}



void WinDraw_Redraw(void)
{
	memset(WinDraw_RenewalLine, 1, SCREEN_HEIGHT+2);
}


void WinDraw_InitFlags(void) 
{
	ZeroMemory(WinDraw_ScreenMap, sizeof(WinDraw_ScreenMap));
	ZeroMemory(WinX1_Palette, sizeof(WinX1_Palette));
	WinDraw_Redraw();
}


void FASTCALL WinDraw_ChangePalette(void) {

	int		i;

	for (i=0; i<0x80; i++) {
		palentry[i+0x40].peRed = WinX1_Palette[i].b.red;
		palentry[i+0x40].peBlue = WinX1_Palette[i].b.blue;
		palentry[i+0x40].peGreen = WinX1_Palette[i].b.green;
	}

	if (SCREENMODE & SCMD_USEPAL) {
		palchanged = 1;
	}
	else {
		if (SCREENMODE == SCMD_WINDOW16) {
			for (i=0; i<0x80; i++) {
				WinX1_Pal16[i] = 0;
				if (WinX1_Palette[i].b.red) {
					WinX1_Pal16[i] |= WinX1_Pal16R;
				}
				if (WinX1_Palette[i].b.blue) {
					WinX1_Pal16[i] |= WinX1_Pal16B;
				}
				if (WinX1_Palette[i].b.green) {
					WinX1_Pal16[i] |= WinX1_Pal16G;
				}
			}
		}
		memset(WinDraw_RenewalLine, 1, sizeof(WinDraw_RenewalLine));
	}
}



void palette_set(void) {

	BYTE	i;
	HDC 	hdc = GetDC(hWndMain);

	GetSystemPaletteEntries(hdc, 0, 256, palentry);
	ReleaseDC(hWndMain, hdc);

	for (i=0x40; i<0xc0; i++) {
		palentry[i].peFlags = PC_RESERVED | PC_NOCOLLAPSE;
	}
	WinDraw_ChangePalette();
	IDirectDraw2_CreatePalette(dd, DDPCAPS_8BIT, palentry, &pal, 0);
	IDirectDrawSurface_SetPalette(prsurf, pal);
	palchanged = 0;
}

int WinDraw_Init(void)
{
	LPDIRECTDRAW	dd1;
	DDSURFACEDESC	ddsd;
	DDPIXELFORMAT	ddpf;

	HDC hdcs, hdcd;
	HANDLE hbmp,hbmpold;
	DDCOLORKEY ddck={ 0, 0};		// FDD�����v�p�J���[�L�[�B���͓���

	dd = NULL;
	prsurf = NULL;
	bksurf = NULL;
	clipper = NULL;
	pal = NULL;

	if (DirectDrawCreate(NULL, &dd1, NULL) != DD_OK) {
		return FALSE;
	}

	IDirectDraw_QueryInterface(dd1, &IID_IDirectDraw2, (void **)&dd);
	IDirectDraw_Release(dd1);
	dd1=0;

	if (fullscreen)
	{
		IDirectDraw2_SetCooperativeLevel(dd, hWndMain,
					DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT);
		if (IDirectDraw2_SetDisplayMode(dd, FULLSCREEN_WIDTH, FULLSCREEN_HEIGHT,
								 8, 0, 0) != DD_OK) {
			return FALSE;
		}
		IDirectDraw2_CreateClipper(dd, 0, &clipper, NULL);
		IDirectDrawClipper_SetHWnd(clipper, 0, hWndMain);

		ZeroMemory(&ddsd, sizeof(ddsd));
		ddsd.dwSize = sizeof(ddsd);
		ddsd.dwFlags = DDSD_CAPS;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
		if (IDirectDraw2_CreateSurface(dd, &ddsd, &prsurf, NULL) != DD_OK) {
			return FALSE;
		}

		ZeroMemory(&ddsd, sizeof(ddsd));
		ddsd.dwSize = sizeof(ddsd);
		ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
		ddsd.dwWidth = FULLSCREEN_WIDTH;
		ddsd.dwHeight = SCREEN_HEIGHT;
		if (IDirectDraw2_CreateSurface(dd, &ddsd, &bksurf, NULL) != DD_OK) {
			return FALSE;
		}

		SCREENMODE = SCMD_FULLSCREEN;
		palette_set();
	}
	else
	{
		IDirectDraw2_SetCooperativeLevel(dd, hWndMain, DDSCL_NORMAL);

		ZeroMemory(&ddsd, sizeof(ddsd));
		ddsd.dwSize = sizeof(ddsd);
		ddsd.dwFlags = DDSD_CAPS;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;

		if (IDirectDraw2_CreateSurface(dd, &ddsd, &prsurf, NULL) != DD_OK) {
			return FALSE;
		}

		IDirectDraw2_CreateClipper(dd, 0, &clipper, NULL);
		IDirectDrawClipper_SetHWnd(clipper, 0, hWndMain);
		IDirectDrawSurface_SetClipper(prsurf, clipper);

		ZeroMemory(&ddpf, sizeof(ddpf));
		ddpf.dwSize = sizeof(DDPIXELFORMAT);
		if (DD_OK != IDirectDrawSurface_GetPixelFormat(prsurf, &ddpf)) {
			return FALSE;
		}

		ZeroMemory(&ddsd, sizeof(ddsd));
		ddsd.dwSize = sizeof(ddsd);
		ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
		ddsd.dwWidth = SCREEN_WIDTH;
		ddsd.dwHeight = SCREEN_HEIGHT;

		if (IDirectDraw2_CreateSurface(dd, &ddsd, &bksurf, NULL) != DD_OK) {
			return FALSE;
		}
		if (ddpf.dwRGBBitCount == 8) {
			SCREENMODE = SCMD_WINDOW8;
			palette_set();
		}
		else if (ddpf.dwRGBBitCount == 16) {
			SCREENMODE = SCMD_WINDOW16;
			WinX1_Pal16B = (WORD)ddpf.dwBBitMask;
			WinX1_Pal16R = (WORD)ddpf.dwRBitMask;
			WinX1_Pal16G = (WORD)ddpf.dwGBitMask;
			palette_set();
		}
		else if (ddpf.dwRGBBitCount == 24) {
			SCREENMODE = SCMD_WINDOW24;
		}
		else if (ddpf.dwRGBBitCount == 32) {
			SCREENMODE = SCMD_WINDOW32;
		}
		else {
			return FALSE;
		}
	}

							// FDD�����v�pBITMAP��ǂݍ���
							// �T�[�t�F�C�X�쐬
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth = 64;
	ddsd.dwHeight = 40;
	if (IDirectDraw2_CreateSurface(dd, &ddsd, &fddled, NULL) != DD_OK) return FALSE;

							// BITMAP��ǂݍ���
	hbmp=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_FDDLED));

							// �T�[�t�F�C�X�֓]��
	hdcs=CreateCompatibleDC(NULL);
	hbmpold=SelectObject(hdcs, hbmp);
	IDirectDrawSurface_GetDC(fddled, &hdcd);
	BitBlt(hdcd, 0, 0, 44, 8, hdcs, 0, 0,SRCCOPY);
	IDirectDrawSurface_ReleaseDC(fddled, hdcd);
	SelectObject(hdcs, hbmpold);
	DeleteDC(hdcs);
	DeleteObject(hbmp);
							// ���͓��߂���悤�ɂ��Ă���
	IDirectDrawSurface_SetColorKey(fddled, DDCKEY_SRCBLT, &ddck);

	return TRUE;
}


void WinDraw_Cleanup(void) {

	if ((SCREENMODE == SCMD_FULLSCREEN) && (dd)) {
		IDirectDraw2_RestoreDisplayMode(dd);
		IDirectDraw2_SetCooperativeLevel(dd, hWndMain, DDSCL_NORMAL);
	}
	if (fddled ) IDirectDrawSurface_Release(fddled);
	if (bksurf ) IDirectDrawSurface_Release(bksurf);
	if (pal    ) IDirectDrawPalette_Release(pal);
	if (clipper) IDirectDrawClipper_Release(clipper);
	if (prsurf ) IDirectDrawSurface_Release(prsurf);
	if (dd     ) IDirectDraw2_Release(dd);
	fddled=0;
	prsurf=0;
	bksurf=0;
	pal=0;
	clipper=0;
	dd=0;
}


void FASTCALL WinDraw_Draws(void) {

	DDSURFACEDESC	ddsd;

	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);

	switch(SCREENMODE) {
		case SCMD_FULLSCREEN:
		case SCMD_WINDOW8:
			if (IDirectDrawSurface_Lock(bksurf, NULL, &ddsd, DDLOCK_WAIT, NULL) == DD_OK) {
				if (x2mode) {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine
x2win8bppdrlp1:			btr		word ptr [ebx], 0
						jnc		x2win8bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH/4
x2win8bppdrlp2:			mov		ax, [esi]
						add		ax, 0x4040
						mov		[edi], al
						mov		[edi+1], ax
						mov		[edi+3], ah
						add		esi, 2
						add		edi, 4
						dec		cx
						jne		x2win8bppdrlp2
						pop		edi
						pop		esi
x2win8bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, SCREEN_HEIGHT
						jc		x2win8bppdrlp1
						pop		edi
						pop		esi
					}
				}
				else {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine
x1win8bppdrlp1:			btr		word ptr [ebx], 0
						jnc		x1win8bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH/4
x1win8bppdrlp2:			mov		eax, [esi]
						add		eax, 0x40404040
						mov		[edi], eax
						add		esi, 4
						add		edi, 4
						dec		cx
						jne		x1win8bppdrlp2
						pop		edi
						pop		esi
x1win8bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, SCREEN_HEIGHT
						jc		x1win8bppdrlp1
						pop		edi
						pop		esi
					}
				}
				IDirectDrawSurface_Unlock(bksurf, NULL);
			}
			break;
		case SCMD_WINDOW16:
			if (IDirectDrawSurface_Lock(bksurf, NULL, &ddsd, DDLOCK_WAIT, NULL) == DD_OK) {
				if (x2mode) {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine
x2win16bppdrlp1:		btr		word ptr [ebx], 0
						jnc		x2win16bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH/2
x2win16bppdrlp2:		movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		ax, word ptr WinX1_Pal16[eax*2]
						mov		[edi], ax
						mov		[edi+2], ax
						inc		esi
						add		edi, 4
						dec		cx
						jne		x2win16bppdrlp2
						pop		edi
						pop		esi
x2win16bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, putlines
						jc		x2win16bppdrlp1
						pop		edi
						pop		esi
					}
				}
				else {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine

x1win16bppdrlp1:		btr		word ptr [ebx], 0
						jnc		x1win16bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH
x1win16bppdrlp2:		movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		ax, word ptr WinX1_Pal16[eax*2]
						mov		[edi], ax
						inc		esi
						add		edi, 2
						dec		cx
						jne		x1win16bppdrlp2
						pop		edi
						pop		esi
x1win16bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, putlines
						jc		x1win16bppdrlp1
						pop		edi
						pop		esi
					}
				}
				IDirectDrawSurface_Unlock(bksurf, NULL);
			}
			break;
		case SCMD_WINDOW24:
			if (IDirectDrawSurface_Lock(bksurf, NULL, &ddsd, DDLOCK_WAIT, NULL) == DD_OK) {
				if (x2mode) {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine
x2win24bppdrlp1:		btr		word ptr [ebx], 0
						jnc		x2win24bppdred
						push	esi
						push	edi
						mov		cx, (SCREEN_WIDTH/2) - 1
x2win24bppdrlp2:		movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		eax, dword ptr WinX1_Palette[eax*4]
						mov		[edi], eax
						mov		[edi+3], eax
						inc		esi
						add		edi, 6
						dec		cx
						jne		x2win24bppdrlp2
						movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		eax, dword ptr WinX1_Palette[eax*4]
						mov		[edi], eax
						mov		[edi+3], al
						shr		eax, 8
						mov		[edi+4], ax
						pop		edi
						pop		esi
x2win24bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, putlines
						jc		x2win24bppdrlp1
						pop		edi
						pop		esi
					}
				}
				else {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine

x1win24bppdrlp1:		btr		word ptr [ebx], 0
						jnc		x1win24bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH - 1
x1win24bppdrlp2:		movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		eax, dword ptr WinX1_Palette[eax*4]
						mov		[edi], eax
						inc		esi
						add		edi, 3
						dec		cx
						jne		x1win24bppdrlp2
						movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		eax, dword ptr WinX1_Palette[eax*4]
						mov		[edi], al
						shr		eax, 8
						mov		[edi+1], ax
						pop		edi
						pop		esi
x1win24bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, putlines
						jc		x1win24bppdrlp1
						pop		edi
						pop		esi
					}
				}
				IDirectDrawSurface_Unlock(bksurf, NULL);
			}
			break;
		case SCMD_WINDOW32:
			if (IDirectDrawSurface_Lock(bksurf, NULL, &ddsd, DDLOCK_WAIT, NULL) == DD_OK) {
				if (x2mode) {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine
x2win32bppdrlp1:		btr		word ptr [ebx], 0
						jnc		x2win32bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH/2
x2win32bppdrlp2:		movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		eax, dword ptr WinX1_Palette[eax*4]
						mov		[edi], eax
						mov		[edi+4], eax
						inc		esi
						add		edi, 8
						dec		cx
						jne		x2win32bppdrlp2
						pop		edi
						pop		esi
x2win32bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, putlines
						jc		x2win32bppdrlp1
						pop		edi
						pop		esi
					}
				}
				else {
					__asm {
						push	esi
						push	edi
						mov		esi, offset WinDraw_ScreenMap
						mov		edi, ddsd.lpSurface
						xor		edx, edx
						mov		ebx, offset WinDraw_RenewalLine

x1win32bppdrlp1:		btr		word ptr [ebx], 0
						jnc		x1win32bppdred
						push	esi
						push	edi
						mov		cx, SCREEN_WIDTH
x1win32bppdrlp2:		movzx	eax, byte ptr [esi]
						and		al, 0x7f
						mov		eax, dword ptr WinX1_Palette[eax*4]
						mov		[edi], eax
						inc		esi
						add		edi, 4
						dec		cx
						jne		x1win32bppdrlp2
						pop		edi
						pop		esi
x1win32bppdred:			add		esi, SCREEN_WIDTH
						add		edi, ddsd.lPitch
						inc		ebx
						inc		dx
						cmp		dx, putlines
						jc		x1win32bppdrlp1
						pop		edi
						pop		esi
					}
				}
				IDirectDrawSurface_Unlock(bksurf, NULL);
			}
			break;
	}
	fcount++;
}

void WinDraw_FDDLED()
{
	POINT	pt;
	RECT	rectDst;
	RECT	rectSrc;

	if (!FDD_LED_SW) return;
	if (FDD_LED)
	{
		pt.x = ((FDD_LED==1)?595:617);
		pt.y = 391;
		ClientToScreen(hWndMain, &pt);
		SetRect(&rectDst, pt.x, pt.y, pt.x + 22, pt.y + 8);
		SetRect(&rectSrc, ((FDD_LED==1)?0:22), 0, ((FDD_LED==1)?22:44), 8);
		if (fddled)
		{
			if (SCREENMODE==SCMD_FULLSCREEN)
				IDirectDrawSurface_BltFast(prsurf, ((FDD_LED == 2)?617:595), 391,
					fddled, &rectSrc, DDBLTFAST_WAIT|DDBLTFAST_SRCCOLORKEY);
			else
				IDirectDrawSurface_Blt(prsurf, &rectDst, fddled, &rectSrc, DDBLT_WAIT|DDBLT_KEYSRC, NULL);
		}
	}
	else
	{
		pt.x = 595;
		pt.y = 391;
		ClientToScreen(hWndMain, &pt);
		SetRect(&rectDst, pt.x, pt.y, (pt.x+44), (pt.y+8));
		SetRect(&rectSrc, 595, 391, 639, 399);
		if (bksurf)
		{
			if (SCREENMODE==SCMD_FULLSCREEN)
				IDirectDrawSurface_BltFast(prsurf, 595, 391,
					bksurf, &rectSrc, DDBLTFAST_WAIT);
			else
				IDirectDrawSurface_Blt(prsurf, &rectDst, bksurf, &rectSrc, DDBLT_WAIT, NULL);
		}
	}
}

void FASTCALL WinDraw_DrawAll(void) {

	POINT	pt;
	RECT	rectDst;

	switch(SCREENMODE) {
		case SCMD_WINDOW8:
			if ((palchanged) && (pal)) {
				palchanged = 0;
				IDirectDrawPalette_SetEntries(pal, 0, 0x40, 0x80, &palentry[0x40]);
			}
			if (bksurf != NULL) {
				pt.x = 0;
				pt.y = 0;
				ClientToScreen(hWndMain, &pt);
				SetRect(&rectDst, pt.x, pt.y, pt.x + 640, pt.y + 400);
				IDirectDrawSurface_Blt(prsurf, &rectDst, bksurf, &rect200, DDBLT_WAIT, NULL);
			}
			break;
		case SCMD_WINDOW16:
		case SCMD_WINDOW24:
		case SCMD_WINDOW32:
			if (bksurf != NULL) {
				pt.x = 0;
				pt.y = 0;
				ClientToScreen(hWndMain, &pt);
				SetRect(&rectDst, pt.x, pt.y, pt.x + 640, pt.y + 400);
				IDirectDrawSurface_Blt(prsurf, &rectDst, bksurf, &rect200, DDBLT_WAIT, NULL);
			}
			break;
		case SCMD_FULLSCREEN:
			if ((palchanged) && (pal)) {
				palchanged = 0;
				IDirectDrawPalette_SetEntries(pal, 0, 0x40, 0x80, &palentry[0x40]);
			}
			if (bksurf != NULL) {
				if (IDirectDrawSurface_BltFast(prsurf, 0, FULLSCREEN_POSY, bksurf,
							&rect200, DDBLTFAST_WAIT) == DDERR_SURFACELOST) {
					IDirectDrawSurface_Restore(prsurf);
					IDirectDrawSurface_Restore(bksurf);
				}
			}
			break;
	}
	WinDraw_FDDLED();
}

void WinDraw_Palette(void) {

	if (pal) {
		IDirectDrawSurface_SetPalette(prsurf, pal);
	}
}


void FASTCALL WinDraw_ChangeXMode(BYTE x2flag) {

	if (x2mode != x2flag) {
		x2mode = x2flag;
		memset(WinDraw_RenewalLine, 1, sizeof(WinDraw_RenewalLine));
	}
}

void WinDraw_ShowMenu(void)
{
	if (fullscreen) {
		IDirectDrawSurface_SetClipper(prsurf, clipper);
		ShowCursor(TRUE);
	}
}

void WinDraw_HideMenu(void)
{
	if (fullscreen) {
		IDirectDrawSurface_SetClipper(prsurf, 0);
		ShowCursor(FALSE);
		WinDraw_DrawAll();
	}
}
