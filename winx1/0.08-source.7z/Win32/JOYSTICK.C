// JOYSTICK.C - �W���C�X�e�B�b�N�T�|�[�g for WinX1
// DInput�̏������^�I���ƁA�W���C�X�e�B�b�N�|�[�g�`�F�b�N�iPSG����Ă΂��j

#include "..\win32\common.h"
#include "..\win32\resource.h"
#include <dinput.h>

extern	HWND		hWndMain;
extern	HINSTANCE	hInst;

LPDIRECTINPUT		dinput = NULL;
LPDIRECTINPUTDEVICE2	joy[2] = {NULL, NULL};

#ifndef MAX_BUTTON
#define MAX_BUTTON 32
#endif

char joyname[2][MAX_PATH];
char joybtnname[2][MAX_BUTTON][MAX_PATH];
BYTE joybtnnum[2] = {0, 0};

static	int		joyactive = 0;

extern BYTE Config_JOY_BTN[2][4];

#define	JOY_UP		0x01
#define	JOY_DOWN	0x02
#define	JOY_LEFT	0x04
#define	JOY_RIGHT	0x08
#define	JOY_TRG1	0x40
#define	JOY_TRG2	0x20
#define	JOY_TRG3	0x80
#define	JOY_TRG4	0x10


BOOL CALLBACK EnumButtonProc(LPCDIDEVICEOBJECTINSTANCE lpddoi, LPVOID pv)
{
	BYTE j = *(BYTE*)pv;
	if (joybtnnum[j]<MAX_BUTTON)
	{
		strcpy(joybtnname[j][joybtnnum[j]], lpddoi->tszName);
		joybtnnum[j]++;
		return DIENUM_CONTINUE;
	}
	else
		return DIENUM_STOP;
}
 

BOOL CALLBACK JoyEnumProc(LPDIDEVICEINSTANCE pdidi, LPVOID pv)
{
	GUID *guid = NULL;
	LPDIRECTINPUTDEVICE tmpdev = NULL;

	guid = (GUID *)pv;
	*guid = pdidi->guidInstance;

	if (!joy[0])
	{
		if ((IDirectInput_CreateDevice(dinput, guid, &tmpdev, NULL)) == DI_OK)
		{
			if ((IDirectInputDevice_QueryInterface(tmpdev, &IID_IDirectInputDevice2, &joy[0])) == DI_OK)
			{
				IDirectInputDevice_Release(tmpdev);
				return DIENUM_CONTINUE;
			}
			else
			{
				joy[0] = NULL;
				return DIENUM_CONTINUE;
			}
		}
		else
		{
			joy[0] = NULL;
			return DIENUM_CONTINUE;
		}
	}
	if (!joy[1])
	{
		if ((IDirectInput_CreateDevice(dinput, guid, &tmpdev, NULL)) == DI_OK)
		{
			if ((IDirectInputDevice_QueryInterface(tmpdev, &IID_IDirectInputDevice2, &joy[1])) == DI_OK)
			{
				IDirectInputDevice_Release(tmpdev);
				return DIENUM_STOP;
			}
			else
			{
				joy[1] = NULL;
				return DIENUM_CONTINUE;
			}
		}
		else
		{
			joy[1] = NULL;
			return DIENUM_CONTINUE;
		}
	}
	return DIENUM_CONTINUE;
}


void Joystick_Init(void)
{
	BYTE jnum;
	HRESULT	hres;
	GUID guid;
	DIPROPRANGE diprg;
	DIDEVICEINSTANCE dev;

	if (FAILED(DirectInputCreate(hInst, DIRECTINPUT_VERSION, &dinput, NULL))) {
		return;
	}

	IDirectInput_EnumDevices(dinput, DIDEVTYPE_JOYSTICK,
					(LPDIENUMDEVICESCALLBACK)JoyEnumProc,
					&guid, DIEDFL_ATTACHEDONLY);

	if ((joy[0] != NULL) && (SUCCEEDED(IDirectInputDevice2_SetDataFormat(joy[0], &c_dfDIJoystick))))
	{
		hres = IDirectInputDevice2_SetCooperativeLevel(joy[0], hWndMain,
						DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
		if (SUCCEEDED(hres)) {
			ZeroMemory(&diprg, sizeof(diprg));
			diprg.diph.dwSize = sizeof(diprg);
			diprg.diph.dwHeaderSize	= sizeof(diprg.diph);
			diprg.diph.dwObj = DIJOFS_X;
			diprg.diph.dwHow = DIPH_BYOFFSET;
			diprg.lMin = -1000;
			diprg.lMax = 1000;
			IDirectInputDevice2_SetProperty(joy[0], DIPROP_RANGE, &diprg.diph);
			diprg.diph.dwObj = DIJOFS_Y;
			IDirectInputDevice2_SetProperty(joy[0], DIPROP_RANGE, &diprg.diph);
			IDirectInputDevice2_Acquire(joy[0]);

			ZeroMemory(&dev, sizeof(DIDEVICEINSTANCE));
			dev.dwSize = sizeof(DIDEVICEINSTANCE);
			if (IDirectInputDevice2_GetDeviceInfo(joy[0], &dev) == DI_OK)
				strcpy(joyname[0], dev.tszProductName);
			else
				strcpy(joyname[0], "�s���ȃf�o�C�X");

			joybtnnum[0] = 0;
			jnum = 0;
			IDirectInputDevice_EnumObjects(joy[0],
						(LPDIENUMDEVICEOBJECTSCALLBACK)EnumButtonProc,
						&jnum, DIDFT_BUTTON);
		}
	}
	if ((joy[1] != NULL) && (SUCCEEDED(IDirectInputDevice2_SetDataFormat(joy[1], &c_dfDIJoystick))))
	{
		hres = IDirectInputDevice2_SetCooperativeLevel(joy[1], hWndMain,
						DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
		if (SUCCEEDED(hres)) {
			ZeroMemory(&diprg, sizeof(diprg));
			diprg.diph.dwSize = sizeof(diprg);
			diprg.diph.dwHeaderSize	= sizeof(diprg.diph);
			diprg.diph.dwObj = DIJOFS_X;
			diprg.diph.dwHow = DIPH_BYOFFSET;
			diprg.lMin = -1000;
			diprg.lMax = 1000;
			IDirectInputDevice2_SetProperty(joy[1], DIPROP_RANGE, &diprg.diph);
			diprg.diph.dwObj = DIJOFS_Y;
			IDirectInputDevice2_SetProperty(joy[1], DIPROP_RANGE, &diprg.diph);
			IDirectInputDevice2_Acquire(joy[1]);
		}

			ZeroMemory(&dev, sizeof(DIDEVICEINSTANCE));
			dev.dwSize = sizeof(DIDEVICEINSTANCE);
			if (IDirectInputDevice2_GetDeviceInfo(joy[1], &dev) == DI_OK)
				strcpy(joyname[1], dev.tszProductName);
			else
				strcpy(joyname[1], "�s���ȃf�o�C�X");

			joybtnnum[1] = 0;
			jnum = 1;
			IDirectInputDevice_EnumObjects(joy[1],
						(LPDIENUMDEVICEOBJECTSCALLBACK)EnumButtonProc,
						&jnum, DIDFT_BUTTON);
	}
}

void Joystick_Cleanup(void)
{
	if (joy[0]) IDirectInputDevice2_Release(joy[0]);
	if (joy[1]) IDirectInputDevice2_Release(joy[1]);
	if (dinput) IDirectInput_Release(dinput);
}


void Joystick_Activate(UINT wParam)
{
	if (wParam != WA_INACTIVE)
	{
		if (joy[0]) IDirectInputDevice2_Acquire(joy[0]);
		if (joy[1]) IDirectInputDevice2_Acquire(joy[1]);
	}
	else
	{
		if (joy[0]) IDirectInputDevice2_Unacquire(joy[0]);
		if (joy[1]) IDirectInputDevice2_Unacquire(joy[1]);
	}
}


BYTE FASTCALL Joystick_Read(BYTE num)
{
	BYTE ret;
	HRESULT hres;
	DIJOYSTATE state;

	ret = 0xff;

	if (joy[num])
	{
		IDirectInputDevice2_Poll(joy[num]);
		hres = IDirectInputDevice2_GetDeviceState(joy[num], sizeof(DIJOYSTATE), &state);
		if (SUCCEEDED(hres))
		{
			if (state.lX < -500)
				ret ^= JOY_LEFT;
			else if (state.lX > 500)
				ret ^= JOY_RIGHT;

			if (state.lY < -500)
				ret ^= JOY_UP;
			else if (state.lY > 500)
				ret ^= JOY_DOWN;

			if (Config_JOY_BTN[num][0]<joybtnnum[num])
				if (state.rgbButtons[Config_JOY_BTN[num][0]] & 0x80)
					ret ^= JOY_TRG1;
			if (Config_JOY_BTN[num][1]<joybtnnum[num])
				if (state.rgbButtons[Config_JOY_BTN[num][1]] & 0x80)
					ret ^= JOY_TRG2;
			if (Config_JOY_BTN[num][2]<joybtnnum[num])
				if (state.rgbButtons[Config_JOY_BTN[num][2]] & 0x80)
					ret ^= JOY_TRG3;
			if (Config_JOY_BTN[num][3]<joybtnnum[num])
				if (state.rgbButtons[Config_JOY_BTN[num][3]] & 0x80)
					ret ^= JOY_TRG4;
		}
		else if (hres == DIERR_INPUTLOST)
			IDirectInputDevice2_Acquire(joy[num]);
	}
	return ret;
}
