// ---------------------------------------------------------------------------------------
//  ABOUT.C - ABOUT�_�C�A���O
// ---------------------------------------------------------------------------------------
#include	<windows.h>
#include	<windowsx.h>
#include	<shlobj.h>
#include	"common.h"
#include	"resource.h"
#include	"version.h"

LRESULT CALLBACK AboutDialogProc(HWND hdlg, UINT msg, WPARAM wp, LPARAM lp)
{
	char buf[4096];
	
	switch (msg)
	{
	case WM_INITDIALOG:
		wsprintf(buf, "WinX1 - SHARP X1 emulator\n"
					  "Version " APP_VER_STRING "\n"
					  "Copyright (C) 1999, 2000 Kenjo\n");
	
		SetDlgItemText(hdlg, IDC_ABOUT_TEXT, buf);
//		wsprintf(buf, abouttext);
//		SetDlgItemText(hdlg, IDC_ABOUT_BOX, buf);

		SetFocus(GetDlgItem(hdlg, IDOK));
		return 0;

	case WM_COMMAND:
		if (IDOK == LOWORD(wp))
		{
			EndDialog(hdlg, TRUE);
			break;
		}
		return TRUE;

	case WM_CLOSE:
		EndDialog(hdlg, FALSE);
		return TRUE;

	default:
		return FALSE;
	}
	return FALSE;
}
