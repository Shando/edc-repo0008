// ---------------------------------------------------------------------------------------
//  PROP.C - �e��ݒ�p�v���p�e�B�V�[�g�Ɛݒ�l�Ǘ�
//  ini�t�@�C����Xmil�Ƌ��ʂɂ��悤���Ǝv�����񂾂��ǁA���ƕς��Ă���܂� ^^;�B
// ---------------------------------------------------------------------------------------

#include "..\win32\common.h"
#include <commctrl.h>
#include <commdlg.h>
#include <dinput.h>
#include "..\win32\common.h"
#include "..\win32\resource.h"
#include "..\win32\winx1.h"

BYTE Config_ROM_TYPE;
BYTE Config_SKIP_LINE;
DWORD Config_SampleRate;
DWORD Config_BufferSize;
BYTE Config_FrameNum;
BYTE Config_OPM_SW;
BYTE Config_DIP_SW;
WORD Config_WinPosX;
WORD Config_WinPosY;
BYTE Config_DSAlert;
BYTE Config_FDD_LED_SW;
BYTE Config_OPM_VOL;
BYTE Config_PSG_VOL;
BYTE Config_JOY_BTN[2][4];

BYTE ini_title[] = "WinX1";

BYTE Bk_ROM_TYPE;
BYTE Bk_SKIP_LINE;
DWORD Bk_SampleRate;
DWORD Bk_BufferSize;
BYTE Bk_FrameNum;
BYTE Bk_OPM_SW;
BYTE Bk_DIP_SW;
BYTE Bk_DSAlert;
BYTE Bk_FDD_LED;
BYTE Bk_OPM_VOL;
BYTE Bk_PSG_VOL;
BYTE Bk_JOY_BTN[2][4];

#ifndef MAX_BUTTON
#define MAX_BUTTON 32
#endif

extern char filepath[MAX_PATH];
extern char winx1ini[MAX_PATH];
extern int winx, winy;
extern BYTE HasX1IPL, HasTurboIPL;
extern LPDIRECTINPUTDEVICE2 joy[2];
extern char joyname[2][MAX_PATH];
extern char joybtnname[2][MAX_BUTTON][MAX_PATH];
extern BYTE joybtnnum[2];

#define CFGLEN 50
#define BSTATE(b) (b ? BST_CHECKED : BST_UNCHECKED)

static long solveHEX(char *str) {

	long	ret;
	int		i;
	char	c;

	ret = 0;
	for (i=0; i<8; i++) {
		c = *str++;
		if ((c >= '0') && (c <= '9')) {
			c -= '0';
		}
		else if ((c >= 'A') && (c <= 'F')) {
			c -= '7';
		}
		else if ((c >= 'a') && (c <= 'f')) {
			c -= 'W';
		}
		else {
			break;
		}
		ret <<= 4;
		ret += (long) c;
	}
	return(ret);
}

static char *makeBOOL(BYTE value) {

	if (value) {
		return("true");
	}
	return("false");
}

static BYTE Aacmp(char *cmp, char *str) {

	char	p;

	while(*str) {
		p = *cmp++;
		if (!p) {
			break;
		}
		if (p >= 'a' && p <= 'z') {
			p -= 0x20;
		}
		if (p != *str++) {
			return(-1);
		}
	}
	return(0);
}

static BYTE solveBOOL(char *str) {

	if ((!Aacmp(str, "TRUE")) || (!Aacmp(str, "ON")) ||
		(!Aacmp(str, "+")) || (!Aacmp(str, "1")) ||
		(!Aacmp(str, "ENABLE"))) {
		return(1);
	}
	return(0);
}


void LoadConfig(void)
{
	int	i, j;
	char	buf[CFGLEN];

	winx = GetPrivateProfileInt(ini_title, "WinPosX", CW_USEDEFAULT, winx1ini);
	winy = GetPrivateProfileInt(ini_title, "WinPosY", CW_USEDEFAULT, winx1ini);
	GetPrivateProfileString(ini_title, "StartDir", "", buf, MAX_PATH, winx1ini);
	if (buf[0] != 0)
		strcpy(filepath, buf);
	else
		filepath[0] = 0;

	GetPrivateProfileString(ini_title, "OPM", "1", buf, CFGLEN, winx1ini);
	Config_OPM_SW = solveBOOL(buf);
	Config_OPM_VOL = GetPrivateProfileInt(ini_title, "OPM_Volume", 12, winx1ini);
	Config_PSG_VOL = GetPrivateProfileInt(ini_title, "PSG_Volume", 10, winx1ini);
	Config_SampleRate = GetPrivateProfileInt(ini_title, "SampleRate", 22050, winx1ini);
	Config_BufferSize = GetPrivateProfileInt(ini_title, "BufferSize", 50, winx1ini);
	GetPrivateProfileString(ini_title, "DSFailAlert", "1", buf, CFGLEN, winx1ini);
	Config_DSAlert = solveBOOL(buf);

	GetPrivateProfileString(ini_title, "SkipLine", "1", buf, CFGLEN, winx1ini);
	Config_SKIP_LINE = solveBOOL(buf);
	Config_FrameNum = GetPrivateProfileInt(ini_title, "FrameNum", 60, winx1ini);
	GetPrivateProfileString(ini_title, "FDD_LED", "1", buf, CFGLEN, winx1ini);
	Config_FDD_LED_SW = solveBOOL(buf);

	GetPrivateProfileString(ini_title, "DIP_SW", "0", buf, CFGLEN, winx1ini);
	Config_DIP_SW = (BYTE)solveHEX(buf);
	Config_ROM_TYPE = GetPrivateProfileInt(ini_title, "IPL_TYPE", 1, winx1ini);

	for (i=0; i<2; i++)
	{
		for (j=0; j<4; j++)
		{
			sprintf(buf, "Joy%dButton%d", i+1, j+1);
			Config_JOY_BTN[i][j] = GetPrivateProfileInt(ini_title, buf, j, winx1ini);
		}
	}
}


void SaveConfig(void)
{
	int	i, j;
	char	buf[CFGLEN], buf2[CFGLEN];

	wsprintf(buf, "%d", winx);
	WritePrivateProfileString(ini_title, "WinPosX", buf, winx1ini);
	wsprintf(buf, "%d", winy);
	WritePrivateProfileString(ini_title, "WinPosY", buf, winx1ini);
	WritePrivateProfileString(ini_title, "StartDir", filepath, winx1ini);

	WritePrivateProfileString(ini_title, "OPM", makeBOOL(Config_OPM_SW), winx1ini);
	wsprintf(buf, "%d", Config_OPM_VOL);
	WritePrivateProfileString(ini_title, "OPM_Volume", buf, winx1ini);
	wsprintf(buf, "%d", Config_PSG_VOL);
	WritePrivateProfileString(ini_title, "PSG_Volume", buf, winx1ini);
	wsprintf(buf, "%d", Config_SampleRate);
	WritePrivateProfileString(ini_title, "SampleRate", buf, winx1ini);
	wsprintf(buf, "%d", Config_BufferSize);
	WritePrivateProfileString(ini_title, "BufferSize", buf, winx1ini);
	WritePrivateProfileString(ini_title, "DSFailAlert", makeBOOL(Config_DSAlert), winx1ini);

	WritePrivateProfileString(ini_title, "SkipLine", makeBOOL(Config_SKIP_LINE), winx1ini);
	wsprintf(buf, "%d", Config_FrameNum);
	WritePrivateProfileString(ini_title, "FrameNum", buf, winx1ini);
	WritePrivateProfileString(ini_title, "FDD_LED", makeBOOL(Config_FDD_LED_SW), winx1ini);

	wsprintf(buf, "%02X", Config_DIP_SW);
	WritePrivateProfileString(ini_title, "DIP_SW", buf, winx1ini);
	wsprintf(buf, "%d", Config_ROM_TYPE);
	WritePrivateProfileString(ini_title, "IPL_TYPE", buf, winx1ini);

	for (i=0; i<2; i++)
	{
		for (j=0; j<4; j++)
		{
			sprintf(buf, "Joy%dButton%d", i+1, j+1);
			wsprintf(buf2, "%d", Config_JOY_BTN[i][j]);
			WritePrivateProfileString(ini_title, buf, buf2, winx1ini);
		}
	}
}


static LRESULT CALLBACK PropDialogProc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam);
void PropPage_Init(void);

extern HINSTANCE hInst;
extern HWND hWndMain;

#define NUM_PROPSHEETS  4

static DWORD dwDlgId[] = {
	IDD_PROP_DISP,
	IDD_PROP_SOUND,
	IDD_PROP_X1,
	IDD_PROP_JOYSTICK,
};

void PropPage_Init(void)
{
	PROPSHEETPAGE	pspage[NUM_PROPSHEETS];
	PROPSHEETHEADER	pshead;
	int i;

	pshead.hwndParent     = hWndMain;
	pshead.dwSize         = sizeof(PROPSHEETHEADER);
	pshead.dwFlags        = PSH_PROPSHEETPAGE | PSH_USEICONID ;
	pshead.hInstance      = hInst;
	pshead.pszCaption     = "WinX1 Config";
	pshead.nPages         = NUM_PROPSHEETS;
	pshead.nStartPage     = 0;
	pshead.pszIcon        = MAKEINTRESOURCE(IDI_MAIN_ICON);
	pshead.ppsp           = pspage;

	for (i = 0; i < NUM_PROPSHEETS; i++)
	{
		pspage[i].dwSize      = sizeof(PROPSHEETPAGE);
		pspage[i].dwFlags     = 0;
		pspage[i].hInstance   = hInst;
		pspage[i].pszTemplate = MAKEINTRESOURCE(dwDlgId[i]);
		pspage[i].pfnCallback = NULL;
		pspage[i].lParam      = 0;
		pspage[i].pfnDlgProc  = PropDialogProc;
	}

	if (PropertySheet(&pshead) == -1)
		Error("�v���p�e�B�V�[�g�̍쐬�Ɏ��s���܂����B");
}


void Setup_JoystickPage(HWND hDlg)
{
	int i;
	char *nobutton="�Ȃ�";

	if (joy[0])
	{
		SetDlgItemText(hDlg, IDC_JOY1_NAME, joyname[0]);

		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN1), TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN2), TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN3), TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN4), TRUE);

		SendDlgItemMessage(hDlg, IDC_JOY1_BTN1, CB_ADDSTRING, 0, (long)nobutton);
		SendDlgItemMessage(hDlg, IDC_JOY1_BTN2, CB_ADDSTRING, 0, (long)nobutton);
		SendDlgItemMessage(hDlg, IDC_JOY1_BTN3, CB_ADDSTRING, 0, (long)nobutton);
		SendDlgItemMessage(hDlg, IDC_JOY1_BTN4, CB_ADDSTRING, 0, (long)nobutton);
		for (i=0; i<joybtnnum[0]; i++)
		{
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN1, CB_ADDSTRING, 0, (long)joybtnname[0][i]);
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN2, CB_ADDSTRING, 0, (long)joybtnname[0][i]);
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN3, CB_ADDSTRING, 0, (long)joybtnname[0][i]);
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN4, CB_ADDSTRING, 0, (long)joybtnname[0][i]);
		}
		if (Config_JOY_BTN[0][0]<joybtnnum[0])
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN1, CB_SELECTSTRING, 0, (long)joybtnname[0][Config_JOY_BTN[0][0]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN1, CB_SELECTSTRING, 0, (long)nobutton);
		if (Config_JOY_BTN[0][1]<joybtnnum[0])
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN2, CB_SELECTSTRING, 0, (long)joybtnname[0][Config_JOY_BTN[0][1]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN2, CB_SELECTSTRING, 0, (long)nobutton);
		if (Config_JOY_BTN[0][2]<joybtnnum[0])
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN3, CB_SELECTSTRING, 0, (long)joybtnname[0][Config_JOY_BTN[0][2]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN3, CB_SELECTSTRING, 0, (long)nobutton);
		if (Config_JOY_BTN[0][3]<joybtnnum[0])
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN4, CB_SELECTSTRING, 0, (long)joybtnname[0][Config_JOY_BTN[0][3]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY1_BTN4, CB_SELECTSTRING, 0, (long)nobutton);
	}
	else
	{
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN1), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN2), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN3), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY1_BTN4), FALSE);
	}

	if (joy[1])
	{
		SetDlgItemText(hDlg, IDC_JOY2_NAME, joyname[1]);

		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN1), TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN2), TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN3), TRUE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN4), TRUE);

		SendDlgItemMessage(hDlg, IDC_JOY2_BTN1, CB_ADDSTRING, 0, (long)nobutton);
		SendDlgItemMessage(hDlg, IDC_JOY2_BTN2, CB_ADDSTRING, 0, (long)nobutton);
		SendDlgItemMessage(hDlg, IDC_JOY2_BTN3, CB_ADDSTRING, 0, (long)nobutton);
		SendDlgItemMessage(hDlg, IDC_JOY2_BTN4, CB_ADDSTRING, 0, (long)nobutton);
		for (i=0; i<joybtnnum[1]; i++)
		{
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN1, CB_ADDSTRING, 0, (long)joybtnname[1][i]);
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN2, CB_ADDSTRING, 0, (long)joybtnname[1][i]);
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN3, CB_ADDSTRING, 0, (long)joybtnname[1][i]);
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN4, CB_ADDSTRING, 0, (long)joybtnname[1][i]);
		}
		if (Config_JOY_BTN[1][0]<joybtnnum[1])
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN1, CB_SELECTSTRING, 0, (long)joybtnname[1][Config_JOY_BTN[1][0]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN1, CB_SELECTSTRING, 0, (long)nobutton);
		if (Config_JOY_BTN[1][1]<joybtnnum[1])
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN2, CB_SELECTSTRING, 0, (long)joybtnname[1][Config_JOY_BTN[1][1]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN2, CB_SELECTSTRING, 0, (long)nobutton);
		if (Config_JOY_BTN[1][2]<joybtnnum[1])
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN3, CB_SELECTSTRING, 0, (long)joybtnname[1][Config_JOY_BTN[1][2]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN3, CB_SELECTSTRING, 0, (long)nobutton);
		if (Config_JOY_BTN[1][3]<joybtnnum[1])
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN4, CB_SELECTSTRING, 0, (long)joybtnname[1][Config_JOY_BTN[1][3]]);
		else
			SendDlgItemMessage(hDlg, IDC_JOY2_BTN4, CB_SELECTSTRING, 0, (long)nobutton);
	}
	else
	{
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN1), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN2), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN3), FALSE);
		EnableWindow(GetDlgItem(hDlg, IDC_JOY2_BTN4), FALSE);
	}
}


static LRESULT CALLBACK PropDialogProc(HWND hDlg, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	char buf[255];
	int temp;
	int i, j;

	switch (Msg)
	{
	case WM_INITDIALOG:
		{
			HWND hWnd = PropSheet_GetTabControl(GetParent(hDlg));
			DWORD tabStyle = (GetWindowLong(hWnd,GWL_STYLE) & ~TCS_MULTILINE);
			SetWindowLong(hWnd,GWL_STYLE,tabStyle | TCS_SINGLELINE);

			Bk_ROM_TYPE	= Config_ROM_TYPE;
			Bk_SKIP_LINE	= Config_SKIP_LINE;
			Bk_SampleRate	= Config_SampleRate;
			Bk_BufferSize	= Config_BufferSize;
			Bk_FrameNum	= Config_FrameNum;
			Bk_OPM_SW	= Config_OPM_SW;
			Bk_OPM_VOL	= Config_OPM_VOL;
			Bk_PSG_VOL	= Config_PSG_VOL;
			Bk_DIP_SW	= Config_DIP_SW;
			Bk_FDD_LED	= Config_FDD_LED_SW;
			Bk_DSAlert	= Config_DSAlert;
			for (i=0; i<2; i++)
				for (j=0; j<4; j++)
					Bk_JOY_BTN[i][j] = Config_JOY_BTN[i][j];


			CheckDlgButton(hDlg, IDC_FRAME_FULL, BSTATE((Config_FrameNum==60)));
			CheckDlgButton(hDlg, IDC_FRAME_30  , BSTATE((Config_FrameNum==30)));
			CheckDlgButton(hDlg, IDC_FRAME_20  , BSTATE((Config_FrameNum==20)));
			CheckDlgButton(hDlg, IDC_FRAME_15  , BSTATE((Config_FrameNum==15)));
			CheckDlgButton(hDlg, IDC_FRAME_10  , BSTATE((Config_FrameNum==10)));
			CheckDlgButton(hDlg, IDC_FRAME_5   , BSTATE((Config_FrameNum==5)));

			CheckDlgButton(hDlg, IDC_SKIP_ON   , BSTATE(Config_SKIP_LINE));
			CheckDlgButton(hDlg, IDC_SKIP_OFF  , BSTATE(!Config_SKIP_LINE));

			CheckDlgButton(hDlg, IDC_FDD_LED, BSTATE(Config_FDD_LED_SW));

			CheckDlgButton(hDlg, IDC_RATE_NON, BSTATE((Config_SampleRate==0)));
			CheckDlgButton(hDlg, IDC_RATE_44,  BSTATE((Config_SampleRate==44100)));
			CheckDlgButton(hDlg, IDC_RATE_22,  BSTATE((Config_SampleRate==22050)));
			CheckDlgButton(hDlg, IDC_RATE_11,  BSTATE((Config_SampleRate==11025)));

			CheckDlgButton(hDlg, IDC_DEVICE_OPM, BSTATE(Config_OPM_SW));
			SendDlgItemMessage(hDlg, IDC_OPMVOL, TBM_SETRANGE, TRUE, MAKELONG(0, 16));
			SendDlgItemMessage(hDlg, IDC_OPMVOL, TBM_SETPOS, TRUE, Config_OPM_VOL);
			SetDlgItemInt(hDlg, IDC_OPMVOL_TEXT, Config_OPM_VOL, FALSE);
			SendDlgItemMessage(hDlg, IDC_PSGVOL, TBM_SETRANGE, TRUE, MAKELONG(0, 16));
			SendDlgItemMessage(hDlg, IDC_PSGVOL, TBM_SETPOS, TRUE, Config_PSG_VOL);
			SetDlgItemInt(hDlg, IDC_PSGVOL_TEXT, Config_PSG_VOL, FALSE);
			SendDlgItemMessage(hDlg, IDC_BUFSIZE, TBM_SETRANGE, TRUE, MAKELONG(10, 200));
			SendDlgItemMessage(hDlg, IDC_BUFSIZE, TBM_SETPOS, TRUE, Config_BufferSize);
			SetDlgItemInt(hDlg, IDC_BUFSIZE_TEXT, Config_BufferSize, FALSE);
			EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE), (Config_SampleRate!=0));
			EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE_TEXT), (Config_SampleRate!=0));
			CheckDlgButton(hDlg, IDC_DSALERT, BSTATE(Config_DSAlert));


			EnableWindow(GetDlgItem(hDlg, IDC_IPL_X1), HasX1IPL);
			EnableWindow(GetDlgItem(hDlg, IDC_IPL_TURBO), HasTurboIPL);
			CheckDlgButton(hDlg, IDC_IPL_X1,    BSTATE((Config_ROM_TYPE==1)));
			CheckDlgButton(hDlg, IDC_IPL_TURBO, BSTATE((Config_ROM_TYPE==2)));

			CheckDlgButton(hDlg, IDC_SCREEN_NORMAL,   BSTATE((Config_DIP_SW&1)));
			CheckDlgButton(hDlg, IDC_SCREEN_HIGHRESO, BSTATE(!(Config_DIP_SW&1)));

			Setup_JoystickPage(hDlg);
		}

		ShowWindow(hDlg,SW_SHOW);
		return 1;

	case WM_COMMAND:
		if (HIWORD(wParam) == BN_CLICKED)
		{
			switch (LOWORD(wParam))
			{
			case IDC_FRAME_FULL:
				Config_FrameNum=60; return 1;
			case IDC_FRAME_30:
				Config_FrameNum=30; return 1;
			case IDC_FRAME_20:
				Config_FrameNum=20; return 1;
			case IDC_FRAME_15:
				Config_FrameNum=15; return 1;
			case IDC_FRAME_10:
				Config_FrameNum=10; return 1;
			case IDC_FRAME_5:
				Config_FrameNum=5; return 1;

			case IDC_SKIP_ON:
				Config_SKIP_LINE=1; return 1;
			case IDC_SKIP_OFF:
				Config_SKIP_LINE=0; return 1;

			case IDC_RATE_NON:
				Config_SampleRate=0; 
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE_TEXT), FALSE);
				return 1;
			case IDC_RATE_44:
				Config_SampleRate=44100;
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE_TEXT), TRUE);
				return 1;
			case IDC_RATE_22:
				Config_SampleRate=22050;
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE_TEXT), TRUE);
				return 1;
			case IDC_RATE_11:
				Config_SampleRate=11025;
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_BUFSIZE_TEXT), TRUE);
				return 1;

			case IDC_DEVICE_OPM:
				Config_OPM_SW=(!(Config_OPM_SW));
				return 1;
			case IDC_DSALERT:
				Config_DSAlert=(!(Config_DSAlert));
				return 1;

			case IDC_FDD_LED:
				Config_FDD_LED_SW=(!(Config_FDD_LED_SW));
				return 1;

			case IDC_IPL_X1:
				Config_ROM_TYPE=1; return 1;
			case IDC_IPL_TURBO:
				Config_ROM_TYPE=2; return 1;

			case IDC_SCREEN_NORMAL:
				Config_DIP_SW|=1; return 1;
			case IDC_SCREEN_HIGHRESO:
				Config_DIP_SW&=0xfe; return 1;
			}
		} else {
			switch (LOWORD(wParam))
			{
			case IDC_JOY1_BTN1:
				temp = SendDlgItemMessage(hDlg, IDC_JOY1_BTN1, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[0][0] = temp-1;
				else Config_JOY_BTN[0][0] = MAX_BUTTON;
				return 1;
			case IDC_JOY1_BTN2:
				temp = SendDlgItemMessage(hDlg, IDC_JOY1_BTN2, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[0][1] = temp-1;
				else Config_JOY_BTN[0][1] = MAX_BUTTON;
				return 1;
			case IDC_JOY1_BTN3:
				temp = SendDlgItemMessage(hDlg, IDC_JOY1_BTN3, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[0][2] = temp-1;
				else Config_JOY_BTN[0][2] = MAX_BUTTON;
				return 1;
			case IDC_JOY1_BTN4:
				temp = SendDlgItemMessage(hDlg, IDC_JOY1_BTN4, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[0][3] = temp-1;
				else Config_JOY_BTN[0][3] = MAX_BUTTON;
				return 1;

			case IDC_JOY2_BTN1:
				temp = SendDlgItemMessage(hDlg, IDC_JOY2_BTN1, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[1][0] = temp-1;
				else Config_JOY_BTN[1][0] = MAX_BUTTON;
				return 1;
			case IDC_JOY2_BTN2:
				temp = SendDlgItemMessage(hDlg, IDC_JOY2_BTN2, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[1][1] = temp-1;
				else Config_JOY_BTN[1][1] = MAX_BUTTON;
				return 1;
			case IDC_JOY2_BTN3:
				temp = SendDlgItemMessage(hDlg, IDC_JOY2_BTN3, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[1][2] = temp-1;
				else Config_JOY_BTN[1][2] = MAX_BUTTON;
				return 1;
			case IDC_JOY2_BTN4:
				temp = SendDlgItemMessage(hDlg, IDC_JOY2_BTN4, CB_GETCURSEL, 0, 0);
				if (temp) Config_JOY_BTN[1][3] = temp-1;
				else Config_JOY_BTN[1][3] = MAX_BUTTON;
				return 1;
			}
		}
		return 0;

	case WM_HSCROLL:
		Config_BufferSize = SendDlgItemMessage(hDlg, IDC_BUFSIZE, TBM_GETPOS, 0, 0);
		wsprintf(buf, "%d", Config_BufferSize);
		SetDlgItemText(hDlg, IDC_BUFSIZE_TEXT, buf);

		Config_OPM_VOL = SendDlgItemMessage(hDlg, IDC_OPMVOL, TBM_GETPOS, 0, 0);
		wsprintf(buf, "%d", Config_OPM_VOL);
		SetDlgItemText(hDlg, IDC_OPMVOL_TEXT, buf);

		Config_PSG_VOL = SendDlgItemMessage(hDlg, IDC_PSGVOL, TBM_GETPOS, 0, 0);
		wsprintf(buf, "%d", Config_PSG_VOL);
		SetDlgItemText(hDlg, IDC_PSGVOL_TEXT, buf);
		return 1;

	case WM_NOTIFY:
		switch (((NMHDR*) lParam)->code)
		{
		case PSN_SETACTIVE:
			break;

		case PSN_APPLY:
			return PSNRET_NOERROR;
		
		case PSN_QUERYCANCEL:
			Config_ROM_TYPE =	Bk_ROM_TYPE;
			Config_SKIP_LINE =	Bk_SKIP_LINE;
			Config_SampleRate =	Bk_SampleRate;
			Config_BufferSize =	Bk_BufferSize;
			Config_FrameNum =	Bk_FrameNum;
			Config_OPM_SW =		Bk_OPM_SW;
			Config_OPM_VOL =	Bk_OPM_VOL;
			Config_PSG_VOL =	Bk_PSG_VOL;
			Config_DIP_SW =		Bk_DIP_SW;
			Config_DSAlert=		Bk_DSAlert;
			Config_FDD_LED_SW=	Bk_FDD_LED;
			for (i=0; i<2; i++)
				for (j=0; j<4; j++)
					Config_JOY_BTN[i][j] = Bk_JOY_BTN[i][j];
			return FALSE;		
		}
		return TRUE;

	}
	return 0;
}
