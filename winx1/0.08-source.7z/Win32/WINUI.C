// ---------------------------------------------------------------------------------------
//  WINUI.C - �f�B�X�N����ւ��Ƃ���UI�֘A
//  M88�������Ă��� ^^;
//  01/02/00  �L�[�{�[�hLED�ǉ�
// ---------------------------------------------------------------------------------------
#include "..\win32\common.h"
#include <string.h>
#include <mbstring.h>
#include "..\win32\resource.h"
#include "..\win32\winx1.h"
#include "..\win32\windraw.h"
#include "..\x1\fdc.h"
#include "..\x1\fdd88.h"
#include "..\x1\fdd2d.h"
#include "..\x1\z80.h"
#include "..\win32\about.h"

extern	D88_HEADER	d88head[4][D88_MAX_DISKS];	// �}���`�f�B�X�N�C���[�W�p
extern	FDC_REGS	FDC;
extern	BYTE		FDC_NAME[4][MAX_PATH];
extern	BYTE		WRITEPT[];
extern	BYTE		DISKNUM[];
extern	short		curdisk[4];			// �}���`�f�B�X�N�C���[�W�p
extern	short		maxdisk[4];			// �}���`�f�B�X�N�C���[�W�p
extern	DWORD		imagepos[4][D88_MAX_DISKS];	// �}���`�f�B�X�N�C���[�W�p

extern	int		winx, winy;
extern	WORD		fcount;
extern	DWORD		timericnt;
extern	unsigned int	timerid;
	DWORD		timertick=0;

	BYTE		fullscreen = FALSE;
	BYTE		MenuFlag = FALSE;

extern	BYTE		DS_UIMode;

char filepath[MAX_PATH];
BYTE BackupKeyState[256];

extern	HWND		hWndMain;
extern	HINSTANCE	hInst;

static HMENU	drvhmenu[4]={0, 0, 0, 0};

extern	BYTE Config_PSG_VOL;
extern	BYTE Config_OPM_VOL;
extern	void FASTCALL PSG_SetVolume(BYTE vol);
extern	void OPM_SetVolume(BYTE vol);

extern short TraceFlag;

void WinUI_GetFileNameTitle(char* title, const char* name)
{
	if (name)
	{
		char* ptr;
		ptr = _mbsrchr((char*) name, '\\');
		_mbscpy((char*) title,  ptr ? ptr+1 : (char*)(name));
		ptr = _mbschr((char*) title, '.');
		if (ptr)
			*ptr = 0;
	}
}


void WinUI_SelectDisk(short drive, short id, short menuonly)
{
	WORD menuid = (drive==0)?IDM_CHANGEDISK_1:IDM_CHANGEDISK_2;
	BYTE buf[MAX_PATH];

	if (drive >= 2 || id >= 64)
		return;

	CheckMenuItem(drvhmenu[drive], menuid+(curdisk[drive] < 0 ? 63 : curdisk[drive]),
		MF_BYCOMMAND | MF_UNCHECKED);
	if (!menuonly) {
		strncpy(buf, FDC_NAME[drive], MAX_PATH);
		x1_set_fd(drive, id, buf);
	}
	CheckMenuItem(drvhmenu[drive],
				  menuid+(curdisk[drive] < 0 ? 63 : curdisk[drive]),
				  MF_BYCOMMAND | MF_CHECKED);
}


void WinUI_CreateDiskMenu(short drive)
{
	char buf[MAX_PATH + 16];
	char titlebuf[17];
	char *title = titlebuf;
	MENUITEMINFO mii;
	WORD id = (drive==0)?IDM_CHANGEDISK_1:IDM_CHANGEDISK_2;
	
	HMENU hmenuprev = drvhmenu[drive];

	if (maxdisk[drive])
	{
		int i;
		drvhmenu[drive] = CreatePopupMenu();
		if (!drvhmenu[drive])
			return;
		
		for (i=0; i<maxdisk[drive]; i++)
		{
			if (DISKNUM[drive]==DRV_FMT88)
				title = d88head[drive][i].fd_name;
			else if (DISKNUM[drive]==DRV_FMT2D)
			{
				char buf2d[MAX_PATH];
				WinUI_GetFileNameTitle(buf2d, FDC_NAME[drive]);
				wsprintf(title, "<%s #%d>", buf2d, i+1);
			}
			if (!title[0])
				wsprintf(title, "<No Name #%d>", i+1);
			
			wsprintf(buf, i < 9 ? "&%d %.16s" : "%d %.16s", i+1, title);
			AppendMenu(drvhmenu[drive], MF_STRING, id+i, buf );
		}

		AppendMenu(drvhmenu[drive], MF_SEPARATOR, 0, 0);
		AppendMenu(drvhmenu[drive], MF_STRING, id + 63, "&N No disk");
		AppendMenu(drvhmenu[drive], MF_STRING, id + 64, "&0 Change disk");
		SetMenuDefaultItem(drvhmenu[drive], id + 64, FALSE );
	}

	memset(&mii, 0, sizeof(mii));
	mii.cbSize = sizeof(mii);
	mii.fType = MFT_STRING;
	mii.fMask = MIIM_TYPE | MIIM_SUBMENU;
	mii.dwTypeData = buf;

	if (!maxdisk[drive])
	{
		wsprintf(buf, "FDD &%d", drive);
		mii.hSubMenu = 0;
	}
	else
	{
		char title[MAX_PATH] = "";
		WinUI_GetFileNameTitle(title, FDC_NAME[drive]);
	
		wsprintf(buf, "FDD &%d - %s", drive, title);
		mii.hSubMenu = drvhmenu[drive];
	}
	SetMenuItemInfo(GetMenu(hWndMain), drive ? IDM_FDD1 : IDM_FDD0, FALSE, &mii);
	if (hmenuprev)
		DestroyMenu(hmenuprev);
	
	if (maxdisk[drive])
		WinUI_SelectDisk(drive, curdisk[drive], TRUE);
}


void WinUI_ChangeDiskImage(HWND hwnd, short drive)
{
	OPENFILENAME ofn;
	int	isopen;
	char filename[MAX_PATH];

	WinDraw_ShowMenu();
	DS_UIMode=TRUE;
	
	x1_eject_fd(drive, FALSE);

	memset(&ofn, 0, sizeof(ofn));
	filename[0] = 0;
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFilter = "X1 Disk Images (*.2d/*.d88)\0*.2d;*.d88\0"
					  "All Files (*.*)\0*.*\0";
	ofn.lpstrFile = filename;
	ofn.lpstrInitialDir = filepath;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = OFN_CREATEPROMPT | OFN_SHAREAWARE;
	ofn.lpstrDefExt = "d88";
	ofn.lpstrTitle = "X1�f�B�X�N�C���[�W�̑I��";
	
//	EnableIME(hwnd, true);
	isopen = !!GetOpenFileName(&ofn);
//	EnableIME(hwnd, false);

	if (isopen)
	{
		short createnew = FALSE;

		strncpy(filepath, filename, MAX_PATH);
		filepath[ofn.nFileOffset] = 0;
/*		// �w�肳�ꂽ�t�@�C���͑��݂��邩�H
		if (!diskmgr->IsImageOpen(filename))
		{
			FileIO file;
			if (!file.Open(filename, FileIO::readonly))
			{
				if (file.GetError() == FileIO::file_not_found)
				{
					// �t�@�C�������݂��Ȃ�
					createnew = TRUE;
					if (!newdisk.Show(hinst, hwnd))
						return;
				}
				else
				{
					// ���炩�̗��R�ŃA�N�Z�X�ł��Ȃ�
					return;
				}
			}
		}
*/
		x1_set_fd(drive, 0, filename);
		WinUI_CreateDiskMenu(drive);
/*		if (createnew && diskmgr->GetNumDisks(drive) == 0)
		{
			diskmgr->AddDisk(drive, newdisk.GetTitle(), newdisk.GetType());
			OpenDiskImage(drive, filename, 0, 0, false);
			if (newdisk.DoFormat())
				diskmgr->FormatDisk(drive);
		}
*/
		if (drive == 0 && !FDC_NAME[1][0] && maxdisk[0] > 1)
		{
			x1_set_fd(1, 1, filename);
			WinUI_CreateDiskMenu(1);
		}

	}
	else
		WinUI_CreateDiskMenu(drive);

	DS_UIMode=FALSE;
	WinDraw_HideMenu();
//	SetThreadPriority(hthread, prev);
//	snapshotchanged = true;
}


void WinUI_CapsLED(BYTE flag)
{
	BYTE keys[256];

	GetKeyboardState((LPBYTE)&keys);
	if ((flag&&!(keys[VK_CAPITAL]&1)) || (!flag&&(keys[VK_CAPITAL]&1)))
	{
		keybd_event(VK_CAPITAL, 0x45, KEYEVENTF_EXTENDEDKEY, 0);
		keybd_event(VK_CAPITAL, 0x45, KEYEVENTF_EXTENDEDKEY|KEYEVENTF_KEYUP, 0);
	}
}

void WinUI_ScrollLED(BYTE flag)
{
	BYTE keys[256];

	GetKeyboardState((LPBYTE)&keys);
	if ((flag&&!(keys[VK_SCROLL]&1)) || (!flag&&(keys[VK_SCROLL]&1)))
	{
		keybd_event(VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY, 0);
		keybd_event(VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY|KEYEVENTF_KEYUP, 0);
	}
}

// --------------------------------------------------------------------------
//   �ӂ邷����[��
// --------------------------------------------------------------------------
void ChangeFullScreen(int sw) 
{
	WinDraw_Cleanup();

	WinDraw_ChangeMode(sw);
	if (!WinDraw_Init()) {
		Error("��ʃ��[�h�؂�ւ��Ɏ��s���܂����B");
		PostQuitMessage(0);
	}
	else {
		WinDraw_Redraw();
		WinDraw_Draws();
		WinDraw_DrawAll();
		ShowCursor(!sw);
	}
}

// --------------------------------------------------------------------------
//   �^�C�g���o�[���������p�^�C�}�[
// --------------------------------------------------------------------------
short WmTimer(HWND hwnd, WPARAM wparam, LPARAM lparam)
{
	if (wparam == timerid)
	{
		if (!fullscreen)
		{
			char buf[64];
			DWORD timernowtick = GetTickCount();
			unsigned int freq = timericnt/(timernowtick-timertick);
			timertick = timernowtick;
//			wsprintf(buf, "WinX1 - %d fps / %d.%.3d MHz",
//				fcount, (unsigned int)(freq / 1000), (unsigned int)(freq % 1000));
			wsprintf(buf, "WinX1 - %d fps / %d.%.3d MHz  PC:%04X",
				fcount, (unsigned int)(freq / 1000), (unsigned int)(freq % 1000), (R.PC.W&0xffff));
			fcount = 0;
			timericnt = 0;
			SetWindowText(hwnd, buf);
		}
		else
			SetWindowText(hwnd, "WinX1");
		}
	return 0;
}

// --------------------------------------------------------------------------
//   ���j���[�Ƃ��̏���
// --------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {

	RECT		rc;
	PAINTSTRUCT	ps;
	unsigned short wid = LOWORD(wParam);
	char buf[50];

	switch (msg) {
		case WM_COMMAND:
			switch(LOWORD(wid)) {
				case IDM_CONFIG:
					WinDraw_ShowMenu();
					DS_UIMode=TRUE;
					PropPage_Init();
					DS_UIMode=FALSE;
					PSG_SetVolume(Config_PSG_VOL);
					OPM_SetVolume(Config_OPM_VOL);
					WinDraw_HideMenu();
					break;
				case IDM_X1RESET:
					X1_Reset();
					break;
				case IDM_X1NMI:
					Z80_NonMaskedInterrupt();
					break;
				case IDM_EXIT:
					SendMessage(hWnd, WM_CLOSE, 0, 0L);
					break;
				case IDM_FDD0:
				case IDM_CHANGEIMAGE_1:
					WinUI_ChangeDiskImage(hWnd, 0);
					break;
				case IDM_FDD1:
				case IDM_CHANGEIMAGE_2:
					WinUI_ChangeDiskImage(hWnd, 1);
					break;
				case IDM_BOTHDRIVE:
					x1_eject_fd(1, TRUE);
					WinUI_CreateDiskMenu(1);
					WinUI_ChangeDiskImage(hWnd, 0);
					break;

				case IDM_TOGGLEFULLSCREEN:
					if (fullscreen) {
						ChangeFullScreen(FALSE);
					} else
						ChangeFullScreen(TRUE);
					break;

				case IDM_ABOUT:
					WinDraw_ShowMenu();
					DS_UIMode=TRUE;
					DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUT),
									hWnd, (DLGPROC)AboutDialogProc);
					DS_UIMode=FALSE;
					WinDraw_HideMenu();
					break;


				case IDM_TRACE:
					TraceFlag ^= 1;
					break;

				default:
					if (IDM_CHANGEDISK_1 <= wid && wid < IDM_CHANGEDISK_1 + 64)
					{
						WinUI_SelectDisk(0, (short)(wid-IDM_CHANGEDISK_1), FALSE);
						break;
					}
					if (IDM_CHANGEDISK_2 <= wid && wid < IDM_CHANGEDISK_2 + 64)
					{
						WinUI_SelectDisk(1, (short)(wid-IDM_CHANGEDISK_2), FALSE);
						break;
					}
			}
			break;

		case WM_ACTIVATE:
			Joystick_Activate(wParam);
			if (!HIWORD(wParam)) {
				WinDraw_DrawAll();
			}
			break;

		case WM_PAINT:
			BeginPaint(hWnd, &ps);
			WinDraw_DrawAll();
			EndPaint(hWnd, &ps);
			break;

		case WM_QUERYNEWPALETTE:
			WinDraw_Palette();
			break;

		case WM_MOVE:
			if (!fullscreen) {
				GetWindowRect(hWnd, &rc);
				winx = rc.left;
				winy = rc.top;
			}
			break;

		case WM_ENTERMENULOOP:
			MenuFlag=TRUE;
			DS_UIMode=TRUE;
			if ((fullscreen) && (!wParam))
			{
				WinDraw_ShowMenu();
				DrawMenuBar(hWnd);
			}
			break;
		case WM_EXITMENULOOP:
			MenuFlag=FALSE;
			DS_UIMode=FALSE;
			Timer_Reset();
			if ((fullscreen) && (!wParam))
			{
				WinDraw_HideMenu();
			}
			break;

		case WM_ENTERSIZEMOVE:
			DS_UIMode=TRUE;
			break;
		case WM_EXITSIZEMOVE:
			DS_UIMode=FALSE;
			break;

		case WM_KEYDOWN:
			Keyboard_KeyDown(wParam, lParam);
			break;
		case WM_KEYUP:
			if ((WORD)wParam == VK_F12) X1_Reset();
			Keyboard_KeyUp(wParam, lParam);
			break;
/*
		case WM_SYSKEYDOWN:
			if (wParam == VK_F10)
				return(DefWindowProc(hWnd, WM_SYSKEYDOWN, wParam, lParam));
			Keyboard_KeyDown(wParam, lParam);
			break;
		case WM_SYSKEYUP:
			if (wParam == VK_F10)
				return(DefWindowProc(hWnd, WM_SYSKEYUP, wParam, lParam));
			Keyboard_KeyUp(wParam, lParam);
			break;
*/
		case WM_TIMER:
			WmTimer(hWnd, wParam, lParam);
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		default:
			return(DefWindowProc(hWnd, msg, wParam, lParam));
	}
	return(0L);
}

// --------------------------------------------------------------------------
//   �������ƏI��
// --------------------------------------------------------------------------

void WinUI_Init()
{
	GetKeyboardState((LPBYTE)&BackupKeyState);
	WinUI_CapsLED(0);
	WinUI_ScrollLED(0);
}

void WinUI_Cleanup()
{
	WinUI_CapsLED((BYTE)(!!BackupKeyState[VK_CAPITAL]));
	WinUI_ScrollLED((BYTE)(!!BackupKeyState[VK_SCROLL]));
}
