#include "..\win32\common.h"
#include "..\win32\resource.h"
#include "..\win32\winx1.h"
#include "..\win32\windraw.h"
#include "..\win32\timer.h"
#include "..\win32\fileio.h"
#include "..\win32\dsound.h"
#include "..\x1\z80.h"
#include "..\x1\opm.h"

extern	LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

extern	short	FASTCALL PSG_Init(DWORD clock, DWORD rate);
extern	void	FASTCALL PSG_SetVolume(BYTE vol);
extern	void	PropPage_Init(void);
extern	BYTE	palchanged;
extern	DWORD	Config_SampleRate, Config_BufferSize;
extern	BYTE	Config_DSAlert;
extern	BYTE	FrameNum;

	HWND		hWndMain;
	HINSTANCE	hInst;

	unsigned int	timerid = 0;
static	BYTE		fskipcount = 0;

const	char	*prgname="WinX1\0";
	char	winx1dir[MAX_PATH];
	char	winx1ini[MAX_PATH];

extern	BYTE	Config_ROM_TYPE;
extern	BYTE	Config_DIP_SW;
extern	BYTE	Config_SKIP_LINE;
extern	BYTE	Config_FrameNum;
extern	BYTE	Config_OPM_SW;
extern	BYTE	Config_OPM_VOL;
extern	BYTE	Config_PSG_VOL;
extern	DWORD	Config_SampleRate;
extern	BYTE	Config_FDD_LED_SW;

extern	WORD	CRTC_CRT_YL;
extern	BYTE	PCG_VSync;

extern	DWORD	timertick;
extern	BYTE	MenuFlag;

	BYTE	RAM[0x10000];
	BYTE	ROM[0x8000];
	BYTE	ANK_FNT[256][8];
	BYTE	KNJ_FNT[0x4bc00];

	WORD	v_cnt;
	WORD	HSYNC_CLK = 250;
	BYTE	ROM_SW = 1;

	BYTE	ROM_TYPE;
	BYTE	DIP_SW;
	BYTE	SKIP_LINE;
	BYTE	FrameNum;
	BYTE	OPM_SW;
extern	BYTE	FDD_LED_SW;

	BYTE	HasX1IPL = 0;
	BYTE	HasTurboIPL = 0;

	DWORD	timericnt = 0;

// ------ �e�X�g���p�̕ϐ��u���� ------
// ------ �����ƍ����������悤�� --
BYTE	Config_KeyMode;
// ------------------------------------


// -----------------------------------------------------------------------------------
//  IPL�ǂݍ���
// -----------------------------------------------------------------------------------

const	BYTE	IPLFILE[] = "IPLROM.X1";
const	BYTE	TURBOIPLFILE[] = "IPLROM.X1T";

int LoadIPL_X1T(void)
{
	FILEH fp;
	fp = File_OpenCurDir("IPLROM.X1T");
	if (!fp) return FALSE;
	File_Read(fp, ROM, 0x8000);
	File_Close(fp);
	return TRUE;
}

int LoadIPL_X1(void)
{
	FILEH fp;
	fp = File_OpenCurDir("IPLROM.X1");
	if (!fp) return FALSE;
	File_Read(fp, ROM, 0x8000);
	File_Close(fp);
	return TRUE;
}

int LoadIPL(int flag)
{
	FILEH fp;
	ZeroMemory(ROM, sizeof(ROM));

	fp = File_OpenCurDir("IPLROM.X1");
	if (fp) {HasX1IPL = 1; File_Close(fp);} else {HasX1IPL = 0;}
	fp = File_OpenCurDir("IPLROM.X1T");
	if (fp) {HasTurboIPL = 1; File_Close(fp);} else {HasTurboIPL = 0;}

	if (flag != 1) {
		if (HasTurboIPL)
		{
			LoadIPL_X1T();
			ROM_TYPE = Config_ROM_TYPE = 2;
			return TRUE;
		}
		else if (HasX1IPL)
		{
			LoadIPL_X1();
			ROM_TYPE = Config_ROM_TYPE = 1;
			return TRUE;
		}
		else
		{
			ROM_TYPE = Config_ROM_TYPE = 0;
			return FALSE;
		}
	}
	else if (HasX1IPL)
	{
		LoadIPL_X1();
		ROM_TYPE = Config_ROM_TYPE = 1;
		return TRUE;
	}
	else if (HasTurboIPL)
	{
		LoadIPL_X1T();
		ROM_TYPE = Config_ROM_TYPE = 2;
		return TRUE;
	}
	else
	{
		ROM_TYPE = Config_ROM_TYPE = 0;
		return FALSE;
	}
}


// -----------------------------------------------------------------------------------
//  �ӂ���Ɠǂݍ���
// -----------------------------------------------------------------------------------

int LoadFont(void) {

	FILEH fp;

	fp = File_OpenCurDir("FNT0808.X1");
	if (!fp) return FALSE;
	File_Read(fp, ANK_FNT[0], 8*256);
	File_Close(fp);

	fp = File_OpenCurDir("FNT0816.X1");
	if (fp)
	{
		File_Read(fp, KNJ_FNT, 0x1000);
		File_Close(fp);
	}

	fp = File_OpenCurDir("FNT1616.X1");
	if (fp)
	{
		File_Read(fp, &KNJ_FNT[0x1000], 0x4ac00);
		File_Close(fp);
	}

	return TRUE;
}


// -----------------------------------------------------------------------------------
//  �肹���Ƃ��`
// -----------------------------------------------------------------------------------

int X1_Reset(void)
{
	char buf[50];

	HSYNC_CLK = 250;
	ROM_SW = 1;

	ROM_TYPE = Config_ROM_TYPE;
	DIP_SW = Config_DIP_SW;
	SKIP_LINE = Config_SKIP_LINE;
	OPM_SW = Config_OPM_SW;
	FDD_LED_SW = Config_FDD_LED_SW;
	if (!Config_FrameNum) Config_FrameNum = 60;
	FrameNum = 60/Config_FrameNum;

	if (!LoadIPL((int)ROM_TYPE))
	{
		Error("IPL�C���[�W��������܂���B");
		return FALSE;
	}

	Z80_Reset();
	VRAM_Init();
	CRTC_Init();
	Draw_Init();
	PCG_Init();
	SCPU_Init();
	Keyboard_Init();
	PIA_Init();
	FDC_Init();
	DMA_Init();

	if (Config_SampleRate)
	{
		PSG_Init(2000000, Config_SampleRate);			// ���g�����ӎU�L�������c
		OPM_Init(4000000/*3579545*/, Config_SampleRate);
	}
	else
	{
		PSG_Init(2000000, 100);
		OPM_Init(4000000/*3579545*/, 100);
	}

	PSG_SetVolume(Config_PSG_VOL);
	OPM_SetVolume(Config_OPM_VOL);

	return TRUE;
}



// -----------------------------------------------------------------------------------
//  ������
// -----------------------------------------------------------------------------------

int X1_Init(void)
{

	if (!LoadFont())
	{
		Error("�t�H���g�t�@�C����������܂���B");
		return FALSE;
	}
	if (!X1_Reset()) return FALSE;

	return TRUE;
}

// -----------------------------------------------------------------------------------
//  ��n��
// -----------------------------------------------------------------------------------

void X1_Cleanup(void)
{
}

// --------------------------------------------------------------------------
//   ���񑩂̃��C��
// --------------------------------------------------------------------------

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPreInst,
						LPSTR lpszCmdLine, int nCmdShow)
{
	WNDCLASS	winx1;
	MSG		msg;

	HWND		hwnd;
	HACCEL		accel;

	LPTSTR filepart;
	char buf[MAX_PATH];

	if ((hwnd = FindWindow(prgname, NULL)) != NULL) {
		ShowWindow(hwnd, SW_RESTORE);
		SetForegroundWindow(hwnd);
		return(FALSE);
	}

	hInst = hInstance;

	GetModuleFileName(0, buf, MAX_PATH);
	GetFullPathName(buf, MAX_PATH, winx1dir, &filepart);
	*filepart = 0;
	strcpy(winx1ini, winx1dir);
	strcat(winx1ini, "winx1.ini");

	if (!hPreInst) {
		winx1.style = CS_BYTEALIGNCLIENT | CS_HREDRAW | CS_VREDRAW;
		winx1.lpfnWndProc = WndProc;
		winx1.cbClsExtra = 0;
		winx1.cbWndExtra = 0;
		winx1.hInstance = hInstance;
		winx1.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MAIN_ICON));
		winx1.hCursor = LoadCursor(NULL, IDC_ARROW);
		winx1.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
		winx1.lpszMenuName = MAKEINTRESOURCE(IDR_MENU);
		winx1.lpszClassName = prgname;

		accel = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_MAIN_ACCEL));

		if (!RegisterClass(&winx1)) {
			return(FALSE);
		}
	}

	hWndMain = CreateWindowEx(0,
			prgname, prgname,
			WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION |
			WS_MINIMIZEBOX,
			CW_USEDEFAULT, CW_USEDEFAULT,
			SCREEN_WIDTH, SCREEN_HEIGHT,
			NULL, NULL, hInstance, NULL);

	LoadConfig();
	WinUI_Init();

	WinDraw_InitWindowSize(SCREEN_WIDTH, SCREEN_HEIGHT);
	WinDraw_ChangeMode(FALSE);

	ShowWindow(hWndMain, nCmdShow);
	UpdateWindow(hWndMain);

	WinDraw_InitFlags();
	if (!WinDraw_Init()) {
		WinDraw_Cleanup();
		Error("DirectDraw�̏������Ɏ��s���܂����B");
		return FALSE;
	}

	if (!X1_Init()) {
		X1_Cleanup();
		WinDraw_Cleanup();
		return FALSE;
	}

	if (DSound_Init(Config_SampleRate, Config_BufferSize) == FALSE)
		if (Config_DSAlert) Error("DirectSound�̏������Ɏ��s���܂����B\n�T�E���h�����Ōp�����܂��B");

	Joystick_Init();

	Timer_Init();
	timertick = GetTickCount();
	timerid = SetTimer(hWndMain, 1, 1000, 0);

	while (1)
	{
		if (PeekMessage(&msg, 0, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				break;
			}
			if (!TranslateAccelerator(msg.hwnd, accel, &msg))
				TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			if (!MenuFlag && Timer_GetCount())
			{
				Timer_SetCount(0);
				Z80_Execute();
				if (++fskipcount >= FrameNum) {
					fskipcount = 0;
					Draw_ScreenUpdate();
				}
			}
		}
	}

	if (timerid) KillTimer(hWndMain, timerid);

	Joystick_Cleanup();
	DSound_Cleanup();
	OPM_Cleanup();
	X1_Cleanup();
	WinDraw_Cleanup();
	WinUI_Cleanup();
	SaveConfig();

	return msg.wParam;
}
