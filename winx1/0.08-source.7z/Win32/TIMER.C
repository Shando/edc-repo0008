#include	<windows.h>

#define	TIMEBASE 16
WORD	timercnt = 0;
DWORD	tick = 0;

void Timer_Init(void)
{
	tick = GetTickCount();
	timercnt = 0;
}

void Timer_Reset(void)
{
	tick = GetTickCount();
}

void Timer_SetCount(WORD value)
{
	timercnt = value;
}

WORD Timer_GetCount(void)
{
	DWORD	ticknow;
	DWORD	steps;

	ticknow = GetTickCount();
	steps = (ticknow - tick)/TIMEBASE;
	timercnt += (WORD)steps;
	tick += steps*TIMEBASE;
	return timercnt;
}
