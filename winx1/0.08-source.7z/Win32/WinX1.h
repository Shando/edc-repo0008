#ifndef winx1_wincore_h
#define winx1_wincore_h

typedef struct {
	BYTE	KEY_MODE;
	BYTE	SOUND_SW;
	BYTE	SKIP_LINE;
	BYTE	NOWAIT;
	BYTE	DRAW_SKIP;
	BYTE	ROM_TYPE;
	BYTE	CPU8MHz;
	BYTE	DIP_SW;
	WORD	samplingrate;
	WORD	delayms;
	BYTE	BTN_RAPID;
	BYTE	BTN_MODE;
	BYTE	LINEDEPTH;
} WinX1Cfg;

#define		SCREEN_WIDTH		640
#define		SCREEN_HEIGHT		400

#define		FULLSCREEN_WIDTH	SCREEN_WIDTH
#define		FULLSCREEN_HEIGHT	SCREEN_HEIGHT
#define		FULLSCREEN_POSY		((FULLSCREEN_HEIGHT - SCREEN_HEIGHT) / 2)

extern	char		szProgName[];
extern	WinX1Cfg	cfg;

#endif //winx1_wincore_h
