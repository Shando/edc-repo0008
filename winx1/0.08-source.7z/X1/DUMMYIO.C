// ----------------------------------------------------------------------------------------
// DUMMYIO.C - ������I/O�p�̃_�~�[�Q�{�f�o�b�O�p�R�[�h�Ȃ�
// ----------------------------------------------------------------------------------------

#include	"..\win32\common.h"
#include	"..\x1\z80.h"

extern BYTE DMA_Ready;
BYTE *dma;
extern BYTE RAM[0x10000];

void FASTCALL iotracew(WORD port, BYTE value)
{
FILE* fp;
if ((port&0xf000)!=0x4000) return;
fp = fopen("io.txt", "a");
fprintf(fp, "IO-W - Port:%04X Data:%02X @ %04Xh\n", port, value, R.PC.W&0xffff);
fclose(fp);
}

void FASTCALL iotracer(WORD port)
{
char buf[50];
//if (port<0xff8||port>0xfff) return;
sprintf(buf, "IO-R - Port:%04X\n", (port&0xffff));
Error(buf);
}

short TraceFlag = 0;

void FASTCALL cpulog()
{
FILE* fp;

//if ((unsigned short)(R.PC.W&0xffff)==0xff78) TraceFlag++;
if (TraceFlag)
{
fp = fopen("trace.txt", "a");
fprintf(fp, "%04X:%02X %02X %02X %02X  AF:%04X  BC:%04X  DE:%04X  HL:%04X  SP:%04X\n", (unsigned short)(R.PC.W), RAM[(unsigned short)(R.PC.W)+0], RAM[(unsigned short)(R.PC.W)+1], RAM[(unsigned short)(R.PC.W)+2], RAM[(unsigned short)(R.PC.W)+3], (unsigned short)(R.AF.W), (unsigned short)(R.BC.W), (unsigned short)(R.DE.W), (unsigned short)(R.HL.W), (unsigned short)(R.SP.W));
fclose(fp);
}
}

void FASTCALL dmalog()
{
FILE* fp;

dma = &DMA_Ready;

fp = fopen("dma.txt", "a");
fprintf(fp, "DMA Start - Src:%04X Dst:%04X Size:%04X\n", *(WORD*)(dma+20), *(WORD*)(dma+22), (*(WORD*)(dma+18))+1/*, *(dma+27), *(dma+28)*/);
fclose(fp);
}

void FASTCALL x1_membank_w(WORD port, BYTE value)
{}
void FASTCALL x1_sio_w(WORD port, BYTE value)
{}

BYTE FASTCALL x1_membank_r(WORD port)
{return 0xff;}
BYTE FASTCALL x1_sio_r(WORD port)
{return 0xff;}
