// -----------------------------------------------------------------------------------
//  FDC.C - Xmil���炻�̂܂ܖ���Ă��܂��� ^^;�B
//  �A���Abool�n�̒l�����͋t�Ȃ̂Œ��ӁiTRUE=1�AFALSE=0�j
// -----------------------------------------------------------------------------------

#include	"..\win32\common.h"
#include	"..\x1\fdc.h"
#include	"..\x1\fdd2d.h"
#include	"..\x1\fdd88.h"

		FDC_REGS	FDC;
		BYTE		FDC_c[4];
		BYTE		FDC_NAME[4][X1_MAX_PATH];
		BYTE		FDC_PATH[X1_MAX_PATH];
		BYTE		WRITEPT[4] = {0, 0, 0, 0};
		BYTE		DISKNUM[4] = {0, 0, 0, 0};
		BYTE		driveset = 0;
		BYTE		fdcdummyread = 0;

		short		curdisk[4]={-1, -1, -1, -1};	// �}���`�f�B�X�N�C���[�W�p
		short		maxdisk[4]={0, 0, 0, 0};	// �}���`�f�B�X�N�C���[�W�p
		DWORD		imagepos[4][D88_MAX_DISKS];	// �}���`�f�B�X�N�C���[�W�p

const	BYTE		fdctype[] = {1,1,1,1,1,1,1,1,2,2,2,2,3,4,3,3};

	BYTE	FDD_LED = 0;
extern	void	WinDraw_FDDLED(void);

extern BYTE DMA_Ready;
extern BYTE DMA_Enable;

/***********************************************************************
	�e�c�c �i�t���b�s�[�̏o���ɑ�������֐��j
***********************************************************************/

short x1_fdimage(BYTE *fname) {

	int		leng;
	char	*p;

	leng = strlen((char *)fname);
	if (leng > 3) {
		p = (char *)&fname[leng-3];
		if (strcmp(p, ".2D") == 0 || strcmp(p, ".2d") == 0) {
			return(DRV_FMT2D);
		}
	}
	if (leng > 4) {
		p = (char *)&fname[leng-4];
		if (strcmp(p, ".D88") == 0 || strcmp(p, ".d88") == 0 ||
			strcmp(p, ".88D") == 0 || strcmp(p, ".88d") == 0) {
			return(DRV_FMT88);
		}
	}
	return(DRV_EMPTY);
}


short x1_eject_fd(short drv, short flag) {

	if (drv < 0 || drv > 3) {
		return(0);
	}
	if (flag) FDC_NAME[drv][0] = 0;
	switch(DISKNUM[drv]) {
		case DRV_EMPTY:
			return(0);
		case DRV_FMT2D:
			return(fdd_eject_2d(drv));
	}
	return(fdd_eject_d88(drv));
}

short x1_set_fd(short drv, short dskno, BYTE *fname) {

	if (drv < 0 || drv > 3) {
		return(1);
	}
	if ((!fname) || (!fname[0])) {
		return(x1_eject_fd(drv, FALSE));
	}
	switch(x1_fdimage(fname)) {
		case DRV_EMPTY:
			return(1);
		case DRV_FMT2D:
			return(fdd_set_2d(drv, fname, dskno));
	}
	return(fdd_set_d88(drv, fname, dskno));
}


BYTE *x1_get_fname(short drv) {

	return(FDC_NAME[drv]);
}


/***********************************************************************
	�e�c�b �������^�I��
***********************************************************************/


void FDC_Init(void) {

	ZeroMemory(&FDC, sizeof(FDC));
	FDC.step = 1;
	ZeroMemory(FDC_c, 4);
	FDD_LED = 0;
}


BYTE fdd_stat(void) {

	switch(DISKNUM[FDC.drv]) {
		case DRV_EMPTY:
			return(0);
		case DRV_FMT2D:
			return(fdd_stat_2d());
	}
	return(fdd_stat_d88());
}


/***********************************************************************
	�e�c�b �i�w�P���猩��h�^�n�ɑ�������֐��j
***********************************************************************/

int inc_off(void) {

	BYTE	ret;

	if (!FDC.motor) {
		return(0);
	}
	if (fdcdummyread) {
		fdcdummyread--;
		return(0);
	}
	else {
		switch(DISKNUM[FDC.drv]) {
			case DRV_EMPTY:
				return(0);
			case DRV_FMT2D:
				ret = fdd_incoff_2d();
				break;
			default:
				ret = fdd_incoff_d88();
				break;
		}
		if (!ret) {
			DMA_Ready = 1;	// <- DMA � ��ި�ݺ޳ � �ر
		}
	}
	return(ret);
}


void FASTCALL x1_fdc_w(WORD port, BYTE value)
{
	short	cmnd;

	port &= 0xf;
	if (port == 8) {						// �����
		driveset = 0;
		FDC.cmnd = value;
		cmnd = value >> 4;
		FDC.type = fdctype[cmnd];
// FDD�����v����
		if (FDC.type == 2 || cmnd == 0x0f) {
			if (FDD_LED!=(FDC.drv+1))
			{
				FDD_LED=0;		// �h���C�u���ς������
				WinDraw_FDDLED();	// ��x����
			}
			FDD_LED = (FDC.drv+1);
			WinDraw_FDDLED();
		}
		else {
			FDD_LED = 0;
			WinDraw_FDDLED();
		}

		FDC.skip = 2;
		switch(cmnd) {
			case 0:							// ؽı
				if (value & 8) {			// LAYDOCK
					FDC.skip = 0;
				}
				FDC.motor = 0x80;			// Ӱ��On?
				FDC.treg = FDC.c = 0;
				FDC.step = 1;
				break;
			case 1:							// ���
				FDC.motor = 0x80;			// Ӱ��On
				FDC.step = (char)(FDC.c<=FDC.data?1:-1);
				FDC.treg = FDC.c = FDC.data;
				break;
			case 2: case 3:					// �ï��
				if (FDC.motor) {
					FDC.c += FDC.step;
					if (cmnd & 1) {
						FDC.treg = FDC.c;
					}
				}
				break;
			case 4: case 5:					// �ï�ߥ��
				if (FDC.motor) {
					FDC.step = 1;
					FDC.c++;
					if (cmnd & 1) {
						FDC.treg = FDC.c;
					}
				}
				break;
			case 6: case 7:					// �ï�ߥ���
				if (FDC.motor) {
					FDC.step = -1;
					FDC.c--;
					if (cmnd & 1) {
						FDC.treg = FDC.c;
					}
				}
				break;

			case 0x8: case 0x9:				// ذ�� �ް�
			case 0xa: case 0xb:				// ײ�  �ް�
				FDC.off = 0;
				fdcdummyread = 2;
				if (FDC.motor) {
					if (DMA_Enable) {
						DMA_Ready = 0;		// <- DMA � ��ި�ݺ޳
					}
				}
				break;

			case 0xc:						// ذ�� ���ڽ
				switch(DISKNUM[FDC.drv]) {
					case DRV_EMPTY:
						break;
					case DRV_FMT2D:
						fdd_crc_2d();
						break;
					default:
						fdd_crc_d88();
						break;
				}
				FDC.crc_off = 0;
				break;

			case 0xd:						// ̫��.�������
				fdcdummyread = 1;			// �K�v�Ȃ��H
				break;
			case 0xe:						// ذ�� �ׯ�
				break;
			case 0xf:						// ײ�  �ׯ�
				switch(DISKNUM[FDC.drv]) {
					case DRV_EMPTY:
					case DRV_FMT2D:
						break;
					default:
						if (FDC.motor) {
							init_tao_d88();
							if (DMA_Enable) {
								DMA_Ready = 0;
							}
						}
						break;
				}
				break;
		}
	}
	else {
		cmnd = FDC.cmnd >> 4;
		switch(port) {
			case 0x9:				// �ׯ�
				FDC.treg = value;
				break;
			case 0xa:				// ���
				FDC.r = value;
				break;
			case 0xb: // �ް�
				FDC.data = value;
				if (cmnd==0x0a || cmnd==0x0b) {
					switch(DISKNUM[FDC.drv]) {
						case DRV_EMPTY:
							break;
						case DRV_FMT2D:
							fdd_write_2d();
							break;
						default:
							fdd_write_d88();
							break;
					}
					inc_off();
				}
				else if (cmnd==0x0f) {					// TRACE WRITE !!!
					switch(DISKNUM[FDC.drv]) {
						case DRV_EMPTY:
						case DRV_FMT2D:
							break;
						default:
							fdd_wtao_d88(value);
							break;
					}
				}
				break;
			case 0xc: // ��ײ��/����
				driveset = 1;
				FDD_LED = 0;
				WinDraw_FDDLED();
#if 1													// ARSYS !!!
				FDC_c[FDC.drv] = FDC.c;	
				FDC.c = FDC_c[value & 0x03];			// XTAL !!!
#else
				FDC_TBL[FDC.drv] = FDC;
				FDC = FDC_TBL[value & 0x03];
#endif
				FDC.motor = (BYTE)(value & 0x80);
				FDC.drv = value & 0x03;
				FDC.h = (BYTE)(value & 0x10?1:0);

				FDC.cmnd = 0;							// T&E SORCERIAN
				FDC.data = 0;
				FDC.type = 0;

				if (!FDC.motor) {
					FDC.r = 0;							// SACOM TELENET !!!
#if 0													// XTAL !!!
					FDC.c = 0;
					FDC.step = 1;
#endif
				}
				break;
		}
	}
}

BYTE FASTCALL x1_fdc_r(WORD port)
{
static	BYTE	timeoutwait;
static	BYTE	last_r;
static	short	last_off;
		BYTE	ans;
		BYTE	cmnd;

//	TRACEIN(port);

	cmnd = (BYTE)(FDC.cmnd >> 4);

	if ((port &= 0xf) != 8) {
		last_r = -1;
		last_off = -1;
		timeoutwait = 4;
	}
	switch(port) {
		case 0x8:	// �ð��
			ans = 0;
			fdcdummyread = 0;
			if (FDC.skip) {
				FDC.skip--;
//				TRACEIN_A(0xff8, 1);
				return(1);
			}
			if (!DISKNUM[FDC.drv]) {
				if (FDC.type == 1 && FDC.c == 0) {	// �h���C�u�`�F�b�N !!!
//					TRACEIN_A(0xff8, 0x84);
					return(0x84);					// ���ڑ�����Ă鎞����
				}
//				TRACEIN_A(0xff8, 0x80);
				return(0x80);
			}
			if (FDC.type == 2) {
				if (last_r == FDC.r && last_off == FDC.off &&
						!(--timeoutwait)) {
					inc_off();
					timeoutwait = 4;
				}
				last_r = FDC.r;
				last_off = FDC.off;
			}							// Read Write���݂̂̕ω��ł�����

			if (!((ans = fdd_stat()) & 2)) {
				DMA_Ready = 1;				// <- DMA � ��ި�ݺ޳ � �ر
			}
#if 1
			if (driveset) {					// 0xffc��@�������ゾ������
				ans &= 0xc4;
			}
#endif
			if (FDC.type == 3) {
				ans = 0x0;
			}							// Read Write���݂̂̕ω��ł�����

//			TRACEIN_A(0xff8, ans);
/*{
FILE *fp;
fp=fopen("fdc.txt", "a");
fprintf(fp, "Read FF8h Cmd:%d Type:%d Ans:%02X\n", cmnd, FDC.type, ans);
fclose(fp);
}*/
			return(ans);

		case 0x9:							// �ׯ�
//			TRACEIN_A(0xff9, FDC.treg);
			return(FDC.treg);

		case 0xa:							// ���
//			TRACEIN_A(0xffa, FDC.r);
			return(FDC.r);

		case 0xb:							// �ް�
			if (FDC.motor) {
				if (cmnd==0x08 || cmnd==0x09) {	// ذ�ޥ�ް�
					switch(DISKNUM[FDC.drv]) {
						case DRV_EMPTY:
							break;
						case DRV_FMT2D:
							fdd_read_2d();
							break;
						default:
							fdd_read_d88();		// WOODY POCO !!!
							break;
					}
					inc_off();
				}
				else if (cmnd==0x0c) {			// ذ�ޥ���ڽ
					if (FDC.crc_off < 5) {
						FDC.data = FDC.crc_dat[FDC.crc_off];
						FDC.crc_off++;
					}
				}
			}
/*{
FILE* fp;
fp = fopen("fdc.txt", "a");
fprintf(fp, "FDC-R - Data:%02X\n", FDC.data&0xff);
fclose(fp);
}*/
			return(FDC.data);					// WOODY POCO !!!

//		case 0xc:								// FM
//		case 0xd:								// MFM
//		case 0xe:								// 1.6M
//		case 0xf:								// 500K/1M
//			break;
	}
	return(0);
}

