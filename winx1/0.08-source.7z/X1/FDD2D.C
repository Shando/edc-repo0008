// -----------------------------------------------------------------------------------
//  FDD2D.C - Xmil���炻�̂܂ܖ���Ă��܂��� ^^;�B
//  �A���Abool�n�̒l�����͋t�Ȃ̂Œ��ӁiTRUE=1�AFALSE=0�j
// -----------------------------------------------------------------------------------

#include	"..\win32\common.h"
#include	"..\win32\fileio.h"
#include	"..\x1\fdc.h"
#include	"..\x1\fdd88.h"
#include	"..\x1\fdd2d.h"

extern	FDC_REGS	FDC;
extern	BYTE		FDC_NAME[4][X1_MAX_PATH];
extern	short		curdisk[4];
extern	short		maxdisk[4];
extern	DWORD		imagepos[4][D88_MAX_DISKS];

extern	BYTE		WRITEPT[];
extern	BYTE		DISKNUM[];
static	WORD		sec_now[4] = {0, 0, 0, 0};
static	BYTE		sec_write[4] = {0, 0, 0, 0};
static	BYTE		sec_data[4][256];
static	BYTE		hole = 0;


BYTE changesector2d(void) {

	FILEH	hdl;
	WORD	sec;
	DWORD	seekp;
	short	drv = FDC.drv;

	sec = (WORD)(((FDC.c) << 5) + (FDC.h << 4) + FDC.r - 1);
	if (sec_now[drv] == sec) {
		return TRUE;
	}
	if (!(hdl = File_Open(FDC_NAME[drv]))) {
		sec_now[drv] = -1;
		return FALSE;
	}
	if ((sec_write[drv]) && (sec_now[drv] != -1)) {
		seekp = (long)sec_now[drv] << 8;
		if ((File_Seek(hdl, seekp, FSEEK_SET) != seekp) ||
			(File_Write(hdl, sec_data[drv], 256) != 256)) {
			File_Close(hdl);
			sec_now[drv] = -1;
			return FALSE;
		}
	}
	sec_write[drv] = 0;
	sec_now[drv] = sec;
	seekp = (long)sec << 8;
	if ((File_Seek(hdl, seekp, FSEEK_SET) != seekp) ||
		(File_Read(hdl, sec_data[drv], 256) != 256)) {
		File_Close(hdl);
		sec_now[drv] = -1;
		return FALSE;
	}
	File_Close(hdl);
	return TRUE;
}

short fdd_eject_2d(short drv) {

	FILEH	hdl;
	DWORD	seekp;
	short	ret = TRUE;

	while(1) {
		if ((!sec_write[drv]) || (sec_now[drv] == -1)) {
			break;
		}
		seekp = (long)sec_now[drv] << 8;
		if (!(hdl = File_Open(FDC_NAME[drv]))) {
			ret = FALSE;
			break;
		}
		if ((File_Seek(hdl, seekp, FSEEK_SET) != seekp) ||
			(File_Write(hdl, sec_data[drv], 256) != 256)) {
			ret = FALSE;
		}
		if (File_Close(hdl)) {
			ret = FALSE;
		}
		break;
	}
//	FDC_NAME[drv][0] = '\0';
	DISKNUM[drv] = 0;
	sec_now[drv] = -1;
	sec_write[drv] = 0;
	curdisk[drv] = -1;
	maxdisk[drv] = 0;
	return (ret);
}


short fdd_set_2d(short drv, BYTE *fname, short disknum)
{
	WORD	attr;
	fdd_eject_2d(drv);
	if ((drv < 0 || drv > 3) ||
		((attr = File_Attr(fname)) & 0x18)) {	// �װ��ިڸ�إ����
		return FALSE;
	}
	DISKNUM[drv] = DRV_FMT2D;
	strncpy(FDC_NAME[drv], fname, MAX_PATH);
	WRITEPT[drv] = (BYTE)(attr & 1);
//	if (disknum>=maxdisk[drv])
//	{
//		fdd_eject_2d(drv);
//		return FALSE;
//	}
	maxdisk[drv] = 1;
	curdisk[drv] = disknum;
	return TRUE;
}

//**********************************************************************

short fdd_crc_2d(void) {

	FDC.crc_dat[0] = FDC.c;
	FDC.crc_dat[1] = FDC.h;
	FDC.crc_dat[2] = FDC.r;
	FDC.crc_dat[3] = 1;
	FDC.crc_dat[4] = 0;			// CRC(Lo)
	FDC.crc_dat[5] = 0;			// CRC(Hi)
	return TRUE;
}


BYTE fdd_stat_2d(void) {

	BYTE	type, cmnd;
	BYTE	ans = 0;
	// NOT READY
	if (DISKNUM[FDC.drv] != DRV_FMT2D) {
		return(0x80);
	}
	type = FDC.type;
	cmnd = (BYTE)(FDC.cmnd >> 4);

	if (type == 0 || type == 1 || type == 4 ||					// !!!
		cmnd == 0x0a || cmnd == 0x0b || cmnd == 0x0f) {
		if (WRITEPT[FDC.drv]) {				// WRITE PROTECT
			ans |= 0x40;
		}
	}
	if ((type == 1 || type == 2 || cmnd == 0x0c) &&
		((FDC.c > 39) || (FDC.h > 1) || (FDC.r > 16))) {
		ans |= 0x10;					// SEEK ERROR / RECORD NOT FOUND
	}

	if (type == 1 || type == 4) {
		ans |= 0x20;						// HEAD ENGAGED (X1 ��� ��� 1)
		if (FDC.c == 0) {
			ans |= 0x04;					// TRACK00
		}
		if (hole++) {
			ans |= 0x02;					// INDEX
		}
		hole &= 15;
	}
	else if (!(ans & 0xf0)) {
		if ((type == 2) && (FDC.r) && (FDC.off < 256)) {
			ans |= 0x03;					// DATA REQUEST / BUSY
		}
		else if (cmnd == 0x0f) {
			ans |= 0x04;					// error!
		}
	}
	return(ans);
}


//**********************************************************************

void fdd_read_2d(void) {

	if (((fdd_stat_2d() & 0xf3) == 3) && (changesector2d())) {
		FDC.data = sec_data[FDC.drv][FDC.off];
	}
}


void fdd_write_2d(void) {

	if (((fdd_stat_2d() & 0xf3) == 3) && (changesector2d())) {
		sec_data[FDC.drv][FDC.off] = FDC.data;
		sec_write[FDC.drv] = 1;
	}
}


BYTE fdd_incoff_2d(void) {

	BYTE cmnd;

	if (++FDC.off < 256) {
		return TRUE;
	}
	cmnd = (BYTE)(FDC.cmnd >> 4);
	if ((cmnd == 0x09 || cmnd == 0x0b) && (FDC.r < 16)) {
		FDC.r++;
		FDC.off = 0;
		return TRUE;
	}
	FDC.off = 256;
	return FALSE;
}


