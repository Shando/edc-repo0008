// -----------------------------------------------------------------------------------
//  FDD88.C - �}���`�C���[�W�p�ɂ��傱���Ƃ�������
//  �܂��AXmil�Ƃ�bool�n�̒l���t�Ȃ̂Œ��ӁiTRUE=1�AFALSE=0�j
// -----------------------------------------------------------------------------------

#include	"..\win32\common.h"
#include	"..\win32\fileio.h"
#include	"..\x1\fdc.h"
#include	"..\x1\fdd88.h"

D88_HEADER		d88head[4][20];			// �}���`�f�B�X�N�C���[�W�p
static	D88_SECTOR	cursec;
static	short		curdrv = -1;
static	WORD		curtrk = -1;
static	WORD		cursct = -1;
static	DWORD		curfp = 0;
static	DWORD		cursize = 0;
static	BYTE		curwrite = 0;
static	BYTE		curtrkerr = 0;
static	BYTE		hole = 0;
static	BYTE		*curdata;
static	WORD		crcnum = 0;
static	BYTE		crcerror = FALSE;

extern	FDC_REGS	FDC;
extern	BYTE		FDC_NAME[4][MAX_PATH];
extern	BYTE		WRITEPT[];
extern	BYTE		DISKNUM[];

extern	short		curdisk[4];			// �}���`�f�B�X�N�C���[�W�p
extern	short		maxdisk[4];			// �}���`�f�B�X�N�C���[�W�p
extern	DWORD		imagepos[4][D88_MAX_DISKS];	// �}���`�f�B�X�N�C���[�W�p



#define		TAO_MODE_4E		0x4e
#define		TAO_MODE_00		0x00
#define		TAO_MODE_F5		0xf5
#define		TAO_MODE_F6		0xf6
#define		TAO_MODE_CRC	0xfe
#define		TAO_MODE_DATA	0xfb
#define		TAO_ENDOFDATA	0xf7

static	BYTE		chrn[4];
static	BYTE		taomode;
static	BYTE		taoflag;
static	WORD		taop;
static	WORD		taocnt;
static	WORD		taosize;
static	WORD		taosec;
static	WORD		cnt_4e;
static	WORD		taotop;

static	BYTE		D88_BUF[0x2000];
static	BYTE		TAO_BUF[0x2000];

//----------------------------------------------------------------------

DWORD nexttrackp(D88_HEADER *head, DWORD fptr, DWORD last)
{

	int		t;
	DWORD	ret;
	DWORD	*trkp;

	ret = last;
	trkp = (DWORD *)head->trackp;
	for (t=0; t<164; t++, trkp++) {
		if ((*trkp > fptr) && (*trkp < ret))
		{
			ret = *trkp;
		}
	}
	return(ret);
}


int curdataflush(void)
{
	FILEH	hdr;
	int		ret = 0;

	if ((!curfp) || (!cursize))
	{
		return(-1);
	}
	if (!curwrite) 
	{
		return TRUE;
	}
	curwrite = 0;
	if ((hdr = File_Open(FDC_NAME[curdrv])) == (FILEH)-1)
	{
		return FALSE;
	}
	if ((File_Seek(hdr, curfp, FSEEK_SET) != curfp) ||
		(File_Write(hdr, D88_BUF, (DWORD)cursize) != (DWORD)cursize))
	{
		ret = FALSE;
	}
	if (File_Close(hdr))
	{
		ret = FALSE;
	}
	return ret;
}


DWORD read_d88track(short drv, WORD track)
{
	FILEH	hdr;
	short	curdsk = curdisk[drv];
	DWORD	curpos = imagepos[drv][curdsk];

	curdataflush();
	curdrv = drv;
	curtrk = track;
	cursct = -1;
	curwrite = 0;
	curtrkerr = 0;
	crcnum = 0;
	crcerror = 0;

	if ((drv < 0) || (drv > 3) || (track > 163) ||
		((curfp = (d88head[drv][curdisk[drv]]).trackp[track] + imagepos[drv][curdsk]) == 0) ||
		((cursize = nexttrackp(&d88head[drv][curdsk], curfp-curpos,
				d88head[drv][curdsk].fd_size) - (curfp-curpos)) > 0x2000))
	{
		goto readd88_err;
	}

	if (!(hdr = File_Open(FDC_NAME[drv])))
	{
		goto readd88_err;
	}
	if (File_Seek(hdr, curfp, FSEEK_SET) != curfp)
	{
		File_Close(hdr);
		goto readd88_err;
	}
	if (File_Read(hdr, D88_BUF, (DWORD)cursize) != (DWORD)cursize)
	{
		File_Close(hdr);
		goto readd88_err;
	}
	File_Close(hdr);

	return (TRUE);

readd88_err:
	curfp = 0;
	cursize = 0;
	curtrkerr = 1;
	return (FALSE);
}




int seeksector(short drv, WORD track, WORD sector) {

static	int		lastflag = FALSE;

	BYTE 		*p;
	WORD		sec;

	if (curdrv != drv || curtrk != track) {
		read_d88track(drv, track);
	}
	if (curtrkerr) {
		cursct = sector;
		goto seekerror;
	}
	if (cursct != sector) {
		cursct = sector;
		p = D88_BUF;
		for (sec=0; sec<18;) {
			if ((WORD)((D88_SECTOR far *)p)->r == sector) {
				memcpy(&cursec, p, sizeof(D88_SECTOR));
				curdata = p + sizeof(D88_SECTOR);
				lastflag = TRUE;
				break;
			}
			if (++sec >= ((D88_SECTOR far *)p)->sectors) {
				goto seekerror;
			}
			p += ((D88_SECTOR far *)p)->size;
			p += sizeof(D88_SECTOR);
		}
		if (sec >= 18) {
			goto seekerror;
		}
	}
	return(lastflag);

seekerror:;
	ZeroMemory(&cursec, sizeof(D88_SECTOR));
	curdata = &D88_BUF[16];
	lastflag = FALSE;
	return(FALSE);
}


void drvflush(short drv) {

	if (curdrv == drv) {
		curdataflush();
		curdrv = -1;
		curtrk = -1;
		cursct = -1;
	}
}


//**********************************************************************

short readheaders_d88(short drv, FILEH hdr)
{
	File_Seek(hdr, 0, FSEEK_SET);
	
	for (maxdisk[drv] = 0; maxdisk[drv] < D88_MAX_DISKS; maxdisk[drv]++)
	{
		imagepos[drv][maxdisk[drv]] = File_Seek(hdr, 0, FSEEK_CUR);
		if (File_Read(hdr, &d88head[drv][maxdisk[drv]], (DWORD)sizeof(D88_HEADER)) < (DWORD)sizeof(D88_HEADER))
			break;

//	�����ɃC���[�W�f�[�^�̃`�F�b�N������Ȃ��Ɓc
		
		d88head[drv][maxdisk[drv]].fd_name[16] = 0;
		File_Seek(hdr, imagepos[drv][maxdisk[drv]] + d88head[drv][maxdisk[drv]].fd_size, FSEEK_SET);
	}
	if (!maxdisk[drv])
		return FALSE;

	return TRUE;
}


short fdd_eject_d88(short drv) 
{
	short i;
	drvflush(drv);
	for (i=0; i<D88_MAX_DISKS; i++)
		ZeroMemory(&d88head[drv][i], sizeof(D88_HEADER));
//	FDC_NAME[drv][0] = '\0';
	DISKNUM[drv] = 0;
	curdisk[drv]=-1;
	maxdisk[drv]=0;
	return TRUE;
}


short fdd_set_d88(short drv, BYTE *fname, short disknum) {

	WORD	attr;
	FILEH	hdr;
	short	i;

	fdd_eject_d88(drv);
	if ((drv < 0 || drv > 3) ||
		((attr = File_Attr(fname)) & 0x18)) {	// �װ��ިڸ�إ����
		return FALSE;
	}
	if (!(hdr = File_Open(fname))) {
		return FALSE;
	}
	readheaders_d88(drv, hdr);
	File_Close(hdr);
	if (!maxdisk[drv] || (disknum>=maxdisk[drv])) {
		fdd_eject_d88(drv);
		return FALSE;
	}
	if (attr & 1) {
		for (i=0; i<maxdisk[drv]; i++)
			d88head[drv][i].protect |= (WORD)0x10;
	}
	strncpy(FDC_NAME[drv], fname, MAX_PATH);
	DISKNUM[drv] = 1;
	curdisk[drv] = disknum;
	return TRUE;
}

//**********************************************************************

short fdd_crc_d88(void) {

	WORD		track;
	BYTE		*p;
	WORD		sec;

	ZeroMemory(FDC.crc_dat, 6);
	if ((track = (WORD)(FDC.c << 1) + (WORD)FDC.h) > 163) {
		goto crcerror_d88;
	}
	seeksector(FDC.drv, track, FDC.r);
	if (curtrkerr) {
		goto crcerror_d88;
	}
	p = D88_BUF;
	for (sec=0; sec<crcnum;) {
		if (++sec >= ((D88_SECTOR far *)p)->sectors) {
			goto crcerror_d88;
		}
		p += ((D88_SECTOR far *)p)->size;
		p += sizeof(D88_SECTOR);
	}
	*(long *)FDC.crc_dat = *(long far *)p;
	crcnum++;
	crcerror = FALSE;
	return TRUE;

crcerror_d88:;
	crcerror = TRUE;
	return FALSE;
}


BYTE fdd_stat_d88(void) {

	BYTE		type, cmnd;
	BYTE		ans = 0;
	int			seekable;
	WORD		trk;

	if (DISKNUM[FDC.drv] == DRV_EMPTY) {
		return(0x80);						// NOT READY
	}
	type = FDC.type;
	cmnd = (BYTE)(FDC.cmnd >> 4);
	trk = (FDC.c << 1) + (WORD)FDC.h;
	seekable = seeksector(FDC.drv, trk, FDC.r);
	if (!FDC.r) {
		seekable = TRUE;
	}

	if (type == 0 || type == 1 || type == 4 ||
		cmnd == 0x0a || cmnd == 0x0b || cmnd == 0x0f) {
		if (d88head[FDC.drv][curdisk[FDC.drv]].protect & 0x10) {	// WRITE PROTECT
			ans |= 0x40;
		}
	}
	if (type == 2 || cmnd == 0x0f) {
		if (FDC.r && cursec.del_flg) {
			ans |= 0x20;				// RECODE TYPE / WRITE FAULT
		}
	}
	if (type == 1 || type == 2) {
		if ((trk > 163) || (!seekable)) {
			ans |= 0x10;					// SEEK ERROR / RECORD NOT FOUND
		}
		if (!(ans & 0xf0) && FDC.r && cursec.stat == 0xa0) {
			ans |= 0x08;					// CRC ERROR
		}
	}
	if (cmnd == 0x0c) {
		if (curtrkerr) {
			ans |= 0x10;
		}
		if (crcerror) {
			ans |= 0x08;					// CRC ERROR
		}
	}
	if (type == 1 || type == 4) {
		ans |= 0x20;						// HEAD ENGAGED (X1 ��� ��� 1)
		if (!FDC.c) {						// TRACK00
			ans |= 0x04;
		}
		if (hole++) {
			ans |= 0x02;					// INDEX
		}
		hole &= 15;
	}
	else if (!(ans & 0xf0)) {
		if ((type == 2) && ((WORD)FDC.off < cursec.size)) {
			ans |= 0x03; 					// DATA REQUEST / BUSY
		}
		else if ((cmnd == 0x0c) && (FDC.crc_off < 5)) {
			ans |= 0x03;
		}
		else if (cmnd == 0x0f) {
			ans |= taoflag;
		}
	}
	return(ans);
}

//**********************************************************************

void fdd_read_d88(void) {
						// POCO:�ǂ߂Ȃ������烌�W�X�^��ύX�����Ȃ�
	if ((fdd_stat_d88() & 0xf3) == 3) {
		FDC.data = curdata[FDC.off];
	}
}


void fdd_write_d88(void) {

	if ((fdd_stat_d88() & 0xf3) == 3) {
		curdata[FDC.off] = FDC.data;
		curwrite = 1;
	}
}


BYTE fdd_incoff_d88(void) {

	BYTE	cmnd;
	WORD	trk;

	cmnd = (BYTE)(FDC.cmnd >> 4);
	trk = (FDC.c << 1) + (WORD)FDC.h;
	seeksector(FDC.drv, trk, FDC.r);
	if ((WORD)(++FDC.off) < cursec.size) {
		return TRUE;
	}
	FDC.off = cursec.size;
	if ((cmnd == 0x09 || cmnd == 0x0b) &&
		seeksector(FDC.drv, trk, (WORD)(FDC.r+1))) {
		FDC.r++;
		FDC.off = 0;
		return TRUE;
	}
	return FALSE;
}

// ---------------------------------------------------------------------------


void init_tao_d88(void) {

	taomode = TAO_ENDOFDATA;
	taop = 0;
	taocnt = 0;
	taosize = 0;
	taosec = 0;
	taoflag = 3;
	cnt_4e = 0;
}


int fileappend(FILEH hdr, D88_HEADER *head,
									long ptr, long last, long apsize) {

	long	length;
	DWORD	size;
	DWORD	rsize;
	int		t;
	long	*trkp;

	if ((length = last - ptr) <= 0) {			// ����������K�v�Ȃ�
		return TRUE;
	}
	while(length) {
		if (length >= 0x2000) {
			size = 0x2000;
		}
		else {
			size = (WORD)length;
		}
		length -= (long)size;
		File_Seek(hdr, ptr+length, 0);
		rsize = File_Read(hdr, D88_BUF, size);
		File_Seek(hdr, ptr+length+apsize, 0);
		File_Write(hdr, D88_BUF, rsize);
	}

	trkp = head->trackp;
	for (t=0; t<164; t++, trkp++) {
		if ((*trkp) && (*trkp >= ptr)) {
			(*trkp) += apsize;
		}
	}
	return TRUE;
}



void endoftrack(int err) {

	FILEH		hdr;
	int			i;
	WORD		trk;
	D88_HEADER	*head;
	long		fpointer;
	long		endpointer;
	long		lastpointer;
	long		trksize;
	int			ptr;
	long		apsize;

	taoflag = 0;
	if ((!taosec) || (err)) {
		taoflag = 4;
		return;
	}


	curdataflush();						// write cache flush &
	curdrv = -1;						// use D88_BUF[] for temp

	head = &d88head[FDC.drv][curdisk[FDC.drv]];
	trk = (FDC.c << 1) + (WORD)FDC.h;

	ptr = 0;
	for (i=0; i<(int)taosec; i++)
	{
		((D88_SECTOR far *)&TAO_BUF[ptr])->sectors = taosec;
		ptr += ((D88_SECTOR far *)&TAO_BUF[ptr])->size + 16;
	}

	if (!(hdr = File_Open(FDC_NAME[FDC.drv])))
	{
		return;
	}

	if (curdisk[FDC.drv]+1<maxdisk[FDC.drv])
		lastpointer = imagepos[FDC.drv][curdisk[FDC.drv]+1];
	else
		lastpointer = File_Seek(hdr, 0, FSEEK_END);
	if ((fpointer = head->trackp[trk]) == 0) {
		fpointer = 0;								// �V�K�g���b�N
		for (i=trk; i>=0; i--) {
			if (head->trackp[i]) {
				fpointer = head->trackp[i];
				break;
			}
		}
		if (fpointer) {								// �q�b�g����
			fpointer = nexttrackp(head, fpointer, lastpointer);
		}
		else {
			fpointer = sizeof(D88_HEADER);
		}
		endpointer = fpointer;
	}
	else {										// �g���b�N�f�[�^�͊��ɂ���
		endpointer = nexttrackp(head, fpointer, lastpointer);
	}
	trksize = endpointer - fpointer;
	if ((apsize = (long)taosize - trksize) > 0) {
								// �������ރf�[�^�̂ف[���傫��
		fileappend(hdr, head, endpointer, File_Seek(hdr, 0, FSEEK_END), apsize);
		head->fd_size += apsize;
	}
	head->trackp[trk] = fpointer;
	File_Seek(hdr, fpointer, 0);
	File_Write(hdr, TAO_BUF, taosize);
	File_Seek(hdr, 0, 0);
	File_Write(hdr, head, sizeof(D88_HEADER));
	File_Close(hdr);
}


void fdd_wtao_d88(BYTE data) {

	if (taocnt > 0x1f00) {		// 1a00->1f00 XDOS
		endoftrack(0);
		return;
	}
	taocnt++;
	switch(taomode) {
		case TAO_ENDOFDATA:
			if (data == 0x4e) {
				taomode = TAO_MODE_4E;
				cnt_4e = 0;
			}
			break;
		case TAO_MODE_4E:
			if (data == 0x4e) {
				if (cnt_4e++ > 256) {
					endoftrack(0);
				}
			}
			else if (!data) {
				taomode = TAO_MODE_00;
			}
			else {
				endoftrack(1);
			}
			break;
		case TAO_MODE_00:
			if (data == 0xf5) {
				taomode = TAO_MODE_F5;
			}
			else if (data == 0xf6) {
				taomode = TAO_MODE_F6;
			}
			else if (data) {
				endoftrack(1);
			}
			break;
		case TAO_MODE_F6:							// EXPERT-X1 & TFM
			if (data == 0xfc) {
				taomode = TAO_ENDOFDATA;
			}
			else if (data != 0xf6) {
				endoftrack(1);
			}
			break;
		case TAO_MODE_F5:
			if (data == 0xfe) {
				taomode = TAO_MODE_CRC;
				taop = 0;
				taotop = taosize;
			}
			else if (data == 0xfb) {
				taomode = TAO_MODE_DATA;
				taop = 0;
			}
			break;
		case TAO_MODE_CRC:						// CRC WRITE
			if ((data == 0xfe) && (!taop)) {
				break;
			}
			else if (taop < 4) {
				TAO_BUF[taosize++] = data;
				taop++;
			}
			else if (data == 0xf7) {
				taomode = TAO_ENDOFDATA;
				ZeroMemory(&TAO_BUF[taosize], 12);
				taosize += 12;
			}
			break;
		case TAO_MODE_DATA:						// DATA WRITE
			if ((data == 0xfb) && (!taop)) {
				break;
			}
			else if (data == 0xf7) {			// n�Ŕ��肵����������H
				taomode = TAO_ENDOFDATA;
				((D88_SECTOR far *)&TAO_BUF[taotop])->size = taop;
				if (taosec++ > 20) {
					endoftrack(1);
				}
			}
			else {
				TAO_BUF[taosize++] = data;
				taop++;
			}
			break;
	}
}


