// -----------------------------------------------------------------------------------------
//  OPM.C - MAME��FM.C����OPM����������؂�o�������̂ꂷ�B
//  �Ƃ��Ă��d���̂ŃA�Z���u�����̕K�v�A���B
// -----------------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include "opm.h"
#include "..\win32\common.h"

extern BYTE OPM_SW;
static double VolumeShift = 65536;

#ifndef PI
#define PI 3.14159265358979323846
#endif

#define OPM_ARRATE     399128
#define OPM_DRRATE    5514396

#define FREQ_BITS 24
#define FREQ_RATE   (1<<(FREQ_BITS-21))
#define TL_BITS    (FREQ_BITS+2)
#define TL_SHIFT (TL_BITS+1-(14-16))

#define FM_OUTSB  (TL_SHIFT-FM_OUTPUT_BIT)
#define FM_MAXOUT ((1<<(TL_SHIFT-1))-1)
#define FM_MINOUT (-(1<<(TL_SHIFT-1)))

#define OP_CUT_MASK (0xffffffff<<FM_OUTSB)
#define SIN_ENT 2048

#define ENV_BITS 16
#define EG_ENT   4096
#define EG_OFF   ((2*EG_ENT)<<ENV_BITS)
#define EG_DED   EG_OFF
#define EG_DST   (EG_ENT<<ENV_BITS)
#define EG_AED   EG_DST
#define EG_AST   0

#define EG_STEP (96.0/EG_ENT)

#define LFO_ENT 512
#define LFO_SHIFT (32-9)
#define LFO_RATE 0x10000

#define OPM_CHAN(N) (N&7)
#define OPM_SLOT(N) ((N>>3)&3)

#define SLOT1 0
#define SLOT2 2
#define SLOT3 1
#define SLOT4 3

#define ENV_MOD_OFF 0x00
#define ENV_MOD_RR  0x01
#define ENV_MOD_SR  0x02
#define ENV_MOD_DR  0x03
#define ENV_MOD_AR  0x04
#define ENV_SSG_SR  0x05
#define ENV_SSG_DR  0x06
#define ENV_SSG_AR  0x07

#define OUTD_RIGHT  1
#define OUTD_LEFT   2
#define OUTD_CENTER 3

#define FM_TIMER_SINGLE (0)
#define FM_TIMER_INTERVAL (1)

typedef struct fm_slot {
	INT32 *DT;			/* detune          :DT_TABLE[DT]       */
	int DT2;			/* multiple,Detune2:(DT2<<4)|ML for OPM*/
	int TL;				/* total level     :TL << 8            */
	INT32 TLL;			/* adjusted now TL                     */
	UINT8 KSR;			/* key scale rate  :3-KSR              */
	INT32 *AR;			/* attack rate     :&AR_TABLE[AR<<1]   */
	INT32 *DR;			/* decay rate      :&DR_TABLE[DR<<1]   */
	INT32 *SR;			/* sustin rate     :&DR_TABLE[SR<<1]   */
	int  SL;			/* sustin level    :SL_TABLE[SL]       */
	INT32 *RR;			/* release rate    :&DR_TABLE[RR<<2+2] */
	UINT8 SEG;			/* SSG EG type     :SSGEG              */
	UINT8 ksr;			/* key scale rate  :kcode>>(3-KSR)     */
	UINT32 mul;			/* multiple        :ML_TABLE[ML]       */
	UINT32 Cnt;			/* frequency count :                   */
	UINT32 Incr;		/* frequency step  :                   */
	/* envelope generator state */
	UINT8 evm;			/* envelope phase                      */
	INT32 evc;			/* envelope counter                    */
	INT32 eve;			/* envelope counter end point          */
	INT32 evs;			/* envelope counter step               */
	INT32 evsa;		/* envelope step for AR                */
	INT32 evsd;		/* envelope step for DR                */
	INT32 evss;		/* envelope step for SR                */
	INT32 evsr;		/* envelope step for RR                */
	/* LFO */
	UINT8 amon;
	UINT32 ams;
}FM_SLOT;

typedef struct fm_chan {
	FM_SLOT	SLOT[4];
	UINT8 PAN;			/* PAN NONE,LEFT,RIGHT or CENTER       */
	UINT8 ALGO;			/* algorythm                           */
	UINT8 FB;			/* feed back       :&FB_TABLE[FB<<8]   */
	INT32 op1_out[2];	/* op1 output foe beedback             */
	/* algorythm state */
	INT32 *connect1;		/* operator 1 connection pointer       */
	INT32 *connect2;		/* operator 2 connection pointer       */
	INT32 *connect3;		/* operator 3 connection pointer       */
	INT32 *connect4;		/* operator 4 connection pointer       */
	/* LFO */
	INT32 pms;
	UINT32 ams;
	/* phase generator state */
	UINT32  fc;			/* fnum,blk        :calcrated          */
	UINT8 fn_h;			/* freq latch      :                   */
	UINT8 kcode;		/* key code        :                   */
} FM_CH;

/* OPN/OPM common state */
typedef struct fm_state {
	int clock;			/* master clock  (Hz)  */
	int rate;			/* sampling rate (Hz)  */
	double freqbase;	/* frequency base      */
	double TimerBase;	/* Timer base time     */
	UINT8 address;		/* address register    */
	UINT8 irq;			/* interrupt level     */
	UINT8 irqmask;		/* irq mask            */
	UINT8 status;		/* status flag         */
	UINT32 mode;		/* mode  CSM / 3SLOT   */
	int TA;				/* timer a             */
	int TAC;			/* timer a counter     */
	UINT8 TB;			/* timer b             */
	int TBC;			/* timer b counter     */
	/* speedup customize */
	/* time tables */
	INT32 DT_TABLE[8][32];	/* detune tables       */
	INT32 AR_TABLE[94];	/* atttack rate tables */
	INT32 DR_TABLE[94];	/* decay rate tables   */
	/* timer model single / interval */
	UINT8 timermodel;
} FM_ST;

/* -------------------- tables --------------------- */

#define DV (1/EG_STEP)
static const UINT8 KSL[32]=
{
#if 0
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
#else
 0.000/DV , 0.000/DV , 0.000/DV , 0.000/DV ,	/* OCT 0 */
 0.000/DV , 0.000/DV , 0.000/DV , 1.875/DV ,	/* OCT 1 */
 0.000/DV , 0.000/DV , 3.000/DV , 4.875/DV ,	/* OCT 2 */
 0.000/DV , 3.000/DV , 6.000/DV , 7.875/DV ,	/* OCT 3 */
 0.000/DV , 6.000/DV , 9.000/DV ,10.875/DV ,	/* OCT 4 */
 0.000/DV , 9.000/DV ,12.000/DV ,13.875/DV ,	/* OCT 5 */
 0.000/DV ,12.000/DV ,15.000/DV ,16.875/DV ,	/* OCT 6 */
 0.000/DV ,15.000/DV ,18.000/DV ,19.875/DV		/* OCT 7 */
#endif
};
#undef DV

static const int KC_TO_SEMITONE[16]={
	/*translate note code KC into more usable number of semitone*/
	0*64, 1*64, 2*64, 3*64,
	3*64, 4*64, 5*64, 6*64,
	6*64, 7*64, 8*64, 9*64,
	9*64,10*64,11*64,12*64
};

static const int DT2_TABLE[4]={ /* 4 DT2 values */
	0,    384,  500,  608
};

#define SC(db) (db*((3/EG_STEP)*(1<<ENV_BITS)))+EG_DST
static const int SL_TABLE[16]={
 SC( 0),SC( 1),SC( 2),SC(3 ),SC(4 ),SC(5 ),SC(6 ),SC( 7),
 SC( 8),SC( 9),SC(10),SC(11),SC(12),SC(13),SC(14),SC(31)
};
#undef SC

#define TL_MAX (EG_ENT*2) /* limit(tl + ksr + envelope + ams) + sinwave */

static INT32 *TL_TABLE;
static INT32 *SIN_TABLE[SIN_ENT];
static INT32 ENV_CURVE[2*EG_ENT+1];
static int DRAR_TABLE[EG_ENT];

#define OPM_DTTABLE OPN_DTTABLE
static UINT8 OPN_DTTABLE[4 * 32]={
/* FD=0 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
/* FD=1 */
  0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2,
  2, 3, 3, 3, 4, 4, 4, 5, 5, 6, 6, 7, 8, 8, 8, 8,
/* FD=2 */
  1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5,
  5, 6, 6, 7, 8, 8, 9,10,11,12,13,14,16,16,16,16,
/* FD=3 */
  2, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 6, 6, 7,
  8 , 8, 9,10,11,12,13,14,16,17,19,20,22,22,22,22
};

#define ML(n) (n*2)
static const int MUL_TABLE[4*16]= {
/* 1/2, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15 */
   ML(0.50),ML( 1.00),ML( 2.00),ML( 3.00),ML( 4.00),ML( 5.00),ML( 6.00),ML( 7.00),
   ML(8.00),ML( 9.00),ML(10.00),ML(11.00),ML(12.00),ML(13.00),ML(14.00),ML(15.00),
/* DT2=1 *SQL(2)   */
   ML(0.71),ML( 1.41),ML( 2.82),ML( 4.24),ML( 5.65),ML( 7.07),ML( 8.46),ML( 9.89),
   ML(11.30),ML(12.72),ML(14.10),ML(15.55),ML(16.96),ML(18.37),ML(19.78),ML(21.20),
/* DT2=2 *SQL(2.5) */
   ML( 0.78),ML( 1.57),ML( 3.14),ML( 4.71),ML( 6.28),ML( 7.85),ML( 9.42),ML(10.99),
   ML(12.56),ML(14.13),ML(15.70),ML(17.27),ML(18.84),ML(20.41),ML(21.98),ML(23.55),
/* DT2=3 *SQL(3)   */
   ML( 0.87),ML( 1.73),ML( 3.46),ML( 5.19),ML( 6.92),ML( 8.65),ML(10.38),ML(12.11),
   ML(13.84),ML(15.57),ML(17.30),ML(19.03),ML(20.76),ML(22.49),ML(24.22),ML(25.95)
};
#undef ML

#define PMS_RATE 0x400

static INT32 *LFO_wave;
static UINT32 lfo_amd;
static INT32 lfo_pmd;

static INT32 RATE_0[32]=
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

/* -------------------- state --------------------- */

static FM_ST     *State;

static FMSAMPLE  *bufL,*bufR;
static FM_CH  *cch[8];
static INT32 outd[4];

static UINT32 LFOCnt,LFOIncr;

static INT32 feedback2;		/* connect for operator 2 */
static INT32 feedback3;		/* connect for operator 3 */
static INT32 feedback4;		/* connect for operator 4 */

#define Limit(val, max,min) { \
	if ( val > max )      val = max; \
	else if ( val < min ) val = min; \
}

/* ----- buffering one of data(STEREO chip) ----- */
#define FM_BUFFERING_STEREO \
{														\
	/* get left & right output with clipping */			\
	outd[OUTD_LEFT]  += outd[OUTD_CENTER];				\
	Limit( outd[OUTD_LEFT] , FM_MAXOUT, FM_MINOUT );	\
	outd[OUTD_RIGHT] += outd[OUTD_CENTER];				\
	Limit( outd[OUTD_RIGHT], FM_MAXOUT, FM_MINOUT );	\
	/* buffering */										\
/*	((FMSAMPLE_MIX *)bufL)[i] = ((outd[OUTD_LEFT]>>FM_OUTSB)<<FM_OUTPUT_BIT)|(outd[OUTD_RIGHT]>>FM_OUTSB); */\
	*((WORD*)bufL++) += ((outd[OUTD_LEFT]>>FM_OUTSB)/VolumeShift); \
	*((WORD*)bufL++) += ((outd[OUTD_RIGHT]>>FM_OUTSB)/VolumeShift);\
}

/* ----- internal timer mode , update timer */
#define INTERNAL_TIMER_A(ST,CSM_CH)					\
{													\
	if( ST->TAC )		\
		if( (ST->TAC -= ST->freqbase*4096) <= 0 )	\
		{											\
			TimerAOver( ST );						\
			/* CSM mode total level latch and auto key on */	\
			if( ST->mode & 0x80 )					\
				CSMKeyControll( CSM_CH );			\
		}											\
}
#define INTERNAL_TIMER_B(ST,step)						\
{														\
	if( ST->TBC )				\
		if( (ST->TBC -= ST->freqbase*4096*step) <= 0 )	\
			TimerBOver( ST );							\
}

/* --------------------- subroutines  --------------------- */

/* status set and IRQ handling */
INLINE void FM_STATUS_SET(FM_ST *ST,int flag)
{
	/* set status flag */
	ST->status |= flag;
}

/* status reset and IRQ handling */
INLINE void FM_STATUS_RESET(FM_ST *ST,int flag)
{
	/* reset status flag */
	ST->status &=~flag;
}

/* ----- key on  ----- */
INLINE void FM_KEYON(FM_CH *CH , int s )
{
	FM_SLOT *SLOT = &CH->SLOT[s];
	if( SLOT->evm<= ENV_MOD_RR)
	{
		/* set envelope counter from envleope output */

		/* sin wave restart */
		SLOT->Cnt = 0;
		if( s == SLOT1 ) CH->op1_out[0] = CH->op1_out[1] = 0;
		/* set attack */
		SLOT->evm = ENV_MOD_AR;
		SLOT->evs = SLOT->evsa;
		/* reset attack counter */
		SLOT->evc = EG_AST;
		SLOT->eve = EG_AED;
	}
}
/* ----- key off ----- */
INLINE void FM_KEYOFF(FM_CH *CH , int s )
{
	FM_SLOT *SLOT = &CH->SLOT[s];
	if( SLOT->evm > ENV_MOD_RR)
	{
		/* set envelope counter from envleope output */
		SLOT->evm = ENV_MOD_RR;
		if( !(SLOT->evc&EG_DST) )
			SLOT->evc = (ENV_CURVE[SLOT->evc>>ENV_BITS]<<ENV_BITS) + EG_DST;
		SLOT->eve = EG_DED;
		SLOT->evs = SLOT->evsr;
	}
}

/* ---------- calcrate Envelope Generator & Phase Generator ---------- */
/* return : envelope output */
INLINE INT32 FM_CALC_SLOT( FM_SLOT *SLOT )
{
	/* calcrate envelope generator */
	if( (SLOT->evc+=SLOT->evs) >= SLOT->eve )
	{
		switch( SLOT->evm ){
		case ENV_MOD_AR: /* ATTACK -> DECAY1 */
			/* next DR */
			SLOT->evm = ENV_MOD_DR;
			SLOT->evc = EG_DST;
			SLOT->eve = SLOT->SL;
			SLOT->evs = SLOT->evsd;
			break;
		case ENV_MOD_DR: /* DECAY -> SUSTAIN */
			SLOT->evm = ENV_MOD_SR;
			SLOT->evc = SLOT->SL;
			SLOT->eve = EG_DED;
			SLOT->evs = SLOT->evss;
			break;
		case ENV_MOD_RR: /* RR -> OFF & STOP */
			SLOT->evm = ENV_MOD_OFF;
		case ENV_MOD_SR: /* SR -> OFF & STOP */
			SLOT->evc = EG_OFF;
			SLOT->eve = EG_OFF+1;
			SLOT->evs = 0;
			break;
		}
	}
	/* calcrate envelope */
	if(SLOT->ams)
		return SLOT->TLL+ENV_CURVE[SLOT->evc>>ENV_BITS]
			+(SLOT->ams*lfo_amd/LFO_RATE);
	return SLOT->TLL+ENV_CURVE[SLOT->evc>>ENV_BITS];
}

/* set algorythm connection */
static void set_algorythm( FM_CH *CH )
{
	INT32 *carrier = &outd[CH->PAN];

	/* setup connect algorythm */
	switch( CH->ALGO ){
	case 0:
		/*  PG---S1---S2---S3---S4---OUT */
		CH->connect1 = &feedback2;
		CH->connect2 = &feedback3;
		CH->connect3 = &feedback4;
		break;
	case 1:
		/*  PG---S1-+-S3---S4---OUT */
		/*  PG---S2-+               */
		CH->connect1 = &feedback3;
		CH->connect2 = &feedback3;
		CH->connect3 = &feedback4;
		break;
	case 2:
		/* PG---S1------+-S4---OUT */
		/* PG---S2---S3-+          */
		CH->connect1 = &feedback4;
		CH->connect2 = &feedback3;
		CH->connect3 = &feedback4;
		break;
	case 3:
		/* PG---S1---S2-+-S4---OUT */
		/* PG---S3------+          */
		CH->connect1 = &feedback2;
		CH->connect2 = &feedback4;
		CH->connect3 = &feedback4;
		break;
	case 4:
		/* PG---S1---S2-+--OUT */
		/* PG---S3---S4-+      */
		CH->connect1 = &feedback2;
		CH->connect2 = carrier;
		CH->connect3 = &feedback4;
		break;
	case 5:
		/*         +-S2-+     */
		/* PG---S1-+-S3-+-OUT */
		/*         +-S4-+     */
		CH->connect1 = 0;	/* special mark */
		CH->connect2 = carrier;
		CH->connect3 = carrier;
		break;
	case 6:
		/* PG---S1---S2-+     */
		/* PG--------S3-+-OUT */
		/* PG--------S4-+     */
		CH->connect1 = &feedback2;
		CH->connect2 = carrier;
		CH->connect3 = carrier;
		break;
	case 7:
		/* PG---S1-+     */
		/* PG---S2-+-OUT */
		/* PG---S3-+     */
		/* PG---S4-+     */
		CH->connect1 = carrier;
		CH->connect2 = carrier;
		CH->connect3 = carrier;
	}
	CH->connect4 = carrier;
}

/* set detune & multiple */
INLINE void set_det_mul(FM_ST *ST,FM_CH *CH,FM_SLOT *SLOT,int v)
{
	SLOT->mul = MUL_TABLE[v&0x0f];
	SLOT->DT  = ST->DT_TABLE[(v>>4)&7];
	CH->SLOT[SLOT1].Incr=-1;
}

/* set total level */
INLINE void set_tl(FM_CH *CH,FM_SLOT *SLOT , int v,int csmflag)
{
	v &= 0x7f;
	v = (v<<7)|v; /* 7bit -> 14bit */
	SLOT->TL = (v*EG_ENT)>>14;
	if( !csmflag )
	{	/* not CSM latch total level */
		SLOT->TLL = SLOT->TL + KSL[CH->kcode];
	}
}

/* set attack rate & key scale  */
INLINE void set_ar_ksr(FM_CH *CH,FM_SLOT *SLOT,int v,INT32 *ar_table)
{
	SLOT->KSR  = 3-(v>>6);
	SLOT->AR   = (v&=0x1f) ? &ar_table[v<<1] : RATE_0;
	SLOT->evsa = SLOT->AR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_AR ) SLOT->evs = SLOT->evsa;
	CH->SLOT[SLOT1].Incr=-1;
}
/* set decay rate */
INLINE void set_dr(FM_SLOT *SLOT,int v,INT32 *dr_table)
{
	SLOT->DR = (v&=0x1f) ? &dr_table[v<<1] : RATE_0;
	SLOT->evsd = SLOT->DR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_DR ) SLOT->evs = SLOT->evsd;
}
/* set sustain rate */
INLINE void set_sr(FM_SLOT *SLOT,int v,INT32 *dr_table)
{
	SLOT->SR = (v&=0x1f) ? &dr_table[v<<1] : RATE_0;
	SLOT->evss = SLOT->SR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_SR ) SLOT->evs = SLOT->evss;
}
/* set release rate */
INLINE void set_sl_rr(FM_SLOT *SLOT,int v,INT32 *dr_table)
{
	SLOT->SL = SL_TABLE[(v>>4)];
	SLOT->RR = &dr_table[((v&0x0f)<<2)|2];
	SLOT->evsr = SLOT->RR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_RR ) SLOT->evs = SLOT->evsr;
}

/* operator output calcrator */
#define OP_OUT(con)   SIN_TABLE[((SLOT->Cnt+con)/(0x1000000/SIN_ENT))&(SIN_ENT-1)][env_out]
#define OP_OUTN(con)  NOISE_TABLE[(NoiseCnt/(0x1000000/SIN_ENT))&(SIN_ENT-1)][env_out]
/* ---------- calcrate one of channel ---------- */
INLINE void FM_CALC_CH( FM_CH *CH )
{
	FM_SLOT *SLOT;
	UINT32 env_out;
	/* phase generator */
	INT32 pms = lfo_pmd * CH->pms / LFO_RATE;
	if(pms)
	{
		CH->SLOT[SLOT1].Cnt += CH->SLOT[SLOT1].Incr + (INT32)(pms * CH->SLOT[SLOT1].Incr) / PMS_RATE;
		CH->SLOT[SLOT2].Cnt += CH->SLOT[SLOT2].Incr + (INT32)(pms * CH->SLOT[SLOT2].Incr) / PMS_RATE;
		CH->SLOT[SLOT3].Cnt += CH->SLOT[SLOT3].Incr + (INT32)(pms * CH->SLOT[SLOT3].Incr) / PMS_RATE;
		CH->SLOT[SLOT4].Cnt += CH->SLOT[SLOT4].Incr + (INT32)(pms * CH->SLOT[SLOT4].Incr) / PMS_RATE;
	}
	else
	{
		CH->SLOT[SLOT1].Cnt += CH->SLOT[SLOT1].Incr;
		CH->SLOT[SLOT2].Cnt += CH->SLOT[SLOT2].Incr;
		CH->SLOT[SLOT3].Cnt += CH->SLOT[SLOT3].Incr;
		CH->SLOT[SLOT4].Cnt += CH->SLOT[SLOT4].Incr;
	}

	/* SLOT 1 */
	SLOT = &CH->SLOT[SLOT1];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
	{
		if( CH->FB ){
			/* with self feed back */
			int feedback1 = (CH->op1_out[0]+CH->op1_out[1])>>CH->FB;
			CH->op1_out[1] = CH->op1_out[0];
			CH->op1_out[0] = OP_OUT(feedback1);
		}else{
			/* without self feed back */
			CH->op1_out[0] = OP_OUT(0);
		}
		/* output slot1 */
		if( !CH->connect1 )
		{
			/* algorythm 5  */
			feedback2 = feedback3 = feedback4 = CH->op1_out[0];
		}else{
			/* other algorythm */
			feedback2 = feedback3 = feedback4 = 0;
			*CH->connect1 += CH->op1_out[0];
		}
	}
	else
		feedback2 = feedback3 = feedback4 = 0;
	/* SLOT 2 */
	SLOT = &CH->SLOT[SLOT2];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
		*CH->connect2 += OP_OUT(feedback2);
	/* SLOT 3 */
	SLOT = &CH->SLOT[SLOT3];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
		*CH->connect3 += OP_OUT(feedback3);
	/* SLOT 4 */
	SLOT = &CH->SLOT[SLOT4];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
		*CH->connect4 += OP_OUT(feedback4);
	/* cut off output (higher 13bit+sign) */
	*CH->connect4 &= OP_CUT_MASK;
}
/* ---------- frequency counter for operater update ---------- */
INLINE void CALC_FCSLOT(FM_SLOT *SLOT , int fc , int kc )
{
	int ksr;

	/* frequency step counter */
	/* SLOT->Incr= (fc+SLOT->DT[kc])*SLOT->mul; */
	SLOT->Incr= fc*SLOT->mul + SLOT->DT[kc];
	ksr = kc >> SLOT->KSR;
	if( SLOT->ksr != ksr )
	{
		SLOT->ksr = ksr;
		/* attack , decay rate recalcration */
		SLOT->evsa = SLOT->AR[ksr];
		SLOT->evsd = SLOT->DR[ksr];
		SLOT->evss = SLOT->SR[ksr];
		SLOT->evsr = SLOT->RR[ksr];
	}
	SLOT->TLL = SLOT->TL + KSL[kc];
}

/* ---------- frequency counter  ---------- */
INLINE void CALC_FCOUNT(FM_CH *CH )
{
	if( CH->SLOT[SLOT1].Incr==-1){
		int fc = CH->fc;
		int kc = CH->kcode;
		CALC_FCSLOT(&CH->SLOT[SLOT1] , fc , kc );
		CALC_FCSLOT(&CH->SLOT[SLOT2] , fc , kc );
		CALC_FCSLOT(&CH->SLOT[SLOT3] , fc , kc );
		CALC_FCSLOT(&CH->SLOT[SLOT4] , fc , kc );
	}
}

/* ----------- initialize time tabls ----------- */
static void init_timetables( FM_ST *ST , UINT8 *DTTABLE , int ARRATE , int DRRATE )
{
	int i,d;
	double rate;

	/* make detune table */
	for (d = 0;d <= 3;d++){
		for (i = 0;i <= 31;i++){
			rate = (double)DTTABLE[d*32 + i] * ST->freqbase * FREQ_RATE;
			ST->DT_TABLE[d][i]   =  rate;
			ST->DT_TABLE[d+4][i] = -rate;
		}
	}
	/* make attack rate & decay rate tables */
	for (i = 0;i < 4;i++) ST->AR_TABLE[i] = ST->DR_TABLE[i] = 0;
	for (i = 4;i < 64;i++){
		rate  = ST->freqbase;						/* frequency rate */
		if( i < 60 ) rate *= 1.0+(i&3)*0.25;		/* b0-1 : x1 , x1.25 , x1.5 , x1.75 */
		rate *= 1<<((i>>2)-1);						/* b2-5 : shift bit */
		rate *= (double)(EG_ENT<<ENV_BITS);
		ST->AR_TABLE[i] = rate / ARRATE;
		ST->DR_TABLE[i] = rate / DRRATE;
	}
	ST->AR_TABLE[62] = EG_AED-1;
	ST->AR_TABLE[63] = EG_AED-1;
	for (i = 64;i < 94 ;i++){	/* make for overflow area */
		ST->AR_TABLE[i] = ST->AR_TABLE[63];
		ST->DR_TABLE[i] = ST->DR_TABLE[63];
	}

}

/* ---------- reset one of channel  ---------- */
static void reset_channel( FM_ST *ST , FM_CH *CH , int chan )
{
	int c,s;

	ST->mode   = 0;	/* normal mode */
	FM_STATUS_RESET(ST,0xff);
	ST->TA     = 0;
	ST->TAC    = 0;
	ST->TB     = 0;
	ST->TBC    = 0;

	for( c = 0 ; c < chan ; c++ )
	{
		CH[c].fc = 0;
		CH[c].PAN = OUTD_CENTER;
		for(s = 0 ; s < 4 ; s++ )
		{
			CH[c].SLOT[s].SEG = 0;
			CH[c].SLOT[s].evm = ENV_MOD_OFF;
			CH[c].SLOT[s].evc = EG_OFF;
			CH[c].SLOT[s].eve = EG_OFF+1;
			CH[c].SLOT[s].evs = 0;
		}
	}
}

/* ---------- generic table initialize ---------- */
static int FMInitTable( void )
{
	int s,t;
	double rate;
	int i,j;
	double pom;

	/* allocate total level table */
	TL_TABLE = malloc(TL_MAX*2*sizeof(int));
	if( TL_TABLE == 0 ) return 0;
	/* make total level table */
	for (t = 0;t < EG_ENT-1 ;t++){
		rate = ((1<<TL_BITS)-1)/pow(10,EG_STEP*t/20);	/* dB -> voltage */
		TL_TABLE[       t] =  (int)rate;
		TL_TABLE[TL_MAX+t] = -TL_TABLE[t];
	}
	/* fill volume off area */
	for ( t = EG_ENT-1; t < TL_MAX ;t++){
		TL_TABLE[t] = TL_TABLE[TL_MAX+t] = 0;
	}

	/* make sinwave table (total level offet) */
	 /* degree 0 = degree 180                   = off */
	SIN_TABLE[0] = SIN_TABLE[SIN_ENT/2]         = &TL_TABLE[EG_ENT-1];
	for (s = 1;s <= SIN_ENT/4;s++){
		pom = sin(2*PI*s/SIN_ENT); /* sin     */
		pom = 20*log10(1/pom);	   /* decibel */
		j = pom / EG_STEP;         /* TL_TABLE steps */

        /* degree 0   -  90    , degree 180 -  90 : plus section */
		SIN_TABLE[          s] = SIN_TABLE[SIN_ENT/2-s] = &TL_TABLE[j];
        /* degree 180 - 270    , degree 360 - 270 : minus section */
		SIN_TABLE[SIN_ENT/2+s] = SIN_TABLE[SIN_ENT  -s] = &TL_TABLE[TL_MAX+j];
	}
	/* envelope counter -> envelope output table */
	for (i=0; i<EG_ENT; i++)
	{
		/* ATTACK curve */
		/* !!!!! preliminary !!!!! */
		pom = pow( ((double)(EG_ENT-1-i)/EG_ENT) , 8 ) * EG_ENT;
		/* if( pom >= EG_ENT ) pom = EG_ENT-1; */
		ENV_CURVE[i] = (int)pom;
		/* DECAY ,RELEASE curve */
		ENV_CURVE[(EG_DST>>ENV_BITS)+i]= i;
	}
	/* off */
	ENV_CURVE[EG_OFF>>ENV_BITS]= EG_ENT-1;

	/* decay to reattack envelope converttable */
	j = EG_ENT-1;
	for (i=0; i<EG_ENT; i++)
	{
		while( j && (ENV_CURVE[j] < i) ) j--;
		DRAR_TABLE[i] = j<<ENV_BITS;
		/* Log(LOG_INF,"DR %06X = %06X,AR=%06X\n",i,DRAR_TABLE[i],ENV_CURVE[DRAR_TABLE[i]>>ENV_BITS] ); */
	}
	return 1;
}


static void FMCloseTable( void )
{
	if( TL_TABLE ) free( TL_TABLE );
	return;
}

/* OPN/OPM Mode  Register Write */
INLINE void FMSetMode( FM_ST *ST ,int v )
{
	/* b7 = CSM MODE */
	/* b6 = 3 slot mode */
	/* b5 = reset b */
	/* b4 = reset a */
	/* b3 = timer enable b */
	/* b2 = timer enable a */
	/* b1 = load b */
	/* b0 = load a */
	ST->mode = v;

	/* reset Timer b flag */
	if( v & 0x20 )
		FM_STATUS_RESET(ST,0x02);
	/* reset Timer a flag */
	if( v & 0x10 )
		FM_STATUS_RESET(ST,0x01);
	/* load b */
	if( v & 0x02 )
	{
		if( ST->TBC == 0 )
		{
			ST->TBC = ( 256-ST->TB)<<4;
		}
	}else if (ST->timermodel == FM_TIMER_INTERVAL)
	{	/* stop interbval timer */
		if( ST->TBC != 0 )
		{
			ST->TBC = 0;
		}
	}
	/* load a */
	if( v & 0x01 )
	{
		if( ST->TAC == 0 )
		{
			ST->TAC = (1024-ST->TA);
			/* External timer handler */
		}
	}else if (ST->timermodel == FM_TIMER_INTERVAL)
	{	/* stop interbval timer */
		if( ST->TAC != 0 )
		{
			ST->TAC = 0;
		}
	}
}

/* Timer A Overflow */
INLINE void TimerAOver(FM_ST *ST)
{
	/* status set if enabled */
	if(ST->mode & 0x04) FM_STATUS_SET(ST,0x01);
	/* clear or reload the counter */
	if (ST->timermodel == FM_TIMER_INTERVAL)
	{
		ST->TAC = (1024-ST->TA);
	}
	else ST->TAC = 0;
}
/* Timer B Overflow */
INLINE void TimerBOver(FM_ST *ST)
{
	/* status set if enabled */
	if(ST->mode & 0x08) FM_STATUS_SET(ST,0x02);
	/* clear or reload the counter */
	if (ST->timermodel == FM_TIMER_INTERVAL)
	{
		ST->TBC = ( 256-ST->TB)<<4;
	}
	else ST->TBC = 0;
}
/* CSM Key Controll */
INLINE void CSMKeyControll(FM_CH *CH)
{
	int ksl = KSL[CH->kcode];
	/* all key off */
	FM_KEYOFF(CH,SLOT1);
	FM_KEYOFF(CH,SLOT2);
	FM_KEYOFF(CH,SLOT3);
	FM_KEYOFF(CH,SLOT4);
	/* total level latch */
	CH->SLOT[SLOT1].TLL = CH->SLOT[SLOT1].TL + ksl;
	CH->SLOT[SLOT2].TLL = CH->SLOT[SLOT2].TL + ksl;
	CH->SLOT[SLOT3].TLL = CH->SLOT[SLOT3].TL + ksl;
	CH->SLOT[SLOT4].TLL = CH->SLOT[SLOT4].TL + ksl;
	/* all key on */
	FM_KEYON(CH,SLOT1);
	FM_KEYON(CH,SLOT2);
	FM_KEYON(CH,SLOT3);
	FM_KEYON(CH,SLOT4);
}

/*******************************************************************************/
/*		YM2151 local section                                                   */
/*******************************************************************************/
/* -------------------------- OPM ---------------------------------- */
/* here's the virtual YM2151(OPM)  */
typedef struct ym2151_f {
	FM_ST ST;					/* general state     */
	FM_CH CH[8];				/* channel state     */
	UINT8 ct;					/* CT0,1             */
	UINT32 NoiseCnt;			/* noise generator   */
	UINT32 NoiseIncr;			/* noise mode enable & step */
	/* LFO */
	UINT32 LFOCnt;
	UINT32 LFOIncr;
	UINT8 pmd;					/* LFO pmd level     */
	UINT8 amd;					/* LFO amd level     */
	INT32 *wavetype;			/* LFO waveform      */
	INT32 LFO_wave[LFO_ENT*4];	/* LFO wave tabel    */
	UINT8 testreg;				/* test register (LFO reset) */
	UINT32 KC_TABLE[8*12*64+950];/* keycode,keyfunction -> count */
	void (*PortWrite)(int offset,int data);/*  callback when write CT0/CT1 */
} YM2151;

static YM2151 OPM;	/* array of YM2151's */

static INT32 *NOISE_TABLE[SIN_ENT];
static UINT32 NoiseCnt , NoiseIncr;

/* ---------- frequency counter  ---------- */
INLINE void OPM_CALC_FCOUNT(FM_CH *CH )
{
	if( CH->SLOT[SLOT1].Incr==-1)
	{
		int fc = CH->fc;
		int kc = CH->kcode;

		CALC_FCSLOT(&CH->SLOT[SLOT1] , OPM.KC_TABLE[fc + CH->SLOT[SLOT1].DT2] , kc );
		CALC_FCSLOT(&CH->SLOT[SLOT2] , OPM.KC_TABLE[fc + CH->SLOT[SLOT2].DT2] , kc );
		CALC_FCSLOT(&CH->SLOT[SLOT3] , OPM.KC_TABLE[fc + CH->SLOT[SLOT3].DT2] , kc );
		CALC_FCSLOT(&CH->SLOT[SLOT4] , OPM.KC_TABLE[fc + CH->SLOT[SLOT4].DT2] , kc );
	}
}

/* ---------- calcrate one of channel7 ---------- */
INLINE void OPM_CALC_CH7( FM_CH *CH )
{
	FM_SLOT *SLOT;
	int env_out;
	/* phase generator */
	INT32 pms = lfo_pmd * CH->pms / LFO_RATE;
	if(pms)
	{
		CH->SLOT[SLOT1].Cnt += CH->SLOT[SLOT1].Incr + (INT32)(pms * CH->SLOT[SLOT1].Incr) / PMS_RATE;
		CH->SLOT[SLOT2].Cnt += CH->SLOT[SLOT2].Incr + (INT32)(pms * CH->SLOT[SLOT2].Incr) / PMS_RATE;
		CH->SLOT[SLOT3].Cnt += CH->SLOT[SLOT3].Incr + (INT32)(pms * CH->SLOT[SLOT3].Incr) / PMS_RATE;
		CH->SLOT[SLOT4].Cnt += CH->SLOT[SLOT4].Incr + (INT32)(pms * CH->SLOT[SLOT4].Incr) / PMS_RATE;
	}
	else
	{
		CH->SLOT[SLOT1].Cnt += CH->SLOT[SLOT1].Incr;
		CH->SLOT[SLOT2].Cnt += CH->SLOT[SLOT2].Incr;
		CH->SLOT[SLOT3].Cnt += CH->SLOT[SLOT3].Incr;
		CH->SLOT[SLOT4].Cnt += CH->SLOT[SLOT4].Incr;
	}

	/* SLOT 1 */
	SLOT = &CH->SLOT[SLOT1];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
	{
		if( CH->FB ){
			/* with self feed back */
			int feedback1 = (CH->op1_out[0]+CH->op1_out[1])>>CH->FB;
			CH->op1_out[1] = CH->op1_out[0];
			CH->op1_out[0] = OP_OUT(feedback1);
		}else{
			/* without self feed back */
			CH->op1_out[0] = OP_OUT(0);
		}
		/* output slot1 */
		if( !CH->connect1 )
		{
			/* algorythm 5  */
			feedback2 = feedback3 = feedback4 = CH->op1_out[0];
		}else{
			/* other algorythm */
			feedback2 = feedback3 = feedback4 = 0;
			*CH->connect1 += CH->op1_out[0];
		}
	}
	else
		feedback2 = feedback3 = feedback4 = 0;
	/* SLOT 2 */
	SLOT = &CH->SLOT[SLOT2];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
		*CH->connect2 += OP_OUT(feedback2);
	/* SLOT 3 */
	SLOT = &CH->SLOT[SLOT3];
	env_out=FM_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
		*CH->connect3 += OP_OUT(feedback3);
	/* SLOT 4 */
	SLOT = &CH->SLOT[SLOT4];
	env_out=FM_CALC_SLOT(SLOT);
	if(NoiseIncr)
	{
		NoiseCnt += NoiseIncr;
		if( env_out < EG_ENT-1 )
			*CH->connect4 += OP_OUTN(feedback4);
	}
	else
	{
		if( env_out < EG_ENT-1 )
			*CH->connect4 += OP_OUT(feedback4);
	}
}

/* ---------- priscaler set(and make time tables) ---------- */
static void OPMInitTable()
{
	int i;
	double pom;
	double rate;

	if (OPM.ST.rate)
		rate = (double)(1<<FREQ_BITS) / (3579545.0 / OPM.ST.clock * OPM.ST.rate);
	else rate = 1;

	for (i=0; i<8*12*64+950; i++)
	{
		/* This calculation type was used from the Jarek's YM2151 emulator */
		pom = 6.875 * pow (2, ((i+4*64)*1.5625/1200.0) ); /*13.75Hz is note A 12semitones below A-0, so D#0 is 4 semitones above then*/
		/*calculate phase increment for above precounted Hertz value*/
		OPM.KC_TABLE[i] = (UINT32)(pom * rate);
		/*Log(LOG_WAR,"OPM KC %d = %x\n",i,OPM.KC_TABLE[i]);*/
	}

	/* make time tables */
	init_timetables( &OPM.ST , OPM_DTTABLE , OPM_ARRATE , OPM_DRRATE );
	/* LFO wave table */
	for(i=0;i<LFO_ENT;i++)
	{
		OPM.LFO_wave[          i]= LFO_RATE * i / LFO_ENT /127;
		OPM.LFO_wave[LFO_ENT  +i]= ( i<LFO_ENT/2 ? 0 : LFO_RATE )/127;
		OPM.LFO_wave[LFO_ENT*2+i]= LFO_RATE* (i<LFO_ENT/2 ? i : LFO_ENT-i) /(LFO_ENT/2) /127;
		OPM.LFO_wave[LFO_ENT*3+i]= LFO_RATE * (rand()&0xff) /256 /127;
	}
	/* NOISE wave table */
	for(i=0;i<SIN_ENT;i++)
	{
		int sign = rand()&1 ? TL_MAX : 0;
		int lev = rand()&0x1ff;
		//pom = lev ? 20*log10(0x200/lev) : 0;   /* decibel */
		//NOISE_TABLE[i] = &TL_TABLE[sign + (int)(pom / EG_STEP)]; /* TL_TABLE steps */
		NOISE_TABLE[i] = &TL_TABLE[sign + lev * EG_ENT/0x200]; /* TL_TABLE steps */
	}
}

/* ---------- write a register on YM2151 chip number 'n' ---------- */
static void OPMWriteReg(int r, int v)
{
	UINT8 c;
	FM_CH *CH;
	FM_SLOT *SLOT;

	c   = OPM_CHAN(r);
	CH  = &OPM.CH[c];
	SLOT= &CH->SLOT[OPM_SLOT(r)];

	switch( r & 0xe0 ){
	case 0x00: /* 0x00-0x1f */
		switch( r ){
		case 0x01:	/* test */
			if( (OPM.testreg&(OPM.testreg^v))&0x02 ) /* fall eggge */
			{	/* reset LFO counter */
				OPM.LFOCnt = 0;
			}
			OPM.testreg = v;
			break;
		case 0x08:	/* key on / off */
			c = v&7;
			/* CSM mode */
			if( OPM.ST.mode & 0x80 ) break;
			CH = &OPM.CH[c];
			if(v&0x08) FM_KEYON(CH,SLOT1); else FM_KEYOFF(CH,SLOT1);
			if(v&0x10) FM_KEYON(CH,SLOT2); else FM_KEYOFF(CH,SLOT2);
			if(v&0x20) FM_KEYON(CH,SLOT3); else FM_KEYOFF(CH,SLOT3);
			if(v&0x40) FM_KEYON(CH,SLOT4); else FM_KEYOFF(CH,SLOT4);
			break;
		case 0x0f:	/* Noise freq (ch7.op4) */
			/* b7 = Noise enable */
			/* b0-4 noise freq  */
			OPM.NoiseIncr = !(v&0x80) ? 0 :
				/* !!!!! unknown noise freqency rate !!!!! */
				(1<<FREQ_BITS) / 65536 * (v&0x1f) * OPM.ST.freqbase;
			break;
		case 0x10:	/* timer A High 8*/
			OPM.ST.TA = (OPM.ST.TA & 0x03)|(((int)v)<<2);
			break;
		case 0x11:	/* timer A Low 2*/
			OPM.ST.TA = (OPM.ST.TA & 0x3fc)|(v&3);
			break;
		case 0x12:	/* timer B */
			OPM.ST.TB = v;
			break;
		case 0x14:	/* mode , timer controll */
			FMSetMode( &(OPM.ST),v );
			break;
		case 0x18:	/* lfreq   */
			/* f = fm * 2^(LFRQ/16) / (4295*10^6) */
			{
				static double drate[16]={
					1.0        ,1.044273782,1.090507733,1.138788635, //0-3
					1.189207115,1.241857812,1.296839555,1.354255547, //4-7
					1.414213562,1.476826146,1.542210825,1.610490332, //8-11
					1.681792831,1.75625216 ,1.834008086,1.915206561};
				double rate = pow(2.0,v/16)*drate[v&0x0f] / 4295000000.0;
				OPM.LFOIncr = (double)LFO_ENT*(1<<LFO_SHIFT) * (OPM.ST.freqbase*64) * rate;
			}
			break;
		case 0x19:	/* PMD/AMD */
			if( v & 0x80 ) OPM.pmd = v & 0x7f;
			else           OPM.amd = v & 0x7f;
			break;
		case 0x1b:	/* CT , W  */
			/* b7 = CT1 */
			/* b6 = CT0 */
			/* b0-2 = wave form(LFO) 0=nokogiri,1=houkei,2=sankaku,3=noise */
			//if(OPM.ct != v)
			{
				OPM.ct = v>>6;
				if( OPM.PortWrite != 0)
					OPM.PortWrite(0, OPM.ct ); /* bit0 = CT0,bit1 = CT1 */
			}
			if( OPM.wavetype != &OPM.LFO_wave[(v&3)*LFO_ENT])
			{
				OPM.wavetype = &OPM.LFO_wave[(v&3)*LFO_ENT];
			}
			break;
		}
		break;
	case 0x20:	/* 20-3f */
		switch( OPM_SLOT(r) ){
		case 0: /* 0x20-0x27 : RL,FB,CON */
			{
				int feedback = (v>>3)&7;
				CH->ALGO = v&7;
				CH->FB  = feedback ? 8+1 - feedback : 0;
				/* RL order -> LR order */
				CH->PAN = ((v>>7)&1) | ((v>>5)&2);
				set_algorythm( CH );
			}
			break;
		case 1: /* 0x28-0x2f : Keycode */
			{
				int blk = (v>>4)&7;
				/* make keyscale code */
				CH->kcode = (v>>2)&0x1f;
				/* make basic increment counter 22bit = 1 cycle */
				CH->fc = (blk * (12*64)) + KC_TO_SEMITONE[v&0x0f] + CH->fn_h;
				CH->SLOT[SLOT1].Incr=-1;
			}
			break;
		case 2: /* 0x30-0x37 : Keyfunction */
			CH->fc -= CH->fn_h;
			CH->fn_h = v>>2;
			CH->fc += CH->fn_h;
			CH->SLOT[SLOT1].Incr=-1;
			break;
		case 3: /* 0x38-0x3f : PMS / AMS */
			/* b0-1 AMS */
			/* AMS * 23.90625db @ AMD=127 */
			//CH->ams = (v & 0x03) * (23.90625/EG_STEP);
			CH->ams = (23.90625/EG_STEP) / (1<<(3-(v&3)));
			CH->SLOT[SLOT1].ams = CH->ams * CH->SLOT[SLOT1].amon;
			CH->SLOT[SLOT2].ams = CH->ams * CH->SLOT[SLOT2].amon;
			CH->SLOT[SLOT3].ams = CH->ams * CH->SLOT[SLOT3].amon;
			CH->SLOT[SLOT4].ams = CH->ams * CH->SLOT[SLOT4].amon;
			/* b4-6 PMS */
			/* 0,5,10,20,50,100,400,700 (cent) @ PMD=127 */
			{
				/* 1 octabe = 1200cent = +100%/-50% */
				/* 100cent  = 1seminote = 6% ?? */
				static const int pmd_table[8] = {0,5,10,20,50,100,400,700};
				CH->pms = (1.5/1200.0)*pmd_table[(v>>4) & 0x07] * PMS_RATE;
			}
			break;
		}
		break;
	case 0x40:	/* DT1,MUL */
		set_det_mul(&OPM.ST,CH,SLOT,v);
		break;
	case 0x60:	/* TL */
		set_tl(CH,SLOT,v,(c == 7) && (OPM.ST.mode & 0x80) );
		break;
	case 0x80:	/* KS, AR */
		set_ar_ksr(CH,SLOT,v,OPM.ST.AR_TABLE);
		break;
	case 0xa0:	/* AMS EN,D1R */
		set_dr(SLOT,v,OPM.ST.DR_TABLE);
		/* bit7 = AMS ENABLE */
		SLOT->amon = v>>7;
		SLOT->ams = CH->ams * SLOT->amon;
		break;
	case 0xc0:	/* DT2 ,D2R */
		SLOT->DT2  = DT2_TABLE[v>>6];
		CH->SLOT[SLOT1].Incr=-1;
		set_sr(SLOT,v,OPM.ST.DR_TABLE);
		break;
	case 0xe0:	/* D1L, RR */
		set_sl_rr(SLOT,v,OPM.ST.DR_TABLE);
		break;
    }
}

/* ---------- read status port ---------- */
static UINT8 OPMReadStatus()
{
	return OPM.ST.status;
}

void FASTCALL OPM_Write(WORD a,BYTE v)
{
	if( !(a&1) )
	{	/* address port */
		OPM.ST.address = v & 0xff;
	}
	else
	{	/* data port */
		int addr = OPM.ST.address;
		/* write register */
		 OPMWriteReg(addr,v);
	}
}

/* ---------- reset one of chip ---------- */
void OPM_Reset()
{
	int i;

	OPMInitTable();
	reset_channel( &OPM.ST , &OPM.CH[0] , 8 );
	/* status clear */
	OPMWriteReg(0x1b,0x00);
	/* reset OPerator paramater */
	for(i = 0xff ; i >= 0x20 ; i-- ) OPMWriteReg(i,0);
}

/* ----------  Initialize YM2151 emulator(s) ----------    */
/* 'num' is the number of virtual YM2151's to allocate     */
/* 'rate' is sampling rate and 'bufsiz' is the size of the */
/* buffer that should be updated at each interval          */
int OPM_Init(int clock, int rate)
{
	int i;

	FMInitTable();
	OPM.ST.clock = clock;
	OPM.ST.rate = rate;
	OPM.ST.timermodel = FM_TIMER_INTERVAL;
	OPM.ST.freqbase  = rate ? ((double)clock / rate) / 64 : 0;
	OPM.ST.TimerBase = 1.0/((double)clock / 64.0);
	/* Reset callback handler of CT0/1 */
	OPM.PortWrite = 0;
	OPM_Reset();
	return TRUE;
}

/* ---------- shut down emurator ----------- */
void OPM_Cleanup()
{
	FMCloseTable();
}

BYTE FASTCALL OPM_Read(WORD a)
{
	if (OPM_SW)
		return OPM.ST.status;
	else
		return 0xff;
}

/* ---------- make digital sound data ---------- */
void OPM_Update(INT16 *buffer, int length)
{
	int i;
	int amd,pmd;

	/* set bufer */
	bufL = buffer;
	bufR = buffer;

	amd = OPM.amd;
	pmd = OPM.pmd;
	if(amd==0 && pmd==0)
		LFOIncr = 0;
	else
		LFOIncr = OPM.LFOIncr;

	OPM_CALC_FCOUNT( &OPM.CH[0] );
	OPM_CALC_FCOUNT( &OPM.CH[1] );
	OPM_CALC_FCOUNT( &OPM.CH[2] );
	OPM_CALC_FCOUNT( &OPM.CH[3] );
	OPM_CALC_FCOUNT( &OPM.CH[4] );
	OPM_CALC_FCOUNT( &OPM.CH[5] );
	OPM_CALC_FCOUNT( &OPM.CH[6] );
	/* CSM check */
	OPM_CALC_FCOUNT( &OPM.CH[7] );

    for( i=0; i < length ; i++ )
	{
		/* LFO */
		if( LFOIncr )
		{
			INT32 depth = OPM.wavetype[(OPM.LFOCnt+=LFOIncr)>>LFO_SHIFT];
			lfo_amd = depth * amd;
			lfo_pmd = (depth-(LFO_RATE/127/2)) * pmd;
		}
		/* clear output acc. */
		outd[OUTD_LEFT] = outd[OUTD_RIGHT]= outd[OUTD_CENTER] = 0;

		/* calcrate channel output */
		FM_CALC_CH( &OPM.CH[0] );
		FM_CALC_CH( &OPM.CH[1] );
		FM_CALC_CH( &OPM.CH[2] );
		FM_CALC_CH( &OPM.CH[3] );
		FM_CALC_CH( &OPM.CH[4] );
		FM_CALC_CH( &OPM.CH[5] );
		FM_CALC_CH( &OPM.CH[6] );
		OPM_CALC_CH7( &OPM.CH[7] );
		/* buffering */

		FM_BUFFERING_STEREO;
		/* timer A controll */
		INTERNAL_TIMER_A( (&OPM.ST) , (&OPM.CH[7]) )
    }
	INTERNAL_TIMER_B((&OPM.ST),length)
}

void OPM_SetVolume(BYTE vol)
{
	if (vol>16) vol=16;
	if (vol<0) vol=0;
	if (vol)
		VolumeShift = pow(1.189207115, (16-vol));
	else
		VolumeShift = 65536;		// Mute
}
