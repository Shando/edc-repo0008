This version of VisualBoyAdvance Rerecording GB/GBA emulator is in experimental stage. The features might be changed in the formal releases.

Notable problems:
* There are known emulation bugs in some games.
* Savestates are incompatible with, but cannot be distinguished fom those made with previous versions. Avoid confusion on your own.
