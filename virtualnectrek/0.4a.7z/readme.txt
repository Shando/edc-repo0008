Turn Word Wrap ON if you're using Notepad.

Virtual NEC Trek for Windows98 or newer, by James the Animal Tamer.

System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows98 or newer
DirectX
16-bit video card (Virtual NEC Trek will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX


Quick Start
===========
	Extract the Zipped files to a folder on your hard drive, preserving the directory structure.
	Double click the VNECTREK icon!
	When you're prompted for number of pages, type 2 and press the enter key.
	Suppose you want to see the NEC Trek demo.  Type CLOAD and press the enter key.  Then, from the File menu, select Play Cassette File.  From the dialog box which pops up, browse down into the cassette directory, and from there into the demo directory, and select ALLDEMO.CP6.
	After the loading has finished and you see a blinking prompt again, type RUN and press the enter key.
	Enjoy the show!


Known Bugs
==========
1.  You must configure the printer filename before trying to LPRINT or LLIST.  You should do that now.  Really.
2.  There's a problem in which the sound gets a lot of static for a while.
3.  If you start a cassette file playing, you might not be able to start another in the same session.
4.  An extraneous character 255 gets written to LPRINT file sometimes, generally on reset.
5.  I've occasionally had a problem with CLOADing a file.  If it doesn't work right the first time, try again.


Preliminary Note:
=================
Here's Virtual NEC Trek version 0.4a.  The low number indicates that it's sort of working, but not a complete emulation.

An important feature for BASIC programmers is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into the Virtual NEC Trek.  This is much easier than trying to type in a program on the Virtual NEC Trek itself (although that can be done).

If you prefer to use the Virtual NEC Trek's keyboard anyway, you can LLIST your program, then use NOTEPAD to extract your program from the printer output file.  Save out the extracted program to another text file, and you can use the Quicktype feature to load that in.



What works:
=====================
CPU
Memory (with configuration)
Keyboard (emulated)
Video (Mostly working, colors can be configured)
Quicktype (provides a means of loading in BASIC programs from text files)
LPRINT/LLIST (To file.)
BASIC CLOAD (CP6 files)
BASIC CSAVE (CP6 files)
Character set (Internal 6847 set is good but not perfect)
Insertion/removal of game cartridges (you need to Hard Reset to start the cartridge)
Joystick (working, but not configurable at present)
Optional loading of other ROM OS
Sound (somewhat working)
Window size configuration
Touch tablet (use mouse pointer, holding left button, on the window.  Needs work).
Keyboard (sensible)
Key click sound
Video border (somewhat working)
Utility loader of "binary" data


What does NOT work:
=====================
Video (Mixed modes)
Accurate timing
Timers (Sort of working, but not quite there)
Interrupts (Sort of working, but imperfectly)
Disk drive
Other peripherals



 What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Fix bugs
Load/Save WAV files
Drag and drop of supported file types
Paste from clipboard (quicktypes)


NOTES:
=====================
1.  Joysticks.  Virtual NEC Trek uses DirectX for joystick input.  Virtual NEC Trek is tuned for using "joypads."  The joypads I'm using are Microsoft Sidewinder Game Pads.  You can daisy chain two of them.  Anyway, Virtual NEC Trek should work with any joystick that's properly installed under Windows, and, for modern joypads (e.g. Logitech USB circa 2005), it'll also use the POV hat for directionals.

2.  Sound.  Uses DirectSound.  It is mostly working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static.  Note that if your computer is not running the emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).  The AY sound is updated every frame, so unfortunately transients (like the key click) and digitized sound don't work.

3.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real NEC Trek keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.

4.  CLOAD.  To CLOAD a .CP6 file from BASIC, first type CLOAD.  Then select Play Cassette File from the File menu, and choose your .CP6 cassette file.

5.  Game cartridges.  To use these ROMs, from Virtual NEC Trek's file menu, select Load Game ROM.  Select an appropriate cartridge image (.bin file) to load.  To start the software on the cartridge, then select Hard Reset from Virtual NEC Trek's file menu.





Versions:
=========
March 23 2006: 0.4a
	Updated capabilities with features recently updated in my other emulators:
	Full Screen mode can now access the menus. Right click on the full screen to toggle menus.
	The sound buffers will attempt to resynch themselves when no sound has been playing for a while (a half-second or so). This is detected by the speaker clicker not being written to and by the three AY chip volumes being set to 0.
	The POV hat can be used as the joystick directionals in a modern USB joypad.
	Util/Load Binary -- This is useful for assembly language program development.
	Util/Screenshot (F11)  -- puts the screenshots into the screenshots directory.  Beware, the names wrap after 9999.
	Util/Full Screen mode (F12 to toggle)
	Util/Paste -- this Quicktypes text that was on the text clipboard, i.e. Copy from Notepad and Paste onto the emulator.
	Some file access routines are smarter about remembering which file you were using last.  It takes getting used to, but it really is better than before.  Really.
	The emulator should no longer crash when you have Configure/System Timing>Speed up when accessing files checked.
	Soft Reset is now F9 on the keyboard.
	Hard Reset is now Shift F9 on the keyboard.


March 14 2001: 0.4
	First working version.  It's mostly working, too!


Credits
=======
Me (James the Animal Tamer) -- Everything that's not mentioned separately below

Z80Em:		Portable Z80 emulator Copyright (C) Marcel de Kogel 1996,1997
	(I grabbed this from MAME)

ay8910.c	From MAME, credited to Ville Hallik, Michael Cuddy,Tatsuyuki Satoh, Fabrice Frances, Nicola Salmoria.

Character set	Drawn by camennie, of the Yahoo MC-10 club

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98. 		 Thanks, Bill.

ROMs and some .CP6 files:	See those for their respective credits.


Random Jottings
===============
1.  What is a NEC Trek?
Quick Answer:  A computer system sold at various consumer electronic stores circa 1983-1985.
Longer Answer:  "NEC Trek" is the name pinned on the NEC PC-6001A computer by its American marketers.  Back in the early to mid 1980s, Japanese computer companies attempted to penetrate the American home computer market several times.  The NEC Trek was NEC's offering.  It did not fare well in America, where it had to compete against the Commodore 64, the Atari 800, the Apple II+/e/c, and the TI 99/4a computer lines.  In Japan, though, the Japanese version did well enough to found a family of computers.  The NEC Trek differs from its Japanese brother, the PC-6001, primarily by having a different character set.
	The NEC Trek features a z80 workalike as main CPU.  There's a secondary system within the computer which controls the peripherals, but is not really "programmable."  The video display controller is a Motorola 6847, the same chip used in the Radio Shack Color Computer;  it's connected differently, though, giving the NEC Trek the ability to mix different alpha and semigraphics modes on the same screen.  The NEC Trek comes standard with 16K of RAM.  A 16K RAM expander was also sold.
	The Federated Group sold a dozen or so games on cartridge.  I remember that later, The Federated Group sold a NEC Trek bundle deal (correct me if I'm wrong here) -- computer, expander, cassette drive, disk drive, pair of joysticks, touch tablet, and five game cartridges for $350.  This was around Spring 1984.  At the same time, they were selling a Tomy Tutor bundle (computer, cassette drive, joystick, pair of joypad controllers, five game cartridges) for $85.  I got the Tomy Tutor bundle instead ;)


==

2.  What is an emulator?
	An emulator is a software program which enables one computer to act like another.  It'll emulate the graphics, peripherals, sound, timing, etc.  Ideally, the emulator will run pretty much everything the emulated computer could run, and provide a similar "experience."

==

3.  Cool.  Now how do I get started?
	Double click the VNECTREK icon!
	Now you can type your program in.  You can CSAVE it via 
CSAVE "filename"
just as you would if you were using a real NEC Trek system.
	You can RUN your program.
	Wow.  Okay.  Suppose you want to load your program back in?  Type CLOAD.  Then from the File menu, select Play Cassette File.  From the dialog box which pops up, select your program!
	Remember, to load, always type CLOAD first, then select the Play Cassette File from the File menu.

	I like Quicktype better than the cassette stuff.  To use Quicktype, write your BASIC program using Notepad.  Save it.  Then use Quicktype from the File menu, and select the file you just saved.  Virtual NEC Trek will enter it just as if you had typed it!






